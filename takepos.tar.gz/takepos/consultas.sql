SELECT f.rowid, f.facnumber, f.ref_client, f.fk_mode_reglement, b.fk_type , if(b.fk_type='LIQ',4,if(b.fk_type='CB',5,'')) as pay FROM `llx_facture` as f
LEFT JOIN llx_paiement_facture as pf on f.rowid = pf.fk_facture
LEFT JOIN llx_paiement as p on pf.rowid= p.rowid
LEFT JOIN llx_bank as b on p.fk_bank=b.rowid
WHERE module_source='takepos'
