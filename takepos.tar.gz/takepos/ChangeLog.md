# ChangeLog:
    --------------------- Takepos for Dolibarr ---------------------
    JC Prieto  <jcprieto@virtual20.com>

##[Unreleased]
* Fixed
    
* Added
    
* Changed:
    
##[190225]
* Added
    - Photos for products and categories.
       
##[Done]
* Added
    - Main category for POS.
    - Using multiprices level.
* Fixed
    - Fix facnumber. 
        

## 1.0
Initial version

