<?php // BEGIN PHP
$websitekey=basename(__DIR__);
if (! defined('USEDOLIBARRSERVER') && ! defined('USEDOLIBARREDITOR')) { require_once __DIR__.'/master.inc.php'; } // Load env if not already loaded
require_once DOL_DOCUMENT_ROOT.'/core/lib/website.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/website.inc.php';
ob_start();
if (! headers_sent()) {	/* because file is included inline when in edit mode and we don't want warning */ 
header('Cache-Control: max-age=3600, public, must-revalidate');
header('Content-type: text/css');
}
// END PHP ?>
/* CSS content (all pages) */
/*body.bodywebsite { margin: 0; font-family: 'Open Sans', sans-serif; }
.bodywebsite h1 { margin-top: 0; margin-bottom: 0; padding: 10px;}
*/

.bodywebsite #mysection1 {
    font-family: Gulzar;
    font-size: 1.2rem;
    font-weight: bold;
}

.bodywebsite .flex {
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
}

.bodywebsite h1 h2 h3 h4 {
    font-family: Anton;
    font-weight: 900;
}

.bodywebsite section {
    min-height: 100vh;
}

.bodywebsite .btn-perso {
    background-color: #50759e;
    padding-left: 20px;
    padding-right: 20px;
    text-align: center;
    color: #fff;
    font-weight: bold;
}

.bodywebsite .btn-perso:hover {
    background-color: #fff;
    color: #bb393c;
}

.bodywebsite #landing {
    background-color: #C84F37;
    color: #fff;
    height: 100vh;
}

.bodywebsite #desc {
    background-color: #292727;
}

.bodywebsite nav {
    padding-left: 30px;
    padding-right: 30px;
    background-color: rgba(12, 12, 12, 0.5);
    width: 100%;
}

.bodywebsite #title {
    font-size: 80px;
    z-index: 11;
}

.bodywebsite .img-landing {
    position: relative;
    top: -10%;
    z-index: 10;
}

.bodywebsite .pointed {
    cursor: pointer;
    background-color: #292727;
    color: #fff;
}

.bodywebsite #contact {
    background-color: #C84F37;
    color: white;
}

.bodywebsite .container {
    padding-top: 10%;
    padding-bottom: 10%;
}
<?php // BEGIN PHP
$tmp = ob_get_contents(); ob_end_clean(); dolWebsiteOutput($tmp, "css");
// END PHP ?>
