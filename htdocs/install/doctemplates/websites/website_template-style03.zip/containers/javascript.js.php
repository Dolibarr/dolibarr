<?php // BEGIN PHP
$websitekey=basename(__DIR__);
if (! defined('USEDOLIBARRSERVER') && ! defined('USEDOLIBARREDITOR')) { require_once __DIR__.'/master.inc.php'; } // Load env if not already loaded
require_once DOL_DOCUMENT_ROOT.'/core/lib/website.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/website.inc.php';
ob_start();
header('Cache-Control: max-age=3600, public, must-revalidate');
header('Content-type: application/javascript');
// END PHP ?>
/* JS content (all pages) */
  const about = document.getElementById("aboutAuthor");
            const commonText = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis accusantium earum sed odit velit laudantium ex libero quisquam consectetur, dolorem vero ipsam perferendis quibusdam itaque omnis a consequatur error repellat";
            const authorsText = {
                one: "Author 1 : lorem ipsum dolor sit amet, consectetur adipis lorem ipsum dolor sit amet, consectetur adipis lorem ipsum dolor sit amet, consectetur adipis lorem ipsum dolor sit amet, consectetur adipis",
                two: "Author 2 : lorem ipsum dolor sit amet, consectetur adipis lorem ipsum dolor sit amet, consectetur adipislorem ipsum dolor sit amet, consectetur adipis lorem ipsum dolor sit amet, consectetur adipis",
                three: "Author 3 : lorem ipsum dolor sit amet, consectetur adipis lorem ipsum dolor sit amet, consectetur adipislorem ipsum dolor sit amet, consectetur adipis lorem ipsum dolor sit amet, consectetur adipis",
                four: "Author 4 : lorem ipsum dolor sit amet, consectetur adipis lorem ipsum dolor sit amet, consectetur adipis lorem ipsum dolor sit amet, consectetur adipis lorem ipsum dolor sit amet, consectetur adipis",
            }                                

            addPointClass = function(point) {
                point.classList.add("pointed");  
                about.innerText = authorsText[point.id];                                  
            };
            
            removePointClass = function(point) {
                point.classList.remove("pointed");        
                about.innerText = commonText;                        
            };
<?php // BEGIN PHP
$tmp = ob_get_contents(); ob_end_clean(); dolWebsiteOutput($tmp, "js");
// END PHP ?>
