<?php // BEGIN PHP
$websitekey=basename(__DIR__);
if (! defined('USEDOLIBARRSERVER') && ! defined('USEDOLIBARREDITOR')) { require_once __DIR__.'/master.inc.php'; } // Load env if not already loaded
require_once DOL_DOCUMENT_ROOT.'/core/lib/website.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/website.inc.php';
ob_start();
if (! headers_sent()) {	/* because file is included inline when in edit mode and we don't want warning */ 
header('Cache-Control: max-age=3600, public, must-revalidate');
header('Content-type: text/css');
}
// END PHP ?>
/* CSS content (all pages) */ 


.bodywebsite h1,
.bodywebsite h2,
.bodywebsite h3,
.bodywebsite h4,
.bodywebsite h5,
.bodywebsite h6 {
    font-family: 'Hurricane', cursive;
}

.bodywebsite #title {
    font-size: 100px;
}
.bodywebsite #mysection1{
    font-family: 'Inconsolata', monospace;
    color: white;
    height: 100%;
}

.bodywebsite .full-height {
    height: 100vh;
}
.bodywebsite .color {
    color: #aefeff;
}

.bodywebsite .btn-color {
    font-weight: bold;
    color: #35858b;
    border-color: #35858b;
}

.bodywebsite .btn-color:hover {
    background-color: #35858b;
    color: #fff;
}

.bodywebsite .btn-color-filled {
    background-color: #35858b;
    color: #072227;
}
.bodywebsite #products {
    background-color: whitesmoke;
}

.bodywebsite #home, .bodywebsite  #contact{
    background-color: #072227;
}

.bodywebsite footer {
    position: fixed;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
}

/*# sourceMappingURL=bootstrap.css.map */
<?php // BEGIN PHP
$tmp = ob_get_contents(); ob_end_clean(); dolWebsiteOutput($tmp, "css");
// END PHP ?>
