<?php // BEGIN PHP
$websitekey=basename(__DIR__);
if (! defined('USEDOLIBARRSERVER') && ! defined('USEDOLIBARREDITOR')) { require_once __DIR__.'/master.inc.php'; } // Load env if not already loaded
require_once DOL_DOCUMENT_ROOT.'/core/lib/website.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/website.inc.php';
ob_start();
if (! headers_sent()) {	/* because file is included inline when in edit mode and we don't want warning */ 
header('Cache-Control: max-age=3600, public, must-revalidate');
header('Content-type: text/css');
}
// END PHP ?>
/* CSS content (all pages) 
#mysection1 { margin: 100px; font-family: 'Open Sans', sans-serif; }
#mysection1 h1 { margin-top: 0; margin-bottom: 0; padding: 10px;}
*/

h1,
h2,
h3,
h4,
h5,
h6 {
    font-family: 'Hurricane', cursive;
}

nav {
    background-color: #072227;
}

#title {
    font-size: 100px;
}
#mysection1{
    font-family: 'Inconsolata', monospace;
    color: white;
    height: 100%;
}

#mysection1,
main,
.full-height {
    height: 100vh;
}
.color {
    color: #aefeff;
}

.btn-color {
    font-weight: bold;
    color: #35858b;
    border-color: #35858b;
}

.btn-color:hover {
    background-color: #35858b;
    color: #fff;
}

.btn-color-filled {
    background-color: #35858b;
    color: #072227;
}
#products {
    background-color: whitesmoke;
}

#home, #contact{
    background-color: #072227;
}

footer {
    position: fixed;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
}

/*# sourceMappingURL=bootstrap.css.map */
<?php // BEGIN PHP
$tmp = ob_get_contents(); ob_end_clean(); dolWebsiteOutput($tmp, "css");
// END PHP ?>
