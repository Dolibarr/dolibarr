<?php
// File generated to link to the master file
if (! defined('USEDOLIBARRSERVER')) require_once '/home/ldestailleur/git/dolibarr/htdocs/master.inc.php';
?>
