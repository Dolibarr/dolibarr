<?php // BEGIN PHP
$websitekey=basename(dirname(__FILE__));
if (! defined('USEDOLIBARRSERVER')) { require_once dirname(__FILE__).'/master.inc.php'; } // Not already loaded
require_once DOL_DOCUMENT_ROOT.'/core/lib/website.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/website.inc.php';
ob_start();
header('Content-type: text/css');
// END PHP ?>
/* CSS content (all pages) */
body.bodywebsite { margin: 0; font-family: 'Open Sans', sans-serif; }
.bodywebsite h1 { margin-top: 0; margin-bottom: 0; padding: 10px;}

a:focus,
button:focus {
	outline: none !important;
}

button::-moz-focus-inner {
	border: 0;
}

:focus {
	outline: none;
}

input, select, textarea {
	outline: 0;
}

p {
	margin: 0;
}

q {
    font-size: 18px;
}

dl {
	margin-bottom: 0;
}

dt {
	font-weight: 400;
}

html p a:hover {
	text-decoration: none;
}

form {
	margin-bottom: 0;
}

.text-left {
	text-align: left;
}

.text-center {
	text-align: center;
}

.text-right {
	text-align: right;
}

.page .text-middle {
	vertical-align: middle;
}

.page {
	overflow: hidden;
}
.page-head {
	position: relative;
	z-index: 500;
	background-color: #fff;
}
.page-content {
	position: relative;
	z-index: 1;
}
.page-foot {
	background-color: #000;
}

input,
button,
select,
textarea {
	font-family: inherit;
	font-size: inherit;
	line-height: inherit;
}

a {
	display: inline-block;
	text-decoration: none;
	transition: .33s all ease-out;
}

a, a:active, a:focus {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

a:hover, a:focus {
	color: <?php echo empty($website->maincolorbis) ? '#6ca' : '#'.$website->maincolorbis; ?>;
	text-decoration: none;
}

a:focus {
	outline: 0;
}

a[href*='callto'], a[href*='mailto'] {
	white-space: nowrap;
}

img {
	vertical-align: middle;
	max-width: 100%;
}

.img-responsive {
	max-width: 100%;
	height: auto;
}

.img-circle {
	border-radius: 50%;
}

hr {
	margin-top: 0;
	margin-bottom: 0;
	border: 0;
	border-top: 1px solid #2a2b2b;
}

[role="button"] {
	cursor: pointer;
}


.rights {
	display: inline-block;
	margin: 0;
	line-height: 1.5;
	letter-spacing: .025em;
	vertical-align: baseline;
}

.rights * {
	display: inline;
	margin-right: .25em;
}

.page-foot-default .rights {
	color: #fff;
	font-weight: 300;
}

.page-foot .brand + * {
	margin-top: 22px;
}

.page-foot * + .link-block {
	margin-top: 15px;
}

.page-foot .footer-title + * {
	margin-top: 30px;
}

.page-foot .contact-info * + .unit {
	margin-top: 15px;
}

.privacy-link {
	margin-top: 30px;
}

.one-page-section * + .group-xl {
	margin-top: 40px;
}

@media (min-width: 768px) {
	.one-page-section * + .group-xl {
		margin-top: 60px;
	}
}

@media (min-width: 1200px) {
	.one-page-section * + .group-xl {
		margin-top: 100px;
	}
}

h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6 {
	margin-top: 0;
	margin-bottom: 0;
	font-family: "Roboto", Helvetica, Arial, sans-serif;
	font-weight: 700;
	color: #000;
}

h1 > span, h2 > span, h3 > span, h4 > span, h5 > span, h6 > span, .h1 > span, .h2 > span, .h3 > span, .h4 > span, .h5 > span, .h6 > span {
	display: inline-block;
	font-size: inherit;
}

h1 a, h2 a, h3 a, h4 a, h5 a, h6 a, .h1 a, .h2 a, .h3 a, .h4 a, .h5 a, .h6 a {
	display: inline;
	font: inherit;
	letter-spacing: inherit;
	transition: .33s all ease;
}

h1 a, h1 a:active, h1 a:focus, h2 a, h2 a:active, h2 a:focus, h3 a, h3 a:active, h3 a:focus, h4 a, h4 a:active, h4 a:focus, h5 a, h5 a:active, h5 a:focus, h6 a, h6 a:active, h6 a:focus, .h1 a, .h1 a:active, .h1 a:focus, .h2 a, .h2 a:active, .h2 a:focus, .h3 a, .h3 a:active, .h3 a:focus, .h4 a, .h4 a:active, .h4 a:focus, .h5 a, .h5 a:active, .h5 a:focus, .h6 a, .h6 a:active, .h6 a:focus {
	color: inherit;
}

h1 a:hover, h2 a:hover, h3 a:hover, h4 a:hover, h5 a:hover, h6 a:hover, .h1 a:hover, .h2 a:hover, .h3 a:hover, .h4 a:hover, .h5 a:hover, .h6 a:hover {
	color: <?php echo empty($website->maincolorbis) ? '#6ca' : '#'.$website->maincolorbis; ?>;
}

h1,
.h1 {
	font-size: 36px;
	line-height: 1.2;
	letter-spacing: -.025em;
}
h1.small,
.h1.small {
	font-size: 24px;
	line-height: 1.2;
}

@media (min-width: 768px) {
	h1,
	.h1 {
		font-size: 40px;
	}
    h1.small,
    .h1.small {
    	font-size: 40px;
    }
}

@media (min-width: 992px) {
	h1,
	.h1 {
		font-size: 70px;
	}
    h1.small,
    .h1.small {
    	font-size: 60px;
    }
}

@media (min-width: 1200px) {
	h1,
	.h1 {
		line-height: 1.07692;
		font-size: 104px;
	}
	h1.small,
	.h1.small {
		font-size: 72px;
		line-height: 1.2;
	}
}

h2,
.h2 {
	font-size: 32px;
	line-height: 1.4;
	letter-spacing: -.025em;
	text-transform: uppercase;
}

@media (min-width: 768px) {
	h2,
	.h2 {
		font-size: 32px;
	}
}

@media (min-width: 992px) {
	h2,
	.h2 {
		font-size: 40px;
	}
}

@media (min-width: 1200px) {
	h2,
	.h2 {
		line-height: 1.18644;
		font-size: 59px;
	}
}

h3.text-style-lighter,
.h3.text-style-lighter {
	font-weight: 400;
}

@media (min-width: 992px) {
	h3.text-style-lighter,
	.h3.text-style-lighter {
		font-size: 50px;
	}
}

h3,
.h3 {
	font-size: 24px;
	line-height: 1.35;
	text-transform: uppercase;
}

@media (min-width: 768px) {
	h3,
	.h3 {
		font-size: 26px;
	}
}

@media (min-width: 992px) {
	h3,
	.h3 {
		font-size: 30px;
	}
}

@media (min-width: 1200px) {
	h3,
	.h3 {
		line-height: 1.2;
		font-size: 45px;
	}
}

h4,
.h4 {
	font-size: 20px;
	line-height: 1.35;
}

@media (min-width: 768px) {
	h4,
	.h4 {
		font-size: 24px;
	}
}

@media (min-width: 992px) {
	h4,
	.h4 {
		font-size: 26px;
	}
}

@media (min-width: 1200px) {
	h4,
	.h4 {
		line-height: 1.58333;
		font-size: 24px;
	}
}

h5,
.h5 {
	font-size: 18px;
	line-height: 1.35;
}

@media (min-width: 1200px) {
	h5,
	.h5 {
		line-height: 1.2;
		font-size: 33px;
	}
}

h6,
.h6 {
	font-weight: 500;
	font-size: 15px;
	line-height: 1.2;
}

@media (min-width: 576px) {
	h6,
	.h6 {
		line-height: 1.33333;
		font-size: 18px;
	}
}

.text-bigger, .quote-default {
	font-size: 18px;
	font-weight: 300;
	line-height: 1.44;
}

@media (min-width: 768px) {
	.text-bigger, .quote-default {
		font-size: 20px;
	}
}

@media (min-width: 992px) {
	.text-bigger, .quote-default {
		font-size: 25px;
	}
}

.text-large {
	font: 700 38px/42px "Roboto", Helvetica, Arial, sans-serif;
}

@media (min-width: 992px) {
	.text-large {
		font-size: 48px;
	}
}

.text-extra-large-bordered {
	display: inline-block;
	padding: .07em 0.12em;
	font: 700 120px "Roboto", Helvetica, Arial, sans-serif;
	line-height: .8;
	border: .075em solid;
	text-align: center;
}

@media (min-width: 768px) {
	.text-extra-large-bordered {
		font-size: 220px;
	}
}

@media (min-width: 1200px) {
	.text-extra-large-bordered {
		font-size: 272px;
	}
}

.big {
	letter-spacing: .025em;
}

.text-big {
	font-size: 17px;
}

.text-big-22 {
	font-size: 22px;
}

.text-big-18 {
	font-size: 18px;
}

.text-big-19 {
	font-size: 19px;
}

.text-small {
	font-size: 12px;
}

.text-small-16 {
	font-size: 16px;
}

.h3-variant-2 {
	font-size: 36px;
	line-height: 1.2;
}

@media (min-width: 576px) {
	.big {
		font-size: 16px;
		line-height: 1.5;
		letter-spacing: 0;
	}
}

@media (min-width: 768px) {
	.big {
		font-size: 18px;
		line-height: 25px;
	}
}

small,
.small {
	font-size: 12px;
	line-height: 18px;
}

code {
	padding: 5px 7px;
	font-size: 75%;
	color: #fe4a21;
	background-color: #f9f9f9;
	border-radius: 2px;
}

em {
	font-family: Helvetica, Arial, sans-serif;
	font-size: inherit;
	font-style: italic;
	font-weight: 700;
	line-height: inherit;
	color: #767877;
}

mark,
.mark {
	color: #fff;
	background-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	padding: .2em .3em;
}

.text-style-1 {
	font-family: "Roboto", Helvetica, Arial, sans-serif;
	color: #9b9b9b;
}

.text-style-2 {
	font-family: Helvetica, Arial, sans-serif;
	font-style: italic;
	font-weight: 700;
}

address {
	margin-top: 0;
	margin-bottom: 0;
}

.context-dark, .bg-black, .bg-gray-darker, .bg-gray-dark, .bg-mine-shaft, .bg-cod-gray, .bg-accent, .bg-cello {
	color: rgba(255, 255, 255, 0.5);
}

.context-dark h1, .bg-black h1, .bg-gray-darker h1, .bg-gray-dark h1, .bg-mine-shaft h1, .bg-cod-gray h1, .bg-accent h1, .bg-cello h1, .context-dark h2, .bg-black h2, .bg-gray-darker h2, .bg-gray-dark h2, .bg-mine-shaft h2, .bg-cod-gray h2, .bg-accent h2, .bg-cello h2, .context-dark h3, .bg-black h3, .bg-gray-darker h3, .bg-gray-dark h3, .bg-mine-shaft h3, .bg-cod-gray h3, .bg-accent h3, .bg-cello h3, .context-dark h4, .bg-black h4, .bg-gray-darker h4, .bg-gray-dark h4, .bg-mine-shaft h4, .bg-cod-gray h4, .bg-accent h4, .bg-cello h4, .context-dark h5, .bg-black h5, .bg-gray-darker h5, .bg-gray-dark h5, .bg-mine-shaft h5, .bg-cod-gray h5, .bg-accent h5, .bg-cello h5, .context-dark h6, .bg-black h6, .bg-gray-darker h6, .bg-gray-dark h6, .bg-mine-shaft h6, .bg-cod-gray h6, .bg-accent h6, .bg-cello h6, .context-dark .h1, .bg-black .h1, .bg-gray-darker .h1, .bg-gray-dark .h1, .bg-mine-shaft .h1, .bg-cod-gray .h1, .bg-accent .h1, .bg-cello .h1, .context-dark .h2, .bg-black .h2, .bg-gray-darker .h2, .bg-gray-dark .h2, .bg-mine-shaft .h2, .bg-cod-gray .h2, .bg-accent .h2, .bg-cello .h2, .context-dark .h3, .bg-black .h3, .bg-gray-darker .h3, .bg-gray-dark .h3, .bg-mine-shaft .h3, .bg-cod-gray .h3, .bg-accent .h3, .bg-cello .h3, .context-dark .h4, .bg-black .h4, .bg-gray-darker .h4, .bg-gray-dark .h4, .bg-mine-shaft .h4, .bg-cod-gray .h4, .bg-accent .h4, .bg-cello .h4, .context-dark .h5, .bg-black .h5, .bg-gray-darker .h5, .bg-gray-dark .h5, .bg-mine-shaft .h5, .bg-cod-gray .h5, .bg-accent .h5, .bg-cello .h5, .context-dark .h6, .bg-black .h6, .bg-gray-darker .h6, .bg-gray-dark .h6, .bg-mine-shaft .h6, .bg-cod-gray .h6, .bg-accent .h6, .bg-cello .h6 {
	color: #fff;
}

.context-dark a, .bg-black a, .bg-gray-darker a, .bg-gray-dark a, .bg-mine-shaft a, .bg-cod-gray a, .bg-accent a, .bg-cello a, .context-dark a:active, .bg-black a:active, .bg-gray-darker a:active, .bg-gray-dark a:active, .bg-mine-shaft a:active, .bg-cod-gray a:active, .bg-accent a:active, .bg-cello a:active, .context-dark a:focus, .bg-black a:focus, .bg-gray-darker a:focus, .bg-gray-dark a:focus, .bg-mine-shaft a:focus, .bg-cod-gray a:focus, .bg-accent a:focus, .bg-cello a:focus {
	color: #fff;
}

.context-dark a:hover, .bg-black a:hover, .bg-gray-darker a:hover, .bg-gray-dark a:hover, .bg-mine-shaft a:hover, .bg-cod-gray a:hover, .bg-accent a:hover, .bg-cello a:hover {
	color: <?php echo empty($website->maincolorbis) ? '#6ca' : '#'.$website->maincolorbis; ?>;
}

.context-dark .big, .bg-black .big, .bg-gray-darker .big, .bg-gray-dark .big, .bg-mine-shaft .big, .bg-cod-gray .big, .bg-accent .big, .bg-cello .big,
.context-dark .text-bigger,
.bg-black .text-bigger,
.bg-gray-darker .text-bigger,
.bg-gray-dark .text-bigger,
.bg-mine-shaft .text-bigger,
.bg-cod-gray .text-bigger,
.bg-accent .text-bigger,
.bg-cello .text-bigger,
.context-dark .text-extra-large-bordered,
.bg-black .text-extra-large-bordered,
.bg-gray-darker .text-extra-large-bordered,
.bg-gray-dark .text-extra-large-bordered,
.bg-mine-shaft .text-extra-large-bordered,
.bg-cod-gray .text-extra-large-bordered,
.bg-accent .text-extra-large-bordered,
.bg-cello .text-extra-large-bordered {
	color: #fff;
}

.context-dark .countdown-wrap span, .bg-black .countdown-wrap span, .bg-gray-darker .countdown-wrap span, .bg-gray-dark .countdown-wrap span, .bg-mine-shaft .countdown-wrap span, .bg-cod-gray .countdown-wrap span, .bg-accent .countdown-wrap span, .bg-cello .countdown-wrap span,
.context-dark .countdown-wrap div > h4,
.bg-black .countdown-wrap div > h4,
.bg-gray-darker .countdown-wrap div > h4,
.bg-gray-dark .countdown-wrap div > h4,
.bg-mine-shaft .countdown-wrap div > h4,
.bg-cod-gray .countdown-wrap div > h4,
.bg-accent .countdown-wrap div > h4,
.bg-cello .countdown-wrap div > h4 {
	color: #fff;
}

.bg-black {
	background: #000;
	fill: #000;
}

.bg-gray-darker {
	background: #00030a;
	fill: #00030a;
}

.bg-gray-darker .countdown-wrap div > h4 {
	color: rgba(255, 255, 255, 0.2);
}

.bg-gray-dark {
	background: #2a2b2b;
	fill: #2a2b2b;
}

.bg-mine-shaft {
	background: #333;
	fill: #333;
}

.bg-cod-gray {
	background: #111;
	fill: #111;
}

.bg-gray {
	background: #9f9f9f;
	fill: #9f9f9f;
}

.bg-accent {
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	fill: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.bg-accent.bg-default-outline-btn .btn-white-outline:hover {
	background: #3a3c3e;
	border-color: #3a3c3e;
}

.bg-porcelain {
	background: #e5e7e9;
	fill: #e5e7e9;
}

.bg-gray-light {
	background: #dedede;
	fill: #dedede;
}

.bg-gray-lighter {
	background: #f9f9f9;
	fill: #f9f9f9;
}

.bg-whisper {
	background: #f6f7fa;
	fill: #f6f7fa;
}

.bg-whisper-lighten {
	background: #f2f3f8;
	fill: #f2f3f8;
}

.bg-athens-gray {
	background: #F8F9FB;
	fill: #F8F9FB;
}

.bg-iron {
	background: #dcdde0;
	fill: #dcdde0;
}

.bg-cello {
	background: #1e3953;
	fill: #1e3953;
}

.bg-cloud-burst {
	background: #1e354a;
	fill: #1e354a;
}

.bg-abbey {
	background: #464a4d;
	fill: #464a4d;
}

.bg-abbey-04 {
	background: rgba(70, 74, 77, 0.4);
	fill: rgba(70, 74, 77, 0.4);
}

.bg-athens-lighten {
	background: #f2f3f7;
	fill: #f2f3f7;
}

.bg-cape-cod {
	background: #444;
	fill: #3a3c3e;
}
#sectionfirstclass .bg-cape-cod {
	background: #fff;
	fill: #3a3c3e;
}

.bg-athens-gray {
	background: #F8F9FB;
	fill: #F8F9FB;
}

.page .bg-default-02 {
	background: rgba(255, 255, 255, 0.2);
	fill: rgba(255, 255, 255, 0.2);
}

.page .bg-cloud-burst a.text-bismark:hover, .page .bg-cloud-burst a.text-bismark:focus {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.bg-overlay-lighten-inverse-md {
	background: rgba(255, 255, 255, 0.5);
}

@media (min-width: 992px) {
	.bg-overlay-lighten-inverse-md {
		background: transparent;
	}
}

.bg-image {
	-webkit-background-size: cover;
	background-size: cover;
	background-position: center top;
	background-repeat: no-repeat;
}

.bg-image-centered {
	-webkit-background-size: auto;
	background-size: auto;
}

.bg-fixed {
	background-attachment: fixed;
	-webkit-background-size: cover;
	background-size: cover;
}

.bg-image-1 {
	-webkit-background-size: auto 100%;
	background-size: auto 100%;
}

@media (max-width: 767px) {
	.bg-image-1 {
		background-image: none !important;
	}
}

.page .text-primary {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?> !important;
}

.page a.text-primary:focus, .page a.text-primary:hover {
	color: <?php echo empty($website->maincolorbis) ? '#6ca' : '#'.$website->maincolorbis; ?> !important;
}

.page .text-secondary {
	color: #00030a !important;
}

.page a.text-secondary:focus, .page a.text-secondary:hover {
	color: black !important;
}

.page .text-red-orange {
	color: #ff4b22 !important;
}

.page a.text-red-orange:focus, .page a.text-red-orange:hover {
	color: #ee2c00 !important;
}

.page .text-black {
	color: #000 !important;
}

.page a.text-black:focus, .page a.text-black:hover {
	color: black !important;
}

.page .text-silver {
	color: #cdcdcd !important;
}

.page a.text-silver:focus, .page a.text-silver:hover {
	color: #b4b4b4 !important;
}

.page .text-dark {
	color: #2a2b2b !important;
}

.page a.text-dark:focus, .page a.text-dark:hover {
	color: #111111 !important;
}

.page .text-gray {
	color: #9f9f9f !important;
}

.page a.text-gray:focus, .page a.text-gray:hover {
	color: #868686 !important;
}

.page .text-gray-light {
	color: #dedede !important;
}

.page a.text-gray-light:focus, .page a.text-gray-light:hover {
	color: #c5c5c5 !important;
}

.page .text-white {
	color: #fff !important;
	text-shadow: 1px 1px 8px #222;
}

.page a.text-white:focus, .page a.text-white:hover {
	color: #e6e6e6 !important;
}

.page .text-white-05 {
	color: rgba(255, 255, 255, 0.5) !important;
}

.page a.text-white-05:focus, .page a.text-white-05:hover {
	color: rgba(230, 230, 230, 0.5) !important;
}

.page .text-white-03 {
	color: rgba(255, 255, 255, 0.3) !important;
}

.page a.text-white-03:focus, .page a.text-white-03:hover {
	color: rgba(230, 230, 230, 0.3) !important;
}

.page .text-white-08 {
	color: rgba(255, 255, 255, 0.8) !important;
}

.page a.text-white-08:focus, .page a.text-white-08:hover {
	color: rgba(230, 230, 230, 0.8) !important;
}

.page .text-tundora {
	color: #414141 !important;
}

.page a.text-tundora:focus, .page a.text-tundora:hover {
	color: #282828 !important;
}

.page .text-black-05 {
	color: rgba(0, 0, 0, 0.5) !important;
}

.page a.text-black-05:focus, .page a.text-black-05:hover {
	color: rgba(0, 0, 0, 0.5) !important;
}

.page .text-bismark {
	color: #496a8a !important;
}

.page a.text-bismark:focus, .page a.text-bismark:hover {
	color: #375069 !important;
}

.page .text-black-08 {
	color: rgba(0, 0, 0, 0.8) !important;
}

.page a.text-black-08:focus, .page a.text-black-08:hover {
	color: rgba(0, 0, 0, 0.8) !important;
}

.page .text-gray-darker {
	color: #00030a !important;
}

.page a.text-gray-darker:focus, .page a.text-gray-darker:hover {
	color: black !important;
}

.page .text-abbey {
	color: #464a4d !important;
}

.page a.text-abbey:focus, .page a.text-abbey:hover {
	color: #2e3032 !important;
}

.page .text-rolling-stone {
	color: #74787C !important;
}

.page a.text-rolling-stone:focus, .page a.text-rolling-stone:hover {
	color: #5b5f62 !important;
}

.page .text-fuel-yellow {
	color: #F0B922 !important;
}

.page a.text-fuel-yellow:focus, .page a.text-fuel-yellow:hover {
	color: #d19d0e !important;
}

.hidden {
	display: none;
}

.snackbars {
	max-width: 280px;
	padding: 9px 16px;
	margin-left: auto;
	margin-right: auto;
	color: #fff;
	text-align: left;
	background: #171717;
	border-radius: 0;
}

.snackbars .icon-xxs {
	position: relative;
	top: 2px;
	font-size: 20px;
	vertical-align: baseline;
}

.snackbars p span:last-child {
	padding-left: 14px;
}

.snackbars-left {
	display: inline-block;
	margin-bottom: 0;
}

.snackbars-right {
	display: inline-block;
	float: right;
	text-transform: uppercase;
}

.snackbars-right:hover {
	text-decoration: underline;
}

@media (min-width: 576px) {
	.snackbars {
		max-width: 380px;
		padding: 14px 17px;
	}
}

.text-italic {
	font-style: italic;
}

.text-normal {
	font-style: normal;
}

.text-none {
	text-transform: none;
}

.text-underline {
	text-decoration: underline;
}

.text-strike {
	text-decoration: line-through;
}

.text-thin {
	font-weight: 100;
}

.text-light {
	font-weight: 300;
}

.text-regular {
	font-weight: 400;
}

.text-medium {
	font-weight: 500;
}

.text-sbold {
	font-weight: 600;
}

.text-bold, strong {
	font-weight: 700;
}

.text-ubold {
	font-weight: 900;
}

.text-spacing-0 {
	letter-spacing: 0;
}

.text-spacing-40 {
	letter-spacing: 0.04em;
}

.text-spacing-inverse-20 {
	letter-spacing: -.02em;
}

.text-spacing-120 {
	letter-spacing: 0.12em;
}

.btn {
	max-width: 100%;
	font-family: "Roboto", Helvetica, Arial, sans-serif;
	font-size: 14px;
	font-weight: 700;
	border-radius: 0;
	border: 2px solid;
	text-transform: uppercase;
	transition: .3s ease-out;
	padding: 11px 15px;
}

@media (min-width: 992px) {
	.btn {
		padding: 12px 35px;
	}
}

.btn:focus, .btn:active, .btn:active:focus {
	outline: none;
}

.btn:active, .btn.active {
	box-shadow: none;
}

.btn-smaller {
	padding: 8px 25px;
}

.btn-small {
	padding-left: 20px;
	padding-right: 20px;
}

@media (min-width: 768px) {
	.btn {
		min-width: 190px;
	}
}

html .btn-default, html .btn-default:active, html .btn-default.active, html .btn-default:active:focus, html .btn-default.active:focus, html .btn-default:focus:active, html .btn-default:focus {
	color: #fff;
	background-color: #464a4d;
	border-color: #464a4d;
}

.open > html .btn-default.dropdown-toggle, html .btn-default:hover {
	color: #fff;
	background-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	border-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

html .btn-default.disabled, html .btn-default[disabled],
fieldset[disabled] html .btn-default {
	pointer-events: none;
	opacity: .5;
}

html .btn-default .badge {
	color: #464a4d;
	background-color: #fff;
}

html .btn-primary, html .btn-primary:active, html .btn-primary.active, html .btn-primary:active:focus, html .btn-primary.active:focus, html .btn-primary:focus:active, html .btn-primary:focus {
	color: #fff;
	background-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	border-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	/* border: 0; */
}

.open > html .btn-primary.dropdown-toggle {
	color: #fff;
	background-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	border-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	/* border: none; */
}
html .btn-primary:hover {
	color: #fff;
	box-shadow: 1px 1px 8px #aaa;
}

html .btn-primary.disabled, html .btn-primary[disabled],
fieldset[disabled] html .btn-primary {
	pointer-events: none;
	opacity: .5;
}

html .btn-primary .badge {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	background-color: #fff;
}

html .btn-primary-contrast, html .btn-primary-contrast:active, html .btn-primary-contrast.active, html .btn-primary-contrast:active:focus, html .btn-primary-contrast.active:focus, html .btn-primary-contrast:focus:active, html .btn-primary-contrast:focus {
	color: #fff;
	background-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	border-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.open > html .btn-primary-contrast.dropdown-toggle, html .btn-primary-contrast:hover {
	color: #fff;
	background-color: #42b294;
	border-color: #42b294;
}

html .btn-primary-contrast.disabled, html .btn-primary-contrast[disabled],
fieldset[disabled] html .btn-primary-contrast {
	pointer-events: none;
	opacity: .5;
}

html .btn-primary-contrast .badge {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	background-color: #fff;
}

html .btn-primary-outline, html .btn-primary-outline:active, html .btn-primary-outline.active, html .btn-primary-outline:active:focus, html .btn-primary-outline.active:focus, html .btn-primary-outline:focus:active, html .btn-primary-outline:focus {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	background-color: transparent;
	border-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.open > html .btn-primary-outline.dropdown-toggle, html .btn-primary-outline:hover {
	color: #fff;
	background-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	border-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

html .btn-primary-outline.disabled, html .btn-primary-outline[disabled],
fieldset[disabled] html .btn-primary-outline {
	pointer-events: none;
	opacity: .5;
}

html .btn-primary-outline .badge {
	color: transparent;
	background-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

html .btn-cello-outline, html .btn-cello-outline:active, html .btn-cello-outline.active, html .btn-cello-outline:active:focus, html .btn-cello-outline.active:focus, html .btn-cello-outline:focus:active, html .btn-cello-outline:focus {
	color: #1e3953;
	background-color: transparent;
	border-color: #1e3953;
}

.open > html .btn-cello-outline.dropdown-toggle, html .btn-cello-outline:hover {
	color: #fff;
	background-color: #1e3953;
	border-color: #1e3953;
}

html .btn-cello-outline.disabled, html .btn-cello-outline[disabled],
fieldset[disabled] html .btn-cello-outline {
	pointer-events: none;
	opacity: .5;
}

html .btn-cello-outline .badge {
	color: transparent;
	background-color: #1e3953;
}

html .btn-white-outline, html .btn-white-outline:active, html .btn-white-outline.active, html .btn-white-outline:active:focus, html .btn-white-outline.active:focus, html .btn-white-outline:focus:active, html .btn-white-outline:focus {
	color: #fff;
	background-color: transparent;
	border-color: #fff;
}

.open > html .btn-white-outline.dropdown-toggle, html .btn-white-outline:hover {
	color: #fff;
	background-color: <?php echo empty($website->maincolorbis) ? '#6ca' : '#'.$website->maincolorbis; ?>;
	border-color: <?php echo empty($website->maincolorbis) ? '#6ca' : '#'.$website->maincolorbis; ?>;
}

html .btn-white-outline.disabled, html .btn-white-outline[disabled],
fieldset[disabled] html .btn-white-outline {
	pointer-events: none;
	opacity: .5;
}

html .btn-white-outline .badge {
	color: transparent;
	background-color: #fff;
}

html .btn-white-outline-variant-1, html .btn-white-outline-variant-1:active, html .btn-white-outline-variant-1.active, html .btn-white-outline-variant-1:active:focus, html .btn-white-outline-variant-1.active:focus, html .btn-white-outline-variant-1:focus:active, html .btn-white-outline-variant-1:focus {
	color: #fff;
	background-color: transparent;
	border-color: #fff;
}

.open > html .btn-white-outline-variant-1.dropdown-toggle, html .btn-white-outline-variant-1:hover {
	color: #fff;
	background-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	border-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

html .btn-white-outline-variant-1.disabled, html .btn-white-outline-variant-1[disabled],
fieldset[disabled] html .btn-white-outline-variant-1 {
	pointer-events: none;
	opacity: .5;
}

html .btn-white-outline-variant-1 .badge {
	color: transparent;
	background-color: #fff;
}

html .btn-silver-outline, html .btn-silver-outline:active, html .btn-silver-outline.active, html .btn-silver-outline:active:focus, html .btn-silver-outline.active:focus, html .btn-silver-outline:focus:active, html .btn-silver-outline:focus {
	color: #000;
	background-color: transparent;
	border-color: #cdcdcd;
}

.open > html .btn-silver-outline.dropdown-toggle, html .btn-silver-outline:hover {
	color: #fff;
	background-color: #cdcdcd;
	border-color: #cdcdcd;
}

html .btn-silver-outline.disabled, html .btn-silver-outline[disabled],
fieldset[disabled] html .btn-silver-outline {
	pointer-events: none;
	opacity: .5;
}

html .btn-silver-outline .badge {
	color: transparent;
	background-color: #000;
}

html .btn-black-outline, html .btn-black-outline:active, html .btn-black-outline.active, html .btn-black-outline:active:focus, html .btn-black-outline.active:focus, html .btn-black-outline:focus:active, html .btn-black-outline:focus {
	color: #000;
	background-color: transparent;
	border-color: #000;
}

.open > html .btn-black-outline.dropdown-toggle, html .btn-black-outline:hover {
	color: #fff;
	background-color: #000;
	border-color: #000;
}

html .btn-black-outline.disabled, html .btn-black-outline[disabled],
fieldset[disabled] html .btn-black-outline {
	pointer-events: none;
	opacity: .5;
}

html .btn-black-outline .badge {
	color: transparent;
	background-color: #000;
}

html .btn-cello, html .btn-cello:active, html .btn-cello.active, html .btn-cello:active:focus, html .btn-cello.active:focus, html .btn-cello:focus:active, html .btn-cello:focus {
	color: #fff;
	background-color: #1e3953;
	border-color: #1e3953;
}

.open > html .btn-cello.dropdown-toggle, html .btn-cello:hover {
	color: #fff;
	background-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	border-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

html .btn-cello.disabled, html .btn-cello[disabled],
fieldset[disabled] html .btn-cello {
	pointer-events: none;
	opacity: .5;
}

html .btn-cello .badge {
	color: #1e3953;
	background-color: #fff;
}

.btn-xs {
	padding: 12px 25px;
	font-size: 11px;
	line-height: 1.71429;
	border-radius: 0;
}

@media (min-width: 768px) {
	.btn-xs {
		min-width: 165px;
	}
}

.btn-sm {
	padding: 10px 20px;
	font-size: 13px;
	line-height: 1.71429;
	border-radius: 0;
}

@media (min-width: 768px) {
	.btn-sm {
		min-width: 170px;
	}
}

.btn-lg {
	padding: 14px 30px;
	font-size: 14px;
	line-height: 1.71429;
	border-radius: 0;
}

@media (min-width: 768px) {
	.btn-lg {
		min-width: 270px;
		padding: 18px 40px;
	}
}

@media (min-width: 992px) {
	.btn-lg-bigger {
		padding-top: 28px;
		padding-bottom: 28px;
	}
}

.btn-xl {
	padding: 20px 35px;
	font-size: 15px;
	line-height: 1.71429;
	border-radius: 0;
}

@media (min-width: 768px) {
	.btn-xl {
		padding: 21px 50px;
	}
}

@media (min-width: 992px) {
	.btn-xl {
		min-width: 270px;
	}
}

.btn-min-width-0 {
	min-width: 0;
}

.btn-block {
	min-width: 30px;
	max-width: 100%;
}

.btn-rect {
	border-radius: 0;
}

.btn-round {
	border-radius: 12px;
}

.btn-circle {
	border-radius: 35px;
}

.btn-round-bottom {
	border-radius: 0 0 5px 5px;
}

.btn-shadow {
	box-shadow: -3px 3px 3px 0 rgba(0, 0, 0, 0.14);
}

.btn.btn-icon {
	display: -webkit-inline-box;
	display: -webkit-inline-flex;
	display: -ms-inline-flexbox;
	display: inline-flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: center;
	-ms-flex-pack: center;
	justify-content: center;
	vertical-align: middle;
}

.btn.btn-icon .icon {
	position: relative;
	top: 1px;
	display: inline-block;
	width: auto;
	height: auto;
	line-height: 0;
	vertical-align: middle;
	transition: 0s;
}

.btn.btn-icon-left .icon {
	margin-right: 10px;
}

.btn.btn-icon-right {
	-webkit-flex-direction: row-reverse;
	-ms-flex-direction: row-reverse;
	flex-direction: row-reverse;
}

.btn.btn-icon-right .icon {
	margin-left: 10px;
}

.btn-icon-only {
	background: none;
	border: none;
	display: inline-block;
	padding: 0;
	outline: none;
	outline-offset: 0;
	cursor: pointer;
	-webkit-appearance: none;
	font-size: 0;
	line-height: 0;
	transition: .33s all ease;
}

.btn-icon-only::-moz-focus-inner {
	border: none;
	padding: 0;
}

.btn-icon-only.btn-icon-only-primary, .btn-icon-only.btn-icon-only-primary:active, .btn-icon-only.btn-icon-only-primary:focus {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.btn-icon-only.btn-icon-only-primary:hover {
	color: #000;
}

.btn-icon-only {
	padding: 9px 18px;
}

.btn-icon-single {
	display: inline-block;
	padding: 0;
	min-width: 0;
}

.btn-icon-default {
	color: #000;
}

.btn-icon-default:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.btn-cello-outline.btn-icon .icon {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	transition: .33s all ease;
}

.btn-cello-outline.btn-icon:hover.btn-icon .icon {
	color: #fff;
}

.button-block * + .btn {
	margin-top: 0;
}

.icon {
	display: inline-block;
	text-align: center;
}

.icon:before {
	display: inline-block;
	font-weight: 400;
	font-style: normal;
	speak: none;
	text-transform: none;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
}

[class*='icon-circle'] {
	border-radius: 50%;
	overflow: hidden;
}

[class*='icon-round'] {
	border-radius: 4px;
	overflow: hidden;
}

.page .icon-default {
	color: #9f9f9f;
}

.page .icon-black {
	color: #000;
}

.page .icon-primary {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.page .icon-gunsmoke {
	color: #767877;
}

.page .icon-tundora {
	color: #414141;
}

.page .icon-gray-dark-filled {
	color: #fff;
	background: #2a2b2b;
}

.page .icon-san-juan-filled {
	color: #fff;
	background: #2e5275;
}

.page .icon-silver-chalice-filled {
	color: #fff;
	background: #ababab;
}

.page .icon-abbey-filled {
	color: #fff;
	background: #464a4d;
}

.page .icon-white {
	color: #fff;
}

.page a.icon-default, .page a.icon-default:active, .page a.icon-default:focus {
	color: #9f9f9f;
}

.page a.icon-default:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.page a.icon-primary, .page a.icon-primary:active, .page a.icon-primary:focus {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.page a.icon-primary:hover {
	color: #fff;
}

.page a.icon-abbey-filled:hover {
	color: #fff;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.page a.icon-tundora-inverse, .page a.icon-tundora-inverse:active, .page a.icon-tundora-inverse:focus {
	color: #414141;
}

.page a.icon-tundora-inverse:hover {
	color: #fff;
}

.page a.icon-gray-dark-filled, .page a.icon-gray-dark-filled:active, .page a.icon-gray-dark-filled:focus {
	color: #fff;
	background: #2a2b2b;
}

.page a.icon-gray-dark-filled:hover {
	color: #fff;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.page a.icon-silver-chalice-filled, .page a.icon-silver-chalice-filled:active, .page a.icon-silver-chalice-filled:focus {
	color: #fff;
	background: #ababab;
}

.page a.icon-silver-chalice-filled:hover {
	color: #fff;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.page a.icon-san-juan-filled, .page a.icon-san-juan-filled:active, .page a.icon-san-juan-filled:focus {
	color: #fff;
	background: #2e5275;
}

.page a.icon-san-juan-filled:hover {
	color: #fff;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.page .icon-xxs {
	width: 18px;
	height: 18px;
	font-size: 18px;
	line-height: 18px;
}

.page .icon-xxs-small {
	width: 16px;
	height: 16px;
	font-size: 16px;
	line-height: 16px;
}

.page .icon-xxs-smaller {
	width: 14px;
	height: 14px;
	font-size: 14px;
	line-height: 14px;
}

.page .icon-xxs-smallest {
	width: 12px;
	height: 12px;
	font-size: 12px;
	line-height: 12px;
}

.page .icon-xs {
	width: 22px;
	height: 22px;
	font-size: 22px;
	line-height: 22px;
}

.page .icon-xs-smaller {
	width: 20px;
	height: 20px;
	font-size: 20px;
	line-height: 20px;
}

.page .icon-sm {
	width: 24px;
	height: 24px;
	font-size: 24px;
	line-height: 24px;
}

.page .icon-sm-custom {
	width: 24px;
	height: 24px;
	font-size: 24px;
	line-height: 24px;
}

@media (min-width: 992px) {
	.page .icon-sm-custom {
		width: 30px;
		height: 30px;
		font-size: 30px;
		line-height: 30px;
	}
}

.page .icon-md {
	width: 36px;
	height: 36px;
	font-size: 36px;
	line-height: 36px;
}

.page .icon-md-custom {
	width: 26px;
	height: 26px;
	font-size: 26px;
	line-height: 26px;
}

@media (min-width: 992px) {
	.page .icon-md-custom {
		width: 36px;
		height: 36px;
		font-size: 36px;
		line-height: 36px;
	}
}

.page .icon-md-smaller {
	width: 30px;
	height: 30px;
	font-size: 30px;
	line-height: 30px;
}

.page .icon-lg {
	width: 45px;
	height: 45px;
	font-size: 45px;
	line-height: 45px;
}

.page .icon-lg-variant-1 {
	width: 42px;
	height: 42px;
	font-size: 42px;
	line-height: 42px;
}

.page .icon-lg-variant-2 {
	width: 44px;
	height: 44px;
	font-size: 44px;
	line-height: 44px;
}

.page .icon-lg-bigger {
	width: 50px;
	height: 50px;
	font-size: 50px;
	line-height: 50px;
}

.page .icon-xl {
	width: 60px;
	height: 60px;
	font-size: 60px;
	line-height: 60px;
}

.page [class*='icon-round'].icon-xxs-smallest,
.page [class*='icon-circle'].icon-xxs-smallest {
	width: 26px;
	height: 26px;
	line-height: 26px;
}

.icon-shift-1 {
	position: relative;
	top: 2px;
}

.icon-shift-2 {
	position: relative;
	top: 2px;
}

@media (min-width: 992px) {
	.icon-shift-2 {
		top: 4px;
	}
}

.icon-1:before,
.icon-2:before,
.icon-4:before,
.icon-5:before,
.icon-6:before,
.icon-3:before {
	content: '';
	display: inline-block;
	width: 40px;
	height: 40px;
}

.thumbnail {
	position: relative;
	z-index: 1;
	width: 100%;
	max-height: 100%;
	overflow: hidden;
	padding: 0;
	margin: 0;
	border: none;
	border-radius: 0;
	background-color: transparent;
}

.thumbnail .caption {
	padding: 0;
}

.thumbnail {
	box-shadow: none;
}

.thumbnail-variant-1 {
	background-color: transparent;
	text-align: center;
}

.thumbnail-variant-1 .thumbnail-image {
	position: relative;
	display: inline-block;
	overflow: hidden;
	pointer-events: none;
}

.thumbnail-variant-1 .thumbnail-image,
.thumbnail-variant-1 .thumbnail-image > img {
	border-radius: 600px;
}

.thumbnail-variant-1 .thumbnail-image > img {
	width: auto;
	pointer-events: auto;
}

.thumbnail-variant-1 .thumbnail-image-inner {
	position: absolute;
	top: 0;
	right: 1px;
	bottom: 0;
	left: 1px;
	z-index: 2;
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: center;
	-ms-flex-pack: center;
	justify-content: center;
	padding: 20px 5px 5px;
	background: rgba(0, 0, 0, 0.4);
	border-radius: 600px;
}

.thumbnail-variant-1 .thumbnail-image-inner * {
	pointer-events: auto;
}

.thumbnail-variant-1 .thumbnail-image-inner > * + * {
	margin-top: 0;
	margin-left: 20px;
}

.thumbnail-variant-1 .header {
	line-height: 1.2;
}

.thumbnail-variant-1 * + p {
	margin-top: 0;
}

.thumbnail-variant-1 * + .thumbnail-caption {
	margin-top: 18px;
}

@media (min-width: 992px) {
	.desktop .thumbnail-variant-1 .thumbnail-image-inner {
		opacity: 0;
		visibility: hidden;
		transform: rotate3d(0, 1, 0, 60deg);
		transition: .55s all ease;
		background: rgba(0, 0, 0, 0.6);
	}
	.desktop .thumbnail-variant-1 .thumbnail-image:hover .thumbnail-image-inner {
		opacity: 1;
		visibility: visible;
		transform: rotate3d(0, 1, 0, 0deg);
	}
}

@media (min-width: 1200px) {
	.thumbnail-variant-1 * + .thumbnail-caption {
		margin-top: 30px;
	}
}

.thumbnail-variant-2 {
	min-height: 300px;
	padding: 30px 0 0;
	overflow: visible;
	text-align: center;
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: column;
	-ms-flex-direction: column;
	flex-direction: column;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: flex-end;
	-ms-flex-pack: end;
	justify-content: flex-end;
}

.thumbnail-variant-2-wrap {
	padding-bottom: 25px;
}

.thumbnail-variant-2 .thumbnail-image {
	position: absolute;
	top: 0;
	right: 0;
	bottom: 0;
	left: 0;
	height: 100%;
	width: 100%;
	overflow: hidden;
}

.thumbnail-variant-2 .thumbnail-image > img {
	position: absolute;
	top: 20%;
	left: 50%;
	transform: translate(-50%, -20%);
	width: auto;
	min-width: 101%;
	max-width: none;
	height: auto;
	min-height: 100%;
	max-height: none;
}

.thumbnail-variant-2:before {
	content: '';
	position: absolute;
	top: 0;
	right: 0;
	bottom: 0;
	left: 0;
	z-index: 1;
	background: rgba(0, 0, 0, 0.5);
}

.thumbnail-variant-2 .thumbnail-inner {
	position: relative;
	z-index: 2;
	padding: 30px 10px;
}

.thumbnail-variant-2 .thumbnail-caption {
	position: relative;
	z-index: 3;
	width: calc(100% - 34px);
	padding: 17px 8px 25px;
	margin: 31px 17px -25px 17px;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.thumbnail-variant-2 .thumbnail-caption * {
	color: #fff;
}

.thumbnail-variant-2 .thumbnail-caption a, .thumbnail-variant-2 .thumbnail-caption a:active, .thumbnail-variant-2 .thumbnail-caption a:focus {
	color: #fff;
}

.thumbnail-variant-2 .thumbnail-caption a:hover {
	color: #9f9f9f;
}

.thumbnail-variant-2 .text-header {
	font-size: 18px;
	font-weight: 700;
}

.thumbnail-variant-2 .text-caption {
	font-style: italic;
	line-height: 1.3;
	font-family: "Roboto", Helvetica, Arial, sans-serif;
}

@media (min-width: 768px) {
	.thumbnail-variant-2 .text-caption {
		font-size: 16px;
	}
}

.thumbnail-variant-2 * + .divider {
	margin-top: 8px;
}

.thumbnail-variant-2 .divider + * {
	margin-top: 8px;
}

@media (min-width: 992px) {
	.desktop .thumbnail-variant-2:before {
		top: 40px;
	}
	.desktop .thumbnail-variant-2 .thumbnail-inner > * {
		position: relative;
		transform: translateY(14px);
		transition: .4s all ease-in-out;
	}
	.desktop .thumbnail-variant-2:before,
	.desktop .thumbnail-variant-2 .thumbnail-inner {
		opacity: 0;
		visibility: hidden;
		transition: .33s all ease-out;
	}
	.desktop .thumbnail-variant-2:hover:before {
		top: 0;
		left: 0;
		right: 0;
	}
	.desktop .thumbnail-variant-2:hover .thumbnail-inner > * {
		transform: translateY(0);
	}
	.desktop .thumbnail-variant-2:hover:before,
	.desktop .thumbnail-variant-2:hover .thumbnail-inner {
		opacity: 1;
		visibility: visible;
	}
}

@media (min-width: 992px) {
	.thumbnail-variant-2 .thumbnail-caption {
		width: calc(100% - 16px);
		margin: 31px 8px -25px 8px;
	}
}

@media (min-width: 1200px) {
	.thumbnail-variant-2 {
		width: calc(100% - 22px);
		margin: 0 11px 0;
	}
	.thumbnail-variant-2 .thumbnail-caption {
		width: calc(100% - 34px);
		margin: 31px 17px -25px 17px;
	}
}

.ie-11 .thumbnail-variant-2 {
	min-height: 0;
}

.thumbnail-variant-3 {
	width: 100.025%;
	text-align: center;
}

.thumbnail-variant-3 img {
	position: relative;
	left: 50%;
	transform: translateX(-50%);
	width: auto;
	max-width: none;
	min-width: 100.5%;
}

.thumbnail-variant-3 .link-external {
	position: absolute;
	top: -30px;
	right: -30px;
	z-index: 1;
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: center;
	-ms-flex-pack: center;
	justify-content: center;
	width: 200px;
	height: 110px;
	padding: 55px 15px 5px;
	vertical-align: bottom;
	line-height: 40px;
	background: #fafafa;
	transform-origin: 74% 110%;
	transform: rotate(45deg);
	will-change: transform;
	text-align: center;
	/**
      @bugfix: color flickering in child objects on hover
      @affected: IE Edge
    */
	transition: top 0.28s cubic-bezier(0.79, 0.14, 0.15, 0.86), right 0.28s cubic-bezier(0.79, 0.14, 0.15, 0.86), opacity 0.28s cubic-bezier(0.79, 0.14, 0.15, 0.86), visibility 0.28s cubic-bezier(0.79, 0.14, 0.15, 0.86);
}

.thumbnail-variant-3 .link-external .icon {
	transition: none;
	transform: rotate(-45deg);
	color: #000;
	vertical-align: bottom;
}

.thumbnail-variant-3 .link-external:hover {
	top: -12px;
	right: -12px;
}

.thumbnail-variant-3 .link-original {
	position: absolute;
	top: 0;
	right: 0;
	bottom: 0;
	left: 0;
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: flex-end;
	-ms-flex-align: end;
	align-items: flex-end;
	-webkit-justify-content: flex-start;
	-ms-flex-pack: start;
	justify-content: flex-start;
}

.thumbnail-variant-3 .link-original, .thumbnail-variant-3 .link-original:active, .thumbnail-variant-3 .link-original:focus, .thumbnail-variant-3 .link-original:hover {
	color: #fff;
}

.thumbnail-variant-3 .link-original:before {
	content: '\e8ff';
	position: relative;
	left: 20px;
	bottom: 30px;
	z-index: 3;
	font-family: 'Material Icons';
	font-size: 140px;
	line-height: 1;
	opacity: .2;
	transition: .33s all ease;
}

.thumbnail-variant-3 .caption {
	position: absolute;
	top: -2px;
	right: 0;
	bottom: -2px;
	left: 0;
	padding: 15px;
	transition: .33s all ease-in-out;
	background: rgba(0, 0, 0, 0.6);
}

@media (min-width: 992px) {
	.desktop .thumbnail-variant-3 figure img {
		will-change: transform;
		transition: .4s ease-out;
	}
	.desktop .thumbnail-variant-3 .caption,
	.desktop .thumbnail-variant-3 .link-external {
		opacity: 0;
		visibility: hidden;
	}
	.desktop .thumbnail-variant-3 .link-external {
		right: -50px;
		top: -50px;
	}
	.desktop .thumbnail-variant-3:hover .caption,
	.desktop .thumbnail-variant-3:hover .link-external {
		opacity: 1;
		visibility: visible;
	}
	.desktop .thumbnail-variant-3:hover figure img {
		transform: translateX(-50%) scale(1.08);
	}
	.desktop .thumbnail-variant-3:hover .link-external {
		right: -30px;
		top: -30px;
	}
	.desktop .thumbnail-variant-3:hover .link-external:hover {
		top: -20px;
		right: -20px;
	}
}

.thumbnail-variant-3 > * + * {
	margin-top: 0;
}

@media (min-width: 768px) {
	.thumbnail-wrap {
		padding: 0 5px;
	}
}

@media (min-width: 1200px) {
	.thumbnail-wrap {
		padding: 0 9px;
	}
}

.thumbnail-variant-4 {
	position: relative;
	overflow: hidden;
	box-shadow: 0px 0px 13px 0px rgba(1, 3, 4, 0.15);
}

.thumbnail-variant-4 .thumbnail-image {
	background: #000;
}

.thumbnail-variant-4 .thumbnail-image img {
	opacity: .92;
}

.thumbnail-variant-4 .caption {
	position: absolute;
	left: 0;
	right: 0;
	bottom: 0;
	padding: 16px 15px;
	text-align: center;
	color: #000;
	background: #fff;
}

.thumbnail-variant-4 .text-light {
	color: #0d0d0d;
}

@media (min-width: 992px) {
	.desktop .thumbnail-variant-4 .thumbnail-image img {
		position: relative;
		will-change: transform;
		opacity: 1;
		transition: opacity .7s, transform .7s;
		transform: scale3d(1.0001, 1.0001, 1);
	}
	.desktop .thumbnail-variant-4 .caption,
	.desktop .thumbnail-variant-4 .caption-header {
		transition: transform 0.55s;
		transform: translate3d(0, 200%, 0);
	}
	.desktop .thumbnail-variant-4 .caption-header {
		transition-delay: 0.05s;
	}
	.desktop .thumbnail-variant-4:hover .thumbnail-image img {
		opacity: .9;
		transform: scale3d(1.07, 1.07, 1);
	}
	.desktop .thumbnail-variant-4:hover .caption,
	.desktop .thumbnail-variant-4:hover .caption-header {
		transform: translate3d(0, 0, 0);
	}
}

@media (min-width: 992px) {
	.thumbnail-variant-4 .caption {
		padding: 20px 15px;
	}
}

.thumbnail-profile .thumbnail-image img {
	width: 100%;
}

.thumbnail-profile .thumbnail-caption {
	padding: 20px;
	background: #f2f3f7;
}

.thumbnail-profile .thumbnail-caption-inner {
	margin-bottom: -12px;
	-webkit-align-items: flex-end;
	-ms-flex-align: end;
	align-items: flex-end;
	transform: translateY(-12px);
	text-align: center;
}

.thumbnail-profile .thumbnail-caption-inner > * {
	display: inline-block;
	margin-top: 12px;
	-webkit-flex-shrink: 0;
	-ms-flex-negative: 0;
	flex-shrink: 0;
}

.thumbnail-profile .thumbnail-caption-inner, .thumbnail-profile .thumbnail-caption-inner > ul {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: center;
	-ms-flex-pack: center;
	justify-content: center;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: wrap;
	-ms-flex-wrap: wrap;
	flex-wrap: wrap;
}

.thumbnail-profile .thumbnail-caption-inner ul {
	position: relative;
	margin-bottom: -3px;
	transform: translateY(-3px);
	-webkit-flex-grow: 2;
	-ms-flex-positive: 2;
	flex-grow: 2;
}

.thumbnail-profile .thumbnail-caption-inner ul > li {
	display: inline-block;
	margin-top: 3px;
	padding: 0 7px;
}

.thumbnail-profile .thumbnail-caption-inner .btn-wrap {
	-webkit-flex-grow: 1;
	-ms-flex-positive: 1;
	flex-grow: 1;
}

@media (min-width: 576px) {
	.thumbnail-profile .thumbnail-caption-inner, .thumbnail-profile .thumbnail-caption-inner ul {
		-webkit-justify-content: center;
		-ms-flex-pack: center;
		justify-content: center;
	}
}

@media (min-width: 992px) {
	.thumbnail-profile .thumbnail-caption-inner ul {
		-webkit-justify-content: space-around;
		-ms-flex-pack: distribute;
		justify-content: space-around;
	}
}

@media (min-width: 1200px) {
	.thumbnail-profile .thumbnail-caption-inner {
		text-align: left;
		-webkit-justify-content: space-between;
		-ms-flex-pack: justify;
		justify-content: space-between;
	}
	.thumbnail-profile .thumbnail-caption-inner .btn-wrap {
		text-align: right;
	}
}

@media (max-width: 767px) {
	.thumbnail-variant-2 {
		max-width: 300px;
		margin-left: auto;
		margin-right: auto;
	}
	.thumbnail-variant-3,
	.thumbnail-profile {
		max-width: 370px;
		margin-left: auto;
		margin-right: auto;
	}
}

.thumbnail-block {
	display: block;
}

.thumbnail-block > img,
.thumbnail-block a > img {
	width: 100%;
	height: auto;
}

.thumbnail-variant-5 {
	padding: 40px 20px;
	display: inline-block;
}

.thumbnail-variant-5,
.thumbnail-variant-5 img {
	transition: .2s ease-in-out;
}

@media (min-width: 992px) {
	.thumbnail-variant-5 {
		border-top: 5px solid transparent;
		border-bottom: 5px solid transparent;
	}
	.thumbnail-variant-5 .thumbnail-variant-5-img-wrap {
		position: relative;
		display: inline-block;
	}
	.thumbnail-variant-5 .thumbnail-variant-5-img-wrap:before {
		content: '';
		position: absolute;
		top: 0;
		right: 0;
		left: 0;
		width: 100%;
		height: 100%;
		border-radius: 50%;
		background: rgba(0, 0, 0, 0.4);
		transition: .2s ease-in-out;
	}
	.thumbnail-variant-5:hover {
		box-shadow: 0 1px 4px 0 rgba(0, 0, 0, 0.15);
		border-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	}
	.thumbnail-variant-5:hover .thumbnail-variant-5-img-wrap:before {
		opacity: 0;
	}
	.thumbnail-variant-5:hover img {
		will-change: transform;
		-webkit-transform: scale(1.18);
		transform: scale(1.18);
	}
}

@media (min-width: 992px) {
	.thumbnail-variant-5 {
		padding: 40px 50px;
	}
}

@media (min-width: 1200px) {
	.thumbnail-variant-5 {
		padding: 65px 50px;
	}
}

.thumbnail-variant-5 * + h4 {
	margin-top: 36px;
}

.thumbnail-variant-5 h4 + * {
	margin-top: 0;
}

.thumbnail-variant-5 .link-group + .link-group {
	margin-top: 7px;
}

.thumbnail-variant-5 .divider-fullwidth {
	margin-top: 12px;
	margin-bottom: 17px;
}

.thumbnail-with-img * + .thumbnail-title {
	margin-top: 22px;
}

.thumbnail-with-img .thumbnail-title + * {
	margin-top: 10px;
}

.thumbnail-profile-info h4 + * {
	margin-top: 0;
}

.thumbnail-profile-info p + p {
	margin-top: 35px;
}

.thumbnail-profile-info * + .profile-quote {
	margin-top: 15px;
}

.thumbnail-profile-info .profile-quote + * {
	margin-top: 15px;
}

.thumbnail-profile-info * + .list-progress {
	margin-top: 35px;
}

@media (min-width: 992px) {
	.thumbnail-profile-info * + .profile-quote {
		margin-top: 0;
	}
	.thumbnail-profile-info .profile-quote + * {
		margin-top: 0;
	}
}

figure img {
	width: 100%;
	height: auto;
	max-width: none;
}

.figure .caption {
	padding: 15px;
}

.rd-mailform {
	position: relative;
}

label {
	margin-bottom: 0;
}

input::-webkit-autofill + .form-label {
	display: none;
	transition: none;
}

.form-label,
.form-input {
	font-weight: 400;
}

.input-sm,
.input-lg,
.form-input {
	font-size: 14px;
}

.input-sm, .input-sm:focus,
.input-lg,
.input-lg:focus,
.form-input,
.form-input:focus {
	box-shadow: none;
}

textarea.form-input {
	height: 166px;
	min-height: 52px;
	max-height: 249px;
	resize: vertical;
}

.form-input {
	height: auto;
	min-height: 52px;
	border: 0px solid #dedede;
	border-radius: 0;
	-webkit-appearance: none;
	line-height: 24px;
}

.form-input:focus {
	outline: 0;
}

.form-wrap {
	position: relative;
	margin-bottom: 0;
}

.form-wrap + .form-wrap {
	margin-top: 10px;
}

.form-label {
	position: absolute;
	top: 26px;
	left: 19px;
	font-size: 14px;
	color: #9f9f9f;
	pointer-events: none;
	z-index: 9;
	transition: .3s;
	transform: translateY(-50%);
	will-change: transform;
}

.form-label.focus {
	opacity: 0;
}

.form-label.auto-fill {
	color: #9f9f9f;
}

@media (min-width: 768px) {
	.form-label-outside {
		position: static;
		margin-bottom: 8px;
	}
	.form-label-outside, .form-label-outside.focus, .form-label-outside.auto-fill {
		transform: none;
		color: #9f9f9f;
		font-size: 14px;
	}
}

.form-wrap-outside {
	margin-top: 10px;
}

.form-wrap-outside .form-label-outside {
	position: absolute;
	top: -15px;
	left: 0;
}

.form-wrap-outside .form-label-outside.focus {
	opacity: 1;
}

@media (min-width: 768px) {
	.form-wrap-outside .form-label-outside {
		top: -30px;
	}
}

.form-border-bottom {
	border-bottom: 3px solid <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.form-validation {
	position: absolute;
	right: 10px;
	top: 2px;
	font-size: 11px;
	line-height: 11px;
	color: #fe4a21;
	margin-top: 2px;
	transition: .3s;
}

form.label-outside .form-validation {
	top: 12px;
}

.has-error .help-block,
.has-error .control-label,
.has-error .radio,
.has-error .checkbox,
.has-error .radio-inline,
.has-error .checkbox-inline,
.has-error.radio label,
.has-error.checkbox label,
.has-error.radio-inline label,
.has-error.checkbox-inline label {
	color: #fe4a21;
}

.has-error .form-input:not(.form-input-impressed), .has-error .form-input:not(.form-input-impressed):focus {
	border-color: #fe4a21;
	box-shadow: none;
}

.has-error .form-input-impressed, .has-error .form-input-impressed:focus {
	box-shadow: inset 0 0 0 1px #fe4a21;
}

.has-error .input-group-addon {
	color: #fff;
	border-color: #fe4a21;
	background-color: #fe4a21;
}

.form-inline .has-error ~ button[type='submit'] {
	border-color: #fe4a21;
	background: #fe4a21;
}

.has-error .form-validation {
	color: #fe4a21;
}

.has-success .help-block,
.has-success .control-label,
.has-success .radio,
.has-success .checkbox,
.has-success .radio-inline,
.has-success .checkbox-inline,
.has-success.radio label,
.has-success.checkbox label,
.has-success.radio-inline label,
.has-success.checkbox-inline label {
	color: #58c476;
}

.has-success .form-input:not(.form-input-impressed), .has-success .form-input:not(.form-input-impressed):focus {
	border-color: #dff0d8;
	box-shadow: none;
}

.has-success .form-input-impressed, .has-success .form-input-impressed:focus {
	box-shadow: inset 0 0 0 1px #dff0d8;
}

.has-success .input-group-addon {
	color: #fff;
	border-color: #dff0d8;
	background-color: #dff0d8;
}

.form-inline .has-success ~ button[type='submit'] {
	border-color: #dff0d8;
	background: #dff0d8;
}

.has-success .form-validation {
	color: #58c476;
}

.has-warning .help-block,
.has-warning .control-label,
.has-warning .radio,
.has-warning .checkbox,
.has-warning .radio-inline,
.has-warning .checkbox-inline,
.has-warning.radio label,
.has-warning.checkbox label,
.has-warning.radio-inline label,
.has-warning.checkbox-inline label {
	color: #c49558;
}

.has-warning .form-input:not(.form-input-impressed), .has-warning .form-input:not(.form-input-impressed):focus {
	border-color: #fcf8e3;
	box-shadow: none;
}

.has-warning .form-input-impressed, .has-warning .form-input-impressed:focus {
	box-shadow: inset 0 0 0 1px #fcf8e3;
}

.has-warning .input-group-addon {
	color: #fff;
	border-color: #fcf8e3;
	background-color: #fcf8e3;
}

.form-inline .has-warning ~ button[type='submit'] {
	border-color: #fcf8e3;
	background: #fcf8e3;
}

.has-warning .form-validation {
	color: #c49558;
}

.has-info .help-block,
.has-info .control-label,
.has-info .radio,
.has-info .checkbox,
.has-info .radio-inline,
.has-info .checkbox-inline,
.has-info.radio label,
.has-info.checkbox label,
.has-info.radio-inline label,
.has-info.checkbox-inline label {
	color: #3e9cf6;
}

.has-info .form-input:not(.form-input-impressed), .has-info .form-input:not(.form-input-impressed):focus {
	border-color: #d9edf7;
	box-shadow: none;
}

.has-info .form-input-impressed, .has-info .form-input-impressed:focus {
	box-shadow: inset 0 0 0 1px #d9edf7;
}

.has-info .input-group-addon {
	color: #fff;
	border-color: #d9edf7;
	background-color: #d9edf7;
}

.form-inline .has-info ~ button[type='submit'] {
	border-color: #d9edf7;
	background: #d9edf7;
}

.has-info .form-validation {
	color: #3e9cf6;
}

#form-output-global {
	position: fixed;
	bottom: 30px;
	left: 15px;
	visibility: hidden;
	transform: translateX(-500px);
	transition: .3s all ease;
	z-index: 9999999;
}

#form-output-global.active {
	transform: translateX(0);
	visibility: visible;
}

@media (min-width: 576px) {
	#form-output-global {
		left: 30px;
	}
}

.form-output {
	position: absolute;
	top: 100%;
	left: 0;
	font-size: 14px;
	line-height: 1.5;
	margin-top: 2px;
	transition: .3s;
	opacity: 0;
	visibility: hidden;
}

.form-output.active {
	opacity: 1;
	visibility: visible;
}

.form-output.error {
	color: #fe4a21;
}

.form-output.success {
	color: #58c476;
}

.radio .radio-custom,
.radio-inline .radio-custom,
.checkbox .checkbox-custom,
.checkbox-inline .checkbox-custom {
	opacity: 0;
}

.radio .radio-custom, .radio .radio-custom-dummy,
.radio-inline .radio-custom,
.radio-inline .radio-custom-dummy,
.checkbox .checkbox-custom,
.checkbox .checkbox-custom-dummy,
.checkbox-inline .checkbox-custom,
.checkbox-inline .checkbox-custom-dummy {
	position: absolute;
	width: 18px;
	height: 18px;
	margin-left: -20px;
	margin-top: 3px;
	outline: none;
	cursor: pointer;
}

.radio .radio-custom-dummy,
.radio-inline .radio-custom-dummy,
.checkbox .checkbox-custom-dummy,
.checkbox-inline .checkbox-custom-dummy {
	pointer-events: none;
}

.radio .radio-custom-dummy:after,
.radio-inline .radio-custom-dummy:after,
.checkbox .checkbox-custom-dummy:after,
.checkbox-inline .checkbox-custom-dummy:after {
	position: absolute;
	opacity: 0;
	transition: .22s;
}

.radio .radio-custom:focus,
.radio-inline .radio-custom:focus,
.checkbox .checkbox-custom:focus,
.checkbox-inline .checkbox-custom:focus {
	outline: none;
}

.radio-custom:checked + .radio-custom-dummy:after,
.checkbox-custom:checked + .checkbox-custom-dummy:after {
	opacity: 1;
}

.radio,
.radio-inline {
	padding-left: 30px;
}

.radio .radio-custom-dummy,
.radio-inline .radio-custom-dummy {
	margin-top: 2px;
	border-radius: 50%;
	margin-left: -30px;
	background: transparent;
	border: 2px solid #000;
}

.radio .radio-custom-dummy:after,
.radio-inline .radio-custom-dummy:after {
	content: '';
	top: 3px;
	right: 3px;
	bottom: 3px;
	left: 3px;
	background: #00030a;
	border-radius: 50%;
}

.form-wrap-color .radio-inline,
.form-wrap-size .radio-inline {
	padding-left: 0;
}

.form-wrap-color .radio-control,
.form-wrap-size .radio-control {
	position: relative;
	display: block;
	width: 24px;
	height: 24px;
	border-radius: 50%;
	margin-top: 23px;
	margin-bottom: 23px;
}

.form-wrap-color .radio-control:after,
.form-wrap-size .radio-control:after {
	bottom: 0;
}

.form-wrap-color .radio-control:after,
.form-wrap-size .radio-control:after {
	content: '';
	position: absolute;
	left: 50%;
	bottom: -23px;
	transform: translateX(-50%);
	width: 0;
	max-width: 100%;
	height: 3px;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	visibility: hidden;
	transition: .2s;
}

.form-wrap-color .radio-custom:checked ~ .radio-control:after,
.form-wrap-size .radio-custom:checked ~ .radio-control:after {
	visibility: visible;
	width: 100%;
}

.form-wrap-color .radio-custom-dummy,
.form-wrap-size .radio-custom-dummy {
	display: none;
}

.form-wrap-size .radio-inline {
	padding-left: 2px;
	padding-right: 2px;
}

.form-wrap-size .radio-inline + .radio-inline {
	margin-left: 1px;
}

.form-wrap-size .radio-control {
	color: #9f9f9f;
	text-align: center;
	text-transform: uppercase;
	transition: .2s;
}

.form-wrap-size .radio-control:hover {
	color: #000;
}

.form-wrap-size .radio-custom:checked ~ .radio-control {
	color: #000;
}

.checkbox,
.checkbox-inline {
	padding-left: 38px;
	color: #000;
}

.checkbox .checkbox-custom-dummy,
.checkbox-inline .checkbox-custom-dummy {
	pointer-events: none;
	border-radius: 2px;
	margin-left: 0;
	left: 0;
	background: #fff;
	box-shadow: none;
	border: 2px solid #dedede;
}

.checkbox .checkbox-custom-dummy:after,
.checkbox-inline .checkbox-custom-dummy:after {
	content: '\e5ca';
	font-family: 'Material Icons';
	font-size: 22px;
	line-height: 10px;
	position: absolute;
	top: 0;
	left: -1px;
	color: #2a2b2b;
}

.checkbox-small {
	padding-left: 26px;
}

.checkbox-small .checkbox-custom-dummy {
	margin-top: 6px;
	width: 12px;
	height: 12px;
	border-width: 1px;
	border-radius: 1px;
}

.checkbox-small .checkbox-custom-dummy:after {
	top: -1px;
	left: -2px;
	font-size: 18px;
}

.textarea-lined-wrap {
	position: relative;
	line-height: 2.39;
}

.textarea-lined-wrap textarea {
	height: 203px;
	resize: none;
	overflow: hidden;
	line-height: 2.39;
	background-color: transparent;
}

.textarea-lined-wrap-xs textarea {
	height: 68px;
}

.page .form-classic-bordered .form-label,
.page .form-classic-bordered .form-label-outside,
.page .form-classic-bordered .form-input {
	color: #000;
}

.page .form-classic-bordered .form-input {
	border: 1px solid #dedede;
}

.page .form-modern .form-input,
.page .form-modern .form-label {
	color: #9f9f9f;
}

.page .form-modern input {
	height: auto;
	min-height: 20px;
}

.page .form-modern .form-input:focus {
	border-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.page .form-modern .form-input {
	padding: 6px 0;
	border-radius: 0;
	border-width: 0 0 1px 0;
	border-color: #dedede;
	background-color: transparent;
}

.page .form-modern .form-label {
	left: 0;
	top: 18px;
}

.page .form-modern .form-validation {
	top: auto;
	left: auto;
	right: 0;
	bottom: -12px;
	font-style: italic;
}

.page .form-modern .has-error .help-block,
.page .form-modern .has-error .control-label,
.page .form-modern .has-error .radio,
.page .form-modern .has-error .checkbox,
.page .form-modern .has-error .radio-inline,
.page .form-modern .has-error .checkbox-inline,
.page .form-modern .has-error.radio label,
.page .form-modern .has-error.checkbox label,
.page .form-modern .has-error.radio-inline label,
.page .form-modern .has-error.checkbox-inline label {
	color: #fe4a21;
}

.page .form-modern .has-error .form-input:not(.form-input-impressed), .page .form-modern .has-error .form-input:not(.form-input-impressed):focus {
	border-color: #fe4a21;
	box-shadow: none;
}

.page .form-modern .has-error .form-input-impressed, .page .form-modern .has-error .form-input-impressed:focus {
	box-shadow: inset 0 0 0 1px #fe4a21;
}

.page .form-modern .has-error .input-group-addon {
	color: #fff;
	border-color: #fe4a21;
	background-color: #fe4a21;
}

.form-inline .page .form-modern .has-error ~ button[type='submit'] {
	border-color: #fe4a21;
	background: #fe4a21;
}

.page .form-modern .has-error .form-validation {
	color: #fe4a21;
}

.page .form-modern.form-darker .form-input,
.page .form-modern.form-darker .form-label {
	color: #000;
}

.page .form-modern.form-darker .form-label:not(.focus) + .form-input {
	border-color: #cdcdcd;
}

.page .form-modern.form-inverse .form-label,
.page .form-modern.form-inverse .form-input {
	color: #9f9f9f;
	background-color: transparent;
}

.page .form-modern.form-inverse .form-label.text-white-05,
.page .form-modern.form-inverse .form-input.text-white-05 {
	color: rgba(255, 255, 255, 0.5);
}

.form-classic.form-inline {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: stretch;
	-ms-flex-align: stretch;
	align-items: stretch;
	-webkit-justify-content: center;
	-ms-flex-pack: center;
	justify-content: center;
}

.form-classic.form-inline .btn {
	min-width: 0;
}

.form-classic.form-inline .btn-primary:hover {
	background: <?php echo empty($website->maincolorbis) ? '#6ca' : '#'.$website->maincolorbis; ?>;
}

.form-classic.form-inline .form-wrap {
	-webkit-flex-grow: 1;
	-ms-flex-positive: 1;
	flex-grow: 1;
	margin-right: -5px;
}

.form-classic.form-inline .form-input {
	width: 100%;
	border-radius: 5px 0 0 5px;
}

.form-classic.form-inline .btn {
	position: relative;
	z-index: 2;
	-webkit-flex-shrink: 0;
	-ms-flex-negative: 0;
	flex-shrink: 0;
	border-radius: 0 5px 5px 0;
}

.form-classic.form-inline .has-error + .form-input {
	border: 1px solid #fff;
}

.form-classic.form-inline .has-error .help-block,
.form-classic.form-inline .has-error .control-label,
.form-classic.form-inline .has-error .radio,
.form-classic.form-inline .has-error .checkbox,
.form-classic.form-inline .has-error .radio-inline,
.form-classic.form-inline .has-error .checkbox-inline,
.form-classic.form-inline .has-error.radio label,
.form-classic.form-inline .has-error.checkbox label,
.form-classic.form-inline .has-error.radio-inline label,
.form-classic.form-inline .has-error.checkbox-inline label {
	color: #fe4a21;
}

.form-classic.form-inline .has-error .form-input:not(.form-input-impressed), .form-classic.form-inline .has-error .form-input:not(.form-input-impressed):focus {
	border-color: #fe4a21;
	box-shadow: none;
}

.form-classic.form-inline .has-error .form-input-impressed, .form-classic.form-inline .has-error .form-input-impressed:focus {
	box-shadow: inset 0 0 0 1px #fe4a21;
}

.form-classic.form-inline .has-error .input-group-addon {
	color: #fff;
	border-color: #fe4a21;
	background-color: #fe4a21;
}

.form-inline .form-classic.form-inline .has-error ~ button[type='submit'] {
	border-color: #fe4a21;
	background: #fe4a21;
}

.form-classic.form-inline .has-error .form-validation {
	color: #fe4a21;
}

.form-classic.form-inline .form-validation {
	font-style: italic;
	top: auto;
	right: auto;
	left: 0;
	bottom: -15px;
}

.form-classic.form-inline > * + * {
	margin-top: 0;
}

.rd-mailform * + .button-block {
	margin-top: 30px;
}

* + .form-login {
	margin-top: 40px;
}

.form-login * + .form-wrap {
	margin-top: 22px;
}

.form-login * + .btn {
	margin-top: 30px;
}

.form-login * + .info-text {
	margin-top: 15px;
}

@media (min-width: 768px) {
	.form-login * + .btn {
		margin-top: 60px;
	}
}

.unit {
	display: flex;
	flex: 0 1 100%;
}

[class*='unit']:empty {
	margin-bottom: 0;
	margin-left: 0;
}

.unit-body {
	flex: 0 1 auto;
}

.unit-left,
.unit-right {
	flex: 0 0 auto;
	max-width: 100%;
}

.unit {
	margin-bottom: -30px;
	margin-left: -20px;
}

.unit > * {
	margin-bottom: 30px;
	margin-left: 20px;
}

@media (min-width: 576px) {
	.unit-sm {
		margin-bottom: -30px;
		margin-left: -20px;
	}
	.unit-sm > * {
		margin-bottom: 30px;
		margin-left: 20px;
	}
}

@media (min-width: 768px) {
	.unit-md {
		margin-bottom: -30px;
		margin-left: -20px;
	}
	.unit-md > * {
		margin-bottom: 30px;
		margin-left: 20px;
	}
}

@media (min-width: 992px) {
	.unit-lg {
		margin-bottom: -30px;
		margin-left: -20px;
	}
	.unit-lg > * {
		margin-bottom: 30px;
		margin-left: 20px;
	}
}

@media (min-width: 1200px) {
	.unit-xl {
		margin-bottom: -30px;
		margin-left: -20px;
	}
	.unit-xl > * {
		margin-bottom: 30px;
		margin-left: 20px;
	}
}

@media (min-width: 1800px) {
	.unit-xxl {
		margin-bottom: -30px;
		margin-left: -20px;
	}
	.unit-xxl > * {
		margin-bottom: 30px;
		margin-left: 20px;
	}
}

.unit-spacing-xs.unit {
	margin-bottom: -8px;
	margin-left: -8px;
}

.unit-spacing-xs.unit > * {
	margin-bottom: 8px;
	margin-left: 8px;
}

@media (min-width: 576px) {
	.unit-spacing-xs.unit {
		margin-bottom: -8px;
		margin-left: -8px;
	}
	.unit-spacing-xs.unit > * {
		margin-bottom: 8px;
		margin-left: 8px;
	}
}

@media (min-width: 768px) {
	.unit-spacing-xs.unit {
		margin-bottom: -8px;
		margin-left: -8px;
	}
	.unit-spacing-xs.unit > * {
		margin-bottom: 8px;
		margin-left: 8px;
	}
}

@media (min-width: 992px) {
	.unit-spacing-xs.unit {
		margin-bottom: -8px;
		margin-left: -8px;
	}
	.unit-spacing-xs.unit > * {
		margin-bottom: 8px;
		margin-left: 8px;
	}
}

@media (min-width: 1200px) {
	.unit-spacing-xs.unit {
		margin-bottom: -8px;
		margin-left: -8px;
	}
	.unit-spacing-xs.unit > * {
		margin-bottom: 8px;
		margin-left: 8px;
	}
}

@media (min-width: 1800px) {
	.unit-spacing-xs.unit {
		margin-bottom: -8px;
		margin-left: -8px;
	}
	.unit-spacing-xs.unit > * {
		margin-bottom: 8px;
		margin-left: 8px;
	}
}

.unit-spacing-sm.unit {
	margin-bottom: -15px;
	margin-left: -15px;
}

.unit-spacing-sm.unit > * {
	margin-bottom: 15px;
	margin-left: 15px;
}

@media (min-width: 576px) {
	.unit-spacing-sm.unit {
		margin-bottom: -15px;
		margin-left: -15px;
	}
	.unit-spacing-sm.unit > * {
		margin-bottom: 15px;
		margin-left: 15px;
	}
}

@media (min-width: 768px) {
	.unit-spacing-sm.unit {
		margin-bottom: -15px;
		margin-left: -15px;
	}
	.unit-spacing-sm.unit > * {
		margin-bottom: 15px;
		margin-left: 15px;
	}
}

@media (min-width: 992px) {
	.unit-spacing-sm.unit {
		margin-bottom: -15px;
		margin-left: -15px;
	}
	.unit-spacing-sm.unit > * {
		margin-bottom: 15px;
		margin-left: 15px;
	}
}

@media (min-width: 1200px) {
	.unit-spacing-sm.unit {
		margin-bottom: -15px;
		margin-left: -15px;
	}
	.unit-spacing-sm.unit > * {
		margin-bottom: 15px;
		margin-left: 15px;
	}
}

@media (min-width: 1800px) {
	.unit-spacing-sm.unit {
		margin-bottom: -15px;
		margin-left: -15px;
	}
	.unit-spacing-sm.unit > * {
		margin-bottom: 15px;
		margin-left: 15px;
	}
}

.unit-spacing-md.unit {
	margin-bottom: -22px;
	margin-left: -22px;
}

.unit-spacing-md.unit > * {
	margin-bottom: 22px;
	margin-left: 22px;
}

@media (min-width: 576px) {
	.unit-spacing-md.unit {
		margin-bottom: -22px;
		margin-left: -22px;
	}
	.unit-spacing-md.unit > * {
		margin-bottom: 22px;
		margin-left: 22px;
	}
}

@media (min-width: 768px) {
	.unit-spacing-md.unit {
		margin-bottom: -22px;
		margin-left: -22px;
	}
	.unit-spacing-md.unit > * {
		margin-bottom: 22px;
		margin-left: 22px;
	}
}

@media (min-width: 992px) {
	.unit-spacing-md.unit {
		margin-bottom: -22px;
		margin-left: -22px;
	}
	.unit-spacing-md.unit > * {
		margin-bottom: 22px;
		margin-left: 22px;
	}
}

@media (min-width: 1200px) {
	.unit-spacing-md.unit {
		margin-bottom: -22px;
		margin-left: -22px;
	}
	.unit-spacing-md.unit > * {
		margin-bottom: 22px;
		margin-left: 22px;
	}
}

@media (min-width: 1800px) {
	.unit-spacing-md.unit {
		margin-bottom: -22px;
		margin-left: -22px;
	}
	.unit-spacing-md.unit > * {
		margin-bottom: 22px;
		margin-left: 22px;
	}
}

.unit-spacing-lg.unit {
	margin-bottom: -30px;
	margin-left: -30px;
}

.unit-spacing-lg.unit > * {
	margin-bottom: 30px;
	margin-left: 30px;
}

@media (min-width: 576px) {
	.unit-spacing-lg.unit {
		margin-bottom: -30px;
		margin-left: -30px;
	}
	.unit-spacing-lg.unit > * {
		margin-bottom: 30px;
		margin-left: 30px;
	}
}

@media (min-width: 768px) {
	.unit-spacing-lg.unit {
		margin-bottom: -30px;
		margin-left: -30px;
	}
	.unit-spacing-lg.unit > * {
		margin-bottom: 30px;
		margin-left: 30px;
	}
}

@media (min-width: 992px) {
	.unit-spacing-lg.unit {
		margin-bottom: -30px;
		margin-left: -30px;
	}
	.unit-spacing-lg.unit > * {
		margin-bottom: 30px;
		margin-left: 30px;
	}
}

@media (min-width: 1200px) {
	.unit-spacing-lg.unit {
		margin-bottom: -30px;
		margin-left: -30px;
	}
	.unit-spacing-lg.unit > * {
		margin-bottom: 30px;
		margin-left: 30px;
	}
}

@media (min-width: 1800px) {
	.unit-spacing-lg.unit {
		margin-bottom: -30px;
		margin-left: -30px;
	}
	.unit-spacing-lg.unit > * {
		margin-bottom: 30px;
		margin-left: 30px;
	}
}

.unit-middle .unit-left {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: column;
	-ms-flex-direction: column;
	flex-direction: column;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: center;
	-ms-flex-pack: center;
	justify-content: center;
}

.stacktable {
	width: 100%;
	text-align: left;
}

.st-head-row {
	padding-top: 1em;
}

.st-head-row.st-head-row-main {
	font-size: 1.5em;
	padding-top: 0;
}

.st-key {
	width: 49%;
	text-align: right;
	padding-right: 1%;
}

.st-val {
	width: 49%;
	padding-left: 1%;
}

.stacktable.large-only {
	display: none;
}

.stacktable.small-only {
	display: table;
}

@media (min-width: 768px) {
	.stacktable.large-only {
		display: table;
	}
	.stacktable.small-only {
		display: none;
	}
}

.section-relative {
	position: relative;
}

@media (min-width: 768px) {
	.section-with-counters {
		padding-top: 1px;
		padding-bottom: 1px;
	}
	.section-with-counters > div {
		position: relative;
		box-shadow: 2px 2px 27px 0px rgba(1, 3, 4, 0.35);
		z-index: 2;
		margin-top: -30px;
		margin-bottom: -30px;
	}
}

@media (min-width: 768px) {
	.section-image-aside {
		position: relative;
	}
}

.section-image-aside-img {
	position: absolute;
	top: 0;
	bottom: 0;
	width: 190%;
	-webkit-background-size: cover;
	background-size: cover;
}

@media (min-width: 768px) {
	.section-image-aside-img {
		width: 50vw;
	}
}

.section-image-aside-left .section-image-aside-img {
	right: -50%;
}

@media (min-width: 768px) {
	.section-image-aside-left .section-image-aside-img {
		right: 0;
	}
}

.section-image-aside-right .section-image-aside-img {
	left: -50%;
}

@media (min-width: 768px) {
	.section-image-aside-right .section-image-aside-img {
		left: 0;
	}
}

.section-15 {
	padding-top: 15px;
	padding-bottom: 15px;
}

.section-30 {
	padding-top: 30px;
	padding-bottom: 30px;
}

.section-35 {
	padding-top: 35px;
	padding-bottom: 35px;
}

.section-40 {
	padding-top: 40px;
	padding-bottom: 40px;
}

.section-45 {
	padding-top: 45px;
	padding-bottom: 45px;
}

.section-50 {
	padding-top: 50px;
	padding-bottom: 50px;
}

.section-60 {
	padding-top: 60px;
	padding-bottom: 60px;
}

.section-66 {
	padding-top: 66px;
	padding-bottom: 66px;
}

.section-75 {
	padding-top: 75px;
	padding-bottom: 75px;
}

.section-90 {
	padding-top: 90px;
	padding-bottom: 90px;
}

.section-100 {
	padding-top: 100px;
	padding-bottom: 100px;
}

.section-120 {
	padding-top: 120px;
	padding-bottom: 120px;
}

.section-130 {
	padding-top: 130px;
	padding-bottom: 130px;
}

.section-145 {
	padding-top: 145px;
	padding-bottom: 145px;
}

.section-165 {
	padding-top: 165px;
	padding-bottom: 165px;
}

@media (min-width: 576px) {
	.section-sm-15 {
		padding-top: 15px;
		padding-bottom: 15px;
	}
	.section-sm-30 {
		padding-top: 30px;
		padding-bottom: 30px;
	}
	.section-sm-35 {
		padding-top: 35px;
		padding-bottom: 35px;
	}
	.section-sm-40 {
		padding-top: 40px;
		padding-bottom: 40px;
	}
	.section-sm-45 {
		padding-top: 45px;
		padding-bottom: 45px;
	}
	.section-sm-50 {
		padding-top: 50px;
		padding-bottom: 50px;
	}
	.section-sm-60 {
		padding-top: 60px;
		padding-bottom: 60px;
	}
	.section-sm-66 {
		padding-top: 66px;
		padding-bottom: 66px;
	}
	.section-sm-75 {
		padding-top: 75px;
		padding-bottom: 75px;
	}
	.section-sm-90 {
		padding-top: 90px;
		padding-bottom: 90px;
	}
	.section-sm-100 {
		padding-top: 100px;
		padding-bottom: 100px;
	}
	.section-sm-120 {
		padding-top: 120px;
		padding-bottom: 120px;
	}
	.section-sm-130 {
		padding-top: 130px;
		padding-bottom: 130px;
	}
	.section-sm-145 {
		padding-top: 145px;
		padding-bottom: 145px;
	}
	.section-sm-165 {
		padding-top: 165px;
		padding-bottom: 165px;
	}
}

@media (min-width: 768px) {
	.section-md-15 {
		padding-top: 15px;
		padding-bottom: 15px;
	}
	.section-md-30 {
		padding-top: 30px;
		padding-bottom: 30px;
	}
	.section-md-35 {
		padding-top: 35px;
		padding-bottom: 35px;
	}
	.section-md-40 {
		padding-top: 40px;
		padding-bottom: 40px;
	}
	.section-md-45 {
		padding-top: 45px;
		padding-bottom: 45px;
	}
	.section-md-50 {
		padding-top: 50px;
		padding-bottom: 50px;
	}
	.section-md-60 {
		padding-top: 60px;
		padding-bottom: 60px;
	}
	.section-md-66 {
		padding-top: 66px;
		padding-bottom: 66px;
	}
	.section-md-75 {
		padding-top: 75px;
		padding-bottom: 75px;
	}
	.section-md-90 {
		padding-top: 90px;
		padding-bottom: 90px;
	}
	.section-md-100 {
		padding-top: 100px;
		padding-bottom: 100px;
	}
	.section-md-120 {
		padding-top: 120px;
		padding-bottom: 120px;
	}
	.section-md-130 {
		padding-top: 130px;
		padding-bottom: 130px;
	}
	.section-md-145 {
		padding-top: 145px;
		padding-bottom: 145px;
	}
	.section-md-165 {
		padding-top: 165px;
		padding-bottom: 165px;
	}
}

@media (min-width: 992px) {
	.section-lg-15 {
		padding-top: 15px;
		padding-bottom: 15px;
	}
	.section-lg-30 {
		padding-top: 30px;
		padding-bottom: 30px;
	}
	.section-lg-35 {
		padding-top: 35px;
		padding-bottom: 35px;
	}
	.section-lg-40 {
		padding-top: 40px;
		padding-bottom: 40px;
	}
	.section-lg-45 {
		padding-top: 45px;
		padding-bottom: 45px;
	}
	.section-lg-50 {
		padding-top: 50px;
		padding-bottom: 50px;
	}
	.section-lg-60 {
		padding-top: 60px;
		padding-bottom: 60px;
	}
	.section-lg-66 {
		padding-top: 66px;
		padding-bottom: 66px;
	}
	.section-lg-75 {
		padding-top: 75px;
		padding-bottom: 75px;
	}
	.section-lg-90 {
		padding-top: 90px;
		padding-bottom: 90px;
	}
	.section-lg-100 {
		padding-top: 100px;
		padding-bottom: 100px;
	}
	.section-lg-120 {
		padding-top: 120px;
		padding-bottom: 120px;
	}
	.section-lg-130 {
		padding-top: 130px;
		padding-bottom: 130px;
	}
	.section-lg-145 {
		padding-top: 145px;
		padding-bottom: 145px;
	}
	.section-lg-165 {
		padding-top: 165px;
		padding-bottom: 165px;
	}
}

@media (min-width: 1200px) {
	.section-xl-15 {
		padding-top: 15px;
		padding-bottom: 15px;
	}
	.section-xl-30 {
		padding-top: 30px;
		padding-bottom: 30px;
	}
	.section-xl-35 {
		padding-top: 35px;
		padding-bottom: 35px;
	}
	.section-xl-40 {
		padding-top: 40px;
		padding-bottom: 40px;
	}
	.section-xl-45 {
		padding-top: 45px;
		padding-bottom: 45px;
	}
	.section-xl-50 {
		padding-top: 50px;
		padding-bottom: 50px;
	}
	.section-xl-60 {
		padding-top: 60px;
		padding-bottom: 60px;
	}
	.section-xl-66 {
		padding-top: 66px;
		padding-bottom: 66px;
	}
	.section-xl-75 {
		padding-top: 75px;
		padding-bottom: 75px;
	}
	.section-xl-90 {
		padding-top: 90px;
		padding-bottom: 90px;
	}
	.section-xl-100 {
		padding-top: 100px;
		padding-bottom: 100px;
	}
	.section-xl-120 {
		padding-top: 120px;
		padding-bottom: 120px;
	}
	.section-xl-130 {
		padding-top: 130px;
		padding-bottom: 130px;
	}
	.section-xl-145 {
		padding-top: 145px;
		padding-bottom: 145px;
	}
	.section-xl-165 {
		padding-top: 165px;
		padding-bottom: 165px;
	}
}

@media (min-width: 1800px) {
	.section-xxl-15 {
		padding-top: 15px;
		padding-bottom: 15px;
	}
	.section-xxl-30 {
		padding-top: 30px;
		padding-bottom: 30px;
	}
	.section-xxl-35 {
		padding-top: 35px;
		padding-bottom: 35px;
	}
	.section-xxl-40 {
		padding-top: 40px;
		padding-bottom: 40px;
	}
	.section-xxl-45 {
		padding-top: 45px;
		padding-bottom: 45px;
	}
	.section-xxl-50 {
		padding-top: 50px;
		padding-bottom: 50px;
	}
	.section-xxl-60 {
		padding-top: 60px;
		padding-bottom: 60px;
	}
	.section-xxl-66 {
		padding-top: 66px;
		padding-bottom: 66px;
	}
	.section-xxl-75 {
		padding-top: 75px;
		padding-bottom: 75px;
	}
	.section-xxl-90 {
		padding-top: 90px;
		padding-bottom: 90px;
	}
	.section-xxl-100 {
		padding-top: 100px;
		padding-bottom: 100px;
	}
	.section-xxl-120 {
		padding-top: 120px;
		padding-bottom: 120px;
	}
	.section-xxl-130 {
		padding-top: 130px;
		padding-bottom: 130px;
	}
	.section-xxl-145 {
		padding-top: 145px;
		padding-bottom: 145px;
	}
	.section-xxl-165 {
		padding-top: 165px;
		padding-bottom: 165px;
	}
}

.section-top-15 {
	padding-top: 15px;
}

.section-top-30 {
	padding-top: 30px;
}

.section-top-35 {
	padding-top: 35px;
}

.section-top-40 {
	padding-top: 40px;
}

.section-top-45 {
	padding-top: 45px;
}

.section-top-50 {
	padding-top: 50px;
}

.section-top-60 {
	padding-top: 60px;
}

.section-top-66 {
	padding-top: 66px;
}

.section-top-75 {
	padding-top: 75px;
}

.section-top-90 {
	padding-top: 90px;
}

.section-top-100 {
	padding-top: 100px;
}

.section-top-120 {
	padding-top: 120px;
}

.section-top-130 {
	padding-top: 130px;
}

.section-top-145 {
	padding-top: 145px;
}

.section-top-165 {
	padding-top: 165px;
}

@media (min-width: 576px) {
	.section-sm-top-15 {
		padding-top: 15px;
	}
	.section-sm-top-30 {
		padding-top: 30px;
	}
	.section-sm-top-35 {
		padding-top: 35px;
	}
	.section-sm-top-40 {
		padding-top: 40px;
	}
	.section-sm-top-45 {
		padding-top: 45px;
	}
	.section-sm-top-50 {
		padding-top: 50px;
	}
	.section-sm-top-60 {
		padding-top: 60px;
	}
	.section-sm-top-66 {
		padding-top: 66px;
	}
	.section-sm-top-75 {
		padding-top: 75px;
	}
	.section-sm-top-90 {
		padding-top: 90px;
	}
	.section-sm-top-100 {
		padding-top: 100px;
	}
	.section-sm-top-120 {
		padding-top: 120px;
	}
	.section-sm-top-130 {
		padding-top: 130px;
	}
	.section-sm-top-145 {
		padding-top: 145px;
	}
	.section-sm-top-165 {
		padding-top: 165px;
	}
}

@media (min-width: 768px) {
	.section-md-top-15 {
		padding-top: 15px;
	}
	.section-md-top-30 {
		padding-top: 30px;
	}
	.section-md-top-35 {
		padding-top: 35px;
	}
	.section-md-top-40 {
		padding-top: 40px;
	}
	.section-md-top-45 {
		padding-top: 45px;
	}
	.section-md-top-50 {
		padding-top: 50px;
	}
	.section-md-top-60 {
		padding-top: 60px;
	}
	.section-md-top-66 {
		padding-top: 66px;
	}
	.section-md-top-75 {
		padding-top: 75px;
	}
	.section-md-top-90 {
		padding-top: 90px;
	}
	.section-md-top-100 {
		padding-top: 100px;
	}
	.section-md-top-120 {
		padding-top: 120px;
	}
	.section-md-top-130 {
		padding-top: 130px;
	}
	.section-md-top-145 {
		padding-top: 145px;
	}
	.section-md-top-165 {
		padding-top: 165px;
	}
}

@media (min-width: 992px) {
	.section-lg-top-15 {
		padding-top: 15px;
	}
	.section-lg-top-30 {
		padding-top: 30px;
	}
	.section-lg-top-35 {
		padding-top: 35px;
	}
	.section-lg-top-40 {
		padding-top: 40px;
	}
	.section-lg-top-45 {
		padding-top: 45px;
	}
	.section-lg-top-50 {
		padding-top: 50px;
	}
	.section-lg-top-60 {
		padding-top: 60px;
	}
	.section-lg-top-66 {
		padding-top: 66px;
	}
	.section-lg-top-75 {
		padding-top: 75px;
	}
	.section-lg-top-90 {
		padding-top: 90px;
	}
	.section-lg-top-100 {
		padding-top: 100px;
	}
	.section-lg-top-120 {
		padding-top: 120px;
	}
	.section-lg-top-130 {
		padding-top: 130px;
	}
	.section-lg-top-145 {
		padding-top: 145px;
	}
	.section-lg-top-165 {
		padding-top: 165px;
	}
}

@media (min-width: 1200px) {
	.section-xl-top-15 {
		padding-top: 15px;
	}
	.section-xl-top-30 {
		padding-top: 30px;
	}
	.section-xl-top-35 {
		padding-top: 35px;
	}
	.section-xl-top-40 {
		padding-top: 40px;
	}
	.section-xl-top-45 {
		padding-top: 45px;
	}
	.section-xl-top-50 {
		padding-top: 50px;
	}
	.section-xl-top-60 {
		padding-top: 60px;
	}
	.section-xl-top-66 {
		padding-top: 66px;
	}
	.section-xl-top-75 {
		padding-top: 75px;
	}
	.section-xl-top-90 {
		padding-top: 90px;
	}
	.section-xl-top-100 {
		padding-top: 100px;
	}
	.section-xl-top-120 {
		padding-top: 120px;
	}
	.section-xl-top-130 {
		padding-top: 130px;
	}
	.section-xl-top-145 {
		padding-top: 145px;
	}
	.section-xl-top-165 {
		padding-top: 165px;
	}
}

@media (min-width: 1800px) {
	.section-xxl-top-15 {
		padding-top: 15px;
	}
	.section-xxl-top-30 {
		padding-top: 30px;
	}
	.section-xxl-top-35 {
		padding-top: 35px;
	}
	.section-xxl-top-40 {
		padding-top: 40px;
	}
	.section-xxl-top-45 {
		padding-top: 45px;
	}
	.section-xxl-top-50 {
		padding-top: 50px;
	}
	.section-xxl-top-60 {
		padding-top: 60px;
	}
	.section-xxl-top-66 {
		padding-top: 66px;
	}
	.section-xxl-top-75 {
		padding-top: 75px;
	}
	.section-xxl-top-90 {
		padding-top: 90px;
	}
	.section-xxl-top-100 {
		padding-top: 100px;
	}
	.section-xxl-top-120 {
		padding-top: 120px;
	}
	.section-xxl-top-130 {
		padding-top: 130px;
	}
	.section-xxl-top-145 {
		padding-top: 145px;
	}
	.section-xxl-top-165 {
		padding-top: 165px;
	}
}

.section-bottom-15 {
	padding-bottom: 15px;
}

.section-bottom-30 {
	padding-bottom: 30px;
}

.section-bottom-35 {
	padding-bottom: 35px;
}

.section-bottom-40 {
	padding-bottom: 40px;
}

.section-bottom-45 {
	padding-bottom: 45px;
}

.section-bottom-50 {
	padding-bottom: 50px;
}

.section-bottom-60 {
	padding-bottom: 60px;
}

.section-bottom-66 {
	padding-bottom: 66px;
}

.section-bottom-75 {
	padding-bottom: 75px;
}

.section-bottom-90 {
	padding-bottom: 90px;
}

.section-bottom-100 {
	padding-bottom: 100px;
}

.section-bottom-120 {
	padding-bottom: 120px;
}

.section-bottom-130 {
	padding-bottom: 130px;
}

.section-bottom-145 {
	padding-bottom: 145px;
}

.section-bottom-165 {
	padding-bottom: 165px;
}

@media (min-width: 576px) {
	.section-sm-bottom-15 {
		padding-bottom: 15px;
	}
	.section-sm-bottom-30 {
		padding-bottom: 30px;
	}
	.section-sm-bottom-35 {
		padding-bottom: 35px;
	}
	.section-sm-bottom-40 {
		padding-bottom: 40px;
	}
	.section-sm-bottom-45 {
		padding-bottom: 45px;
	}
	.section-sm-bottom-50 {
		padding-bottom: 50px;
	}
	.section-sm-bottom-60 {
		padding-bottom: 60px;
	}
	.section-sm-bottom-66 {
		padding-bottom: 66px;
	}
	.section-sm-bottom-75 {
		padding-bottom: 75px;
	}
	.section-sm-bottom-90 {
		padding-bottom: 90px;
	}
	.section-sm-bottom-100 {
		padding-bottom: 100px;
	}
	.section-sm-bottom-120 {
		padding-bottom: 120px;
	}
	.section-sm-bottom-130 {
		padding-bottom: 130px;
	}
	.section-sm-bottom-145 {
		padding-bottom: 145px;
	}
	.section-sm-bottom-165 {
		padding-bottom: 165px;
	}
}

@media (min-width: 768px) {
	.section-md-bottom-15 {
		padding-bottom: 15px;
	}
	.section-md-bottom-30 {
		padding-bottom: 30px;
	}
	.section-md-bottom-35 {
		padding-bottom: 35px;
	}
	.section-md-bottom-40 {
		padding-bottom: 40px;
	}
	.section-md-bottom-45 {
		padding-bottom: 45px;
	}
	.section-md-bottom-50 {
		padding-bottom: 50px;
	}
	.section-md-bottom-60 {
		padding-bottom: 60px;
	}
	.section-md-bottom-66 {
		padding-bottom: 66px;
	}
	.section-md-bottom-75 {
		padding-bottom: 75px;
	}
	.section-md-bottom-90 {
		padding-bottom: 90px;
	}
	.section-md-bottom-100 {
		padding-bottom: 100px;
	}
	.section-md-bottom-120 {
		padding-bottom: 120px;
	}
	.section-md-bottom-130 {
		padding-bottom: 130px;
	}
	.section-md-bottom-145 {
		padding-bottom: 145px;
	}
	.section-md-bottom-165 {
		padding-bottom: 165px;
	}
}

@media (min-width: 992px) {
	.section-lg-bottom-15 {
		padding-bottom: 15px;
	}
	.section-lg-bottom-30 {
		padding-bottom: 30px;
	}
	.section-lg-bottom-35 {
		padding-bottom: 35px;
	}
	.section-lg-bottom-40 {
		padding-bottom: 40px;
	}
	.section-lg-bottom-45 {
		padding-bottom: 45px;
	}
	.section-lg-bottom-50 {
		padding-bottom: 50px;
	}
	.section-lg-bottom-60 {
		padding-bottom: 60px;
	}
	.section-lg-bottom-66 {
		padding-bottom: 66px;
	}
	.section-lg-bottom-75 {
		padding-bottom: 75px;
	}
	.section-lg-bottom-90 {
		padding-bottom: 90px;
	}
	.section-lg-bottom-100 {
		padding-bottom: 100px;
	}
	.section-lg-bottom-120 {
		padding-bottom: 120px;
	}
	.section-lg-bottom-130 {
		padding-bottom: 130px;
	}
	.section-lg-bottom-145 {
		padding-bottom: 145px;
	}
	.section-lg-bottom-165 {
		padding-bottom: 165px;
	}
}

@media (min-width: 1200px) {
	.section-xl-bottom-15 {
		padding-bottom: 15px;
	}
	.section-xl-bottom-30 {
		padding-bottom: 30px;
	}
	.section-xl-bottom-35 {
		padding-bottom: 35px;
	}
	.section-xl-bottom-40 {
		padding-bottom: 40px;
	}
	.section-xl-bottom-45 {
		padding-bottom: 45px;
	}
	.section-xl-bottom-50 {
		padding-bottom: 50px;
	}
	.section-xl-bottom-60 {
		padding-bottom: 60px;
	}
	.section-xl-bottom-66 {
		padding-bottom: 66px;
	}
	.section-xl-bottom-75 {
		padding-bottom: 75px;
	}
	.section-xl-bottom-90 {
		padding-bottom: 90px;
	}
	.section-xl-bottom-100 {
		padding-bottom: 100px;
	}
	.section-xl-bottom-120 {
		padding-bottom: 120px;
	}
	.section-xl-bottom-130 {
		padding-bottom: 130px;
	}
	.section-xl-bottom-145 {
		padding-bottom: 145px;
	}
	.section-xl-bottom-165 {
		padding-bottom: 165px;
	}
}

@media (min-width: 1800px) {
	.section-xxl-bottom-15 {
		padding-bottom: 15px;
	}
	.section-xxl-bottom-30 {
		padding-bottom: 30px;
	}
	.section-xxl-bottom-35 {
		padding-bottom: 35px;
	}
	.section-xxl-bottom-40 {
		padding-bottom: 40px;
	}
	.section-xxl-bottom-45 {
		padding-bottom: 45px;
	}
	.section-xxl-bottom-50 {
		padding-bottom: 50px;
	}
	.section-xxl-bottom-60 {
		padding-bottom: 60px;
	}
	.section-xxl-bottom-66 {
		padding-bottom: 66px;
	}
	.section-xxl-bottom-75 {
		padding-bottom: 75px;
	}
	.section-xxl-bottom-90 {
		padding-bottom: 90px;
	}
	.section-xxl-bottom-100 {
		padding-bottom: 100px;
	}
	.section-xxl-bottom-120 {
		padding-bottom: 120px;
	}
	.section-xxl-bottom-130 {
		padding-bottom: 130px;
	}
	.section-xxl-bottom-145 {
		padding-bottom: 145px;
	}
	.section-xxl-bottom-165 {
		padding-bottom: 165px;
	}
}

html .group {
	-webkit-transform: translateY(-15px);
	transform: translateY(-15px);
	margin-bottom: -15px;
	margin-left: -15px;
}

html .group > *, html .group > *:first-child {
	display: inline-block;
	margin-top: 15px;
	margin-left: 15px;
}

html .group-xs {
	-webkit-transform: translateY(-5px);
	transform: translateY(-5px);
	margin-bottom: -5px;
	margin-left: -5px;
}

html .group-xs > *, html .group-xs > *:first-child {
	display: inline-block;
	margin-top: 5px;
	margin-left: 5px;
}

html .group-sm {
	-webkit-transform: translateY(-10px);
	transform: translateY(-10px);
	margin-bottom: -10px;
	margin-left: -10px;
}

html .group-sm > *, html .group-sm > *:first-child {
	display: inline-block;
	margin-top: 10px;
	margin-left: 10px;
}

html .group-md {
	-webkit-transform: translateY(-15px);
	transform: translateY(-15px);
	margin-bottom: -15px;
	margin-left: -15px;
}

html .group-md > *, html .group-md > *:first-child {
	display: inline-block;
	margin-top: 15px;
	margin-left: 15px;
}

html .group-lg {
	-webkit-transform: translateY(-20px);
	transform: translateY(-20px);
	margin-bottom: -20px;
	margin-left: -20px;
}

html .group-lg > *, html .group-lg > *:first-child {
	display: inline-block;
	margin-top: 20px;
	margin-left: 20px;
}

html .group-xl {
	-webkit-transform: translateY(-30px);
	transform: translateY(-30px);
	margin-bottom: -30px;
	margin-left: -30px;
}

html .group-xl > *, html .group-xl > *:first-child {
	display: inline-block;
	margin-top: 30px;
	margin-left: 30px;
}

html .group-top > *, html .group-top > *:first-child {
	vertical-align: top;
}

html .group-middle > *, html .group-middle > *:first-child {
	vertical-align: middle;
}

html .group-bottom > *, html .group-bottom > *:first-child {
	vertical-align: bottom;
}

html .group-inline > * {
	display: inline;
}

html .group-inline > *:not(:last-child) {
	margin-right: .25em;
}

html .group-xl-responsive {
	-webkit-transform: translateY(-18px);
	transform: translateY(-18px);
	margin-bottom: -18px;
	margin-left: -18px;
}

html .group-xl-responsive > *, html .group-xl-responsive > *:first-child {
	display: inline-block;
	margin-top: 18px;
	margin-left: 18px;
}

@media (min-width: 768px) {
	html .group-xl-responsive {
		-webkit-transform: translateY(-30px);
		transform: translateY(-30px);
		margin-bottom: -30px;
		margin-left: -30px;
	}
	html .group-xl-responsive > *, html .group-xl-responsive > *:first-child {
		display: inline-block;
		margin-top: 30px;
		margin-left: 30px;
	}
}

.group-flex-center {
	display: -webkit-inline-box;
	display: -webkit-inline-flex;
	display: -ms-inline-flexbox;
	display: inline-flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: wrap;
	-ms-flex-wrap: wrap;
	flex-wrap: wrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: center;
	-ms-flex-pack: center;
	justify-content: center;
}

.relative {
	position: relative;
}

.static {
	position: static;
}

.block-top-level {
	position: relative;
	z-index: 3;
}

.height-fill {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: column;
	-ms-flex-direction: column;
	flex-direction: column;
	-webkit-align-items: stretch;
	-ms-flex-align: stretch;
	align-items: stretch;
}

.height-fill > * {
	-webkit-flex-grow: 1;
	-ms-flex-positive: 1;
	flex-grow: 1;
}

.centered {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-justify-content: center;
	-ms-flex-pack: center;
	justify-content: center;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
}

.align-bottom {
	-webkit-align-self: flex-end;
	-ms-flex-item-align: end;
	align-self: flex-end;
}

.block-centered {
	margin-left: auto;
	margin-right: auto;
}

@media (max-width: 767px) {
	.responsive-centered {
		margin-left: auto;
		margin-right: auto;
	}
}

.overflow-hidden {
	overflow: hidden;
}

.page .white-space-normal {
	white-space: normal;
}

* + h1,
* + .h1 {
	margin-top: 10px;
}

* + h2,
* + .h2 {
	margin-top: 15px;
}

* + h3,
* + .h3 {
	margin-top: 20px;
}

@media (min-width: 768px) {
	* + h3,
	* + .h3 {
		margin-top: 27px;
	}
}

@media (min-width: 992px) {
	* + h3,
	* + .h3 {
		margin-top: 34px;
	}
}

* + h4,
* + .h4 {
	margin-top: 25px;
}

* + h5,
* + .h5 {
	margin-top: 17px;
}

* + h6,
* + .h6 {
	margin-top: 15px;
}

h1 + *,
.h1 + * {
	margin-top: 10px;
}

h2 + *,
.h2 + * {
	margin-top: 15px;
}

h3 + *,
.h3 + * {
	margin-top: 25px;
}

h4 + *,
.h4 + * {
	margin-top: 18px;
}

h5 + *,
.h5 + * {
	margin-top: 19px;
}

h6 + *,
.h6 + * {
	margin-top: 18px;
}

* + p,
* + p {
	margin-top: 14px;
}

* + .text-big {
	margin-top: 20px;
}

hr + * {
	margin-top: 18px;
}

@media (min-width: 1200px) {
	hr + * {
		margin-top: 26px;
	}
}

p + p {
	margin-top: 27px;
}

* + .big {
	margin-top: 6px;
}

* + .text-large {
	margin-top: 10px;
}

* + .text-bigger {
	margin-top: 28px;
}

* + .btn {
	margin-top: 30px;
}

@media (min-width: 1200px) {
	* + .btn {
		margin-top: 44px;
	}
}

* + .link {
	margin-top: 18px;
}

* + .contact-info {
	margin-top: 16px;
}

* + .list-inline {
	margin-top: 32px;
}

* + .list-terms {
	margin-top: 42px;
}

@media (min-width: 1200px) {
	* + .list-terms {
		margin-top: 62px;
	}
}

* + .list-marked,
* + .list-ordered {
	margin-top: 22px;
}

* + .link-wrap {
	margin-top: 8px;
}

* + .link-iconed {
	margin-top: 2px;
}

.contact-info {
	color: #00030a;
	vertical-align: baseline;
}

.contact-info a {
	display: inline-block;
}

.contact-info dl dt, .contact-info dl dd {
	display: inline-block;
}

.contact-info dl dt:after {
	content: ':';
	display: inline-block;
	text-align: center;
}

.contact-info .dl-inline dt {
	padding-right: 0;
}

.grid-system p {
	color: #00030a;
}

@media (max-width: 1199px) {
	.grid-system p {
		width: 100%;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	}
}

.object-inline,
.object-inline-baseline {
	white-space: nowrap;
}

.object-inline > * + *,
.object-inline-baseline > * + * {
	margin-top: 0;
	margin-left: 5px;
}

.object-inline {
	vertical-align: middle;
}

.object-inline > * {
	display: inline-block;
	vertical-align: middle;
}

.object-inline-baseline {
	vertical-align: baseline;
}

.object-inline-baseline > * {
	display: inline-block;
	vertical-align: baseline;
}

.row-no-gutter {
	margin-left: 0;
	margin-right: 0;
}

.row-no-gutter [class*='col'] {
	padding: 0;
}

.text-width-1 {
	max-width: 400px;
}

@media (min-width: 992px) {
	.text-width-1 {
		max-width: 310px;
	}
}

.min-width-1 {
	min-width: 100%;
}

@media (min-width: 576px) {
	.min-width-1 {
		min-width: 270px;
	}
}

.img-shadow {
	box-shadow: -3px 2px 4px 0px rgba(0, 0, 0, 0.58);
}

@media (min-width: 768px) {
	.img-shadow {
		box-shadow: -5px 4px 8px 0px rgba(0, 0, 0, 0.58);
	}
}

#bodywebsite .box {
	box-shadow: 0 5px 23px 0 rgba(0, 0, 0, 0.3);
	padding: 50px 30px;
	margin-top: 10px;
	margin-bottom: 10px;
}

@media (min-width: 992px) {
	.box {
		padding: 55px 30px 65px 44px;
	}
}

@media (min-width: 1200px) {
	.box {
		padding: 54px 40px 85px 54px;
	}
}

.box-xs {
	padding: 38px 20px;
}

.page .box-list-xs {
	box-shadow: 0 5px 13px 0 rgba(0, 0, 0, 0.2);
}

.page .box-list-xs .box-xs + .box-xs {
	border-top: 1px solid #1c2e3f;
}

@media (min-width: 768px) {
	.page .box-list-xs {
		max-width: 170px;
	}
}

.group-item {
	width: 100%;
	max-width: 220px;
	margin-left: auto;
	margin-right: auto;
}

@media (min-width: 576px) {
	.group-item {
		max-width: 300px;
	}
}

@media (min-width: 768px) {
	.group-item {
		min-width: 40%;
		max-width: 0;
	}
}

@media (min-width: 1200px) {
	.group-item {
		min-width: 272px;
	}
	.group-item-sm {
		min-width: 195px;
	}
}

@media (min-width: 1200px) {
	.border-modern {
		position: relative;
	}
	.border-modern .border-modern-item-1, .border-modern .border-modern-item-2, .border-modern .border-modern-item-3, .border-modern .border-modern-item-4 {
		position: absolute;
		width: 45px;
		height: 45px;
		border-left: 3px solid <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
		border-top: 3px solid <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	}
	.border-modern .border-modern-item-1, .border-modern .border-modern-item-2 {
		top: -27px;
	}
	.border-modern .border-modern-item-3, .border-modern .border-modern-item-4 {
		bottom: -68px;
	}
	.border-modern .border-modern-item-1, .border-modern .border-modern-item-3 {
		left: 0px;
	}
	.border-modern .border-modern-item-2, .border-modern .border-modern-item-4 {
		right: 0px;
	}
	.border-modern .border-modern-item-2 {
		transform: rotate(90deg);
	}
	.border-modern .border-modern-item-3 {
		transform: rotate(-90deg);
	}
	.border-modern .border-modern-item-4 {
		transform: rotate(180deg);
	}
}

.pagination-custom {
	position: relative;
	display: inline-block;
	position: relative;
	transform: translateY(-4px);
	margin-bottom: -4px;
}

.pagination-custom > * {
	margin-top: 4px;
}

.pagination-custom > *:not(:last-child) {
	margin-right: 4px;
}

.pagination-custom .page-item {
	display: inline-block;
	line-height: 1;
}

.pagination-custom .page-item:first-child .page-link, .pagination-custom .page-item:last-child .page-link {
	padding-left: 25px;
	padding-right: 25px;
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	border-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.pagination-custom .page-item .page-link {
	display: block;
	width: auto;
	min-width: 52px;
	height: 52px;
	padding: 10px 20px;
	border: 2px solid;
	border-radius: 0;
	font: 700 14px/14px "Roboto", Helvetica, Arial, sans-serif;
	text-transform: uppercase;
	vertical-align: middle;
}

.pagination-custom .page-item .page-link:after {
	content: '';
	height: 108%;
	width: 0;
	display: inline-block;
	vertical-align: middle;
}

.pagination-custom .page-item .page-link, .pagination-custom .page-item .page-link:active, .pagination-custom .page-item .page-link:focus {
	color: #000;
	background: transparent;
	border-color: #cdcdcd;
}

.pagination-custom .page-item .page-link:hover {
	color: #fff;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	border-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.pagination-custom .page-item.disabled,
.pagination-custom .page-item.active {
	pointer-events: none;
}

.pagination-custom .page-item.active .page-link {
	color: #fff;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	border-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.pagination-custom .page-item.disabled .page-link {
	color: #f9f9f9;
	background: #cdcdcd;
	border-color: #cdcdcd;
}

.label-custom {
	padding: .35em .3em .25em;
	font-weight: 400;
	font-size: 70%;
	text-transform: uppercase;
}

.mac .label-custom {
	padding-top: .4em;
}

.label-custom.label-danger {
	color: #fff;
	background: #fe4a21;
	box-shadow: inset 0 8px 12px rgba(0, 0, 0, 0.25);
}

.label-custom.label-info {
	color: #fff;
	background: #3e9cf6;
	box-shadow: inset 0 8px 12px rgba(0, 0, 0, 0.25);
}

blockquote {
	font: inherit;
	padding: 0;
	margin: 0;
	border: 0;
}

blockquote q:before, blockquote q:after {
	content: none;
}

blockquote cite {
	font-style: normal;
}

.quote-default {
	position: relative;
	padding: 43px 0 43px 6px;
	color: #00030a;
}

.quote-default svg {
	fill: #ddd;
}

.quote-default .quote-open,
.quote-default .quote-close {
	position: absolute;
	left: 30px;
}

.quote-default .quote-open {
	top: 0;
}

.quote-default .quote-close {
	bottom: 0;
}

.quote-bordered {
	padding-top: 14px;
}

.quote-bordered .quote-body {
	position: relative;
	padding-bottom: 10px;
}

.quote-bordered h6 {
	font-size: 18px;
}

.quote-bordered .quote-body-inner {
	position: relative;
	padding: 37px 22px 29px 34px;
	border-style: solid;
	border-width: 1px 1px 0 1px;
	border-color: #e5e7e9;
}

.quote-bordered .quote-body-inner:before, .quote-bordered .quote-body-inner:after {
	content: '';
	position: absolute;
	bottom: -10px;
	height: 10px;
	border-style: solid;
	border-color: #e5e7e9;
	background-color: transparent;
}

.quote-bordered .quote-body-inner:before {
	left: 10px;
	width: 46px;
	border-width: 1px 1px 0 0;
	transform: skew(45deg);
	transform-origin: 100% 100%;
}

.quote-bordered .quote-body-inner:after {
	right: 10px;
	width: calc(100% - 66px);
	border-width: 1px 0 0 1px;
	transform: skew(-45deg);
	transform-origin: 0 100%;
}

.quote-bordered .quote-open {
	position: absolute;
	top: -10px;
	left: 34px;
	z-index: 2;
}

.quote-bordered .quote-open > svg {
	fill: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.quote-bordered .quote-footer {
	padding-left: 25px;
}

.quote-bordered cite {
	font-size: 17px;
	font-weight: 900;
	line-height: 21px;
	color: #fff;
}

.quote-bordered * + .quote-footer {
	margin-top: 9px;
}

.quote-bordered cite + p {
	margin-top: 0;
}

.quote-bordered-inverse cite,
.quote-bordered-inverse q {
	color: #000;
}

.quote-minimal-bordered {
	position: relative;
	padding: 16px 0 26px;
	text-align: center;
}

.quote-minimal-bordered q {
	font: 400 20px "Roboto", Helvetica, Arial, sans-serif;
	font-style: italic;
	color: #464a4d;
}

.quote-minimal-bordered q:before, .quote-minimal-bordered q:after {
	content: '"';
}

.quote-minimal-bordered:before, .quote-minimal-bordered:after {
	content: '';
	position: absolute;
	left: 50%;
	width: 270px;
	height: 1px;
	transform: translateX(-50%);
	background: -moz-linear-gradient(left, rgba(255, 255, 255, 0) 0%, #dedede 50%, rgba(0, 0, 0, 0) 100%);
	background: -webkit-linear-gradient(left, rgba(255, 255, 255, 0) 0%, #dedede 50%, rgba(0, 0, 0, 0) 100%);
	background: linear-gradient(to right, rgba(255, 255, 255, 0) 0%, #dedede 50%, rgba(0, 0, 0, 0) 100%);
	filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#00ffffff', endColorstr='#00000000', GradientType=1);
}

.quote-minimal-bordered:before {
	top: 0;
}

.quote-minimal-bordered:after {
	bottom: 0;
}

@media (min-width: 768px) {
	.quote-minimal-bordered q {
		font-size: 24px;
		line-height: 1.55;
	}
}

@media (min-width: 1200px) {
	.quote-minimal-bordered q {
		font-size: 30px;
	}
}

.quote-minimal q {
	font-size: 18px;
	font-weight: 300;
	font-style: italic;
	line-height: 1.2;
	color: #000;
}

.quote-minimal cite {
	font: 700 15px "Roboto", Helvetica, Arial, sans-serif;
	line-height: 1.1;
	color: #000;
}

.quote-minimal .caption {
	color: #9f9f9f;
}

.quote-minimal.quote-minimal-inverse q {
	color: #fff;
}

.quote-minimal.quote-minimal-inverse cite {
	color: #fff;
}

.quote-minimal.quote-minimal-inverse .caption {
	color: rgba(255, 255, 255, 0.5);
}

.quote-minimal * + .caption {
	margin-top: 0;
}

.quote-minimal * + .quote-meta {
	margin-top: 20px;
}

.quote-strict q,
.quote-strict cite {
	color: #000;
}

.quote-strict q {
	font-size: 19px;
	font-weight: 300;
	font-style: italic;
	line-height: 28px;
}

.quote-strict cite {
	display: block;
	font: 700 16px/21px "Roboto", Helvetica, Arial, sans-serif;
	text-transform: uppercase;
}

.quote-strict * + cite {
	margin-top: 20px;
}

.quote-strict.quote-strict-inverse q,
.quote-strict.quote-strict-inverse cite {
	color: #fff;
}

.quote-vertical {
	max-width: 360px;
	margin-left: auto;
	margin-right: auto;
	text-align: center;
}

.quote-vertical q {
	font-size: 16px;
	line-height: 1.57895;
	font-weight: 100;
	color: rgba(0, 0, 0, 0.5);
}

.quote-vertical cite {
	display: block;
	color: #000;
	font: 700 14px/18px "Roboto", Helvetica, Arial, sans-serif;
}

.quote-vertical .quote-open > svg {
	fill: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.quote-vertical .quote-image,
.quote-vertical .quote-image > img {
	border-radius: 600px;
}

.quote-vertical .quote-image > img {
	width: auto;
}

.quote-vertical * + cite {
	margin-top: 16px;
}

.quote-vertical * + .caption {
	margin-top: 0;
}

.quote-vertical * + .quote-text {
	margin-top: 25px;
}

.quote-vertical * + .quote-meta {
	margin-top: 25px;
}

.quote-vertical.quote-vertical-inverse q,
.quote-vertical.quote-vertical-inverse cite {
	color: #fff;
}

.quote-vertical.quote-vertical-inverse .cite {
	color: rgba(255, 255, 255, 0.5);
}

.quote-vertical.quote-vertical-inverse .quote-open > svg {
	fill: #fff;
}

.quote-review cite {
	font: 700 14px/18px "Roboto", Helvetica, Arial, sans-serif;
	text-transform: uppercase;
	letter-spacing: -.025em;
	color: #000;
}

.quote-review .quote-header {
	position: relative;
	transform: translateY(-2px);
	margin-bottom: -2px;
}

.quote-review .quote-header > * {
	margin-top: 2px;
}

.quote-review .quote-header > *:not(:last-child) {
	margin-right: 10px;
}

.quote-review .quote-header > * {
	display: inline-block;
	vertical-align: middle;
}

.quote-review * + .quote-body {
	margin-top: 10px;
}

* + .quote-review {
	margin-top: 35px;
}

@media (min-width: 768px) {
	.quote-minimal q {
		font-size: 22px;
	}
	.quote-minimal cite {
		font-size: 19px;
	}
	.quote-minimal * + .quote-meta {
		margin-top: 37px;
	}
	* + .quote-review {
		margin-top: 45px;
	}
}

@media (min-width: 992px) {
	.quote-minimal q {
		font-size: 24px;
	}
	.quote-vertical q {
		font-size: 19px;
	}
}

.quote-left .divider-fullwidth {
	margin-top: 20px;
	background: #bcd;
}

.quote-left .quote-name {
	font-size: 18px;
	font-weight: 500;
	color: #fff;
}

@media (min-width: 992px) {
	.quote-left .quote-name {
		font-size: 24px;
	}
}

.quote-left .quote-desc-text {
	font-size: 26px;
	line-height: 1;
	font-style: italic;
	font-weight: 700;
}

@media (min-width: 992px) {
	.quote-left .quote-desc-text {
		font-size: 36px;
	}
}

.quote-left .quote-body {
	margin-top: 27px;
	padding-left: 75px;
	position: relative;
	text-align: left;
}

.quote-left .quote-body:before {
	content: '';
	position: absolute;
	top: 6px;
	left: 0;
	width: 50px;
	height: 36px;
	background: url("medias/image/<?php echo $website->ref; ?>/icon-quote.png") no-repeat top left;
	opacity: .5;
}

.quote-left .quote-body q {
	color: #fff;
}

.quote-left .h4 + *,
.quote-left h5 + * {
	margin-top: 0;
}

.page .box-text > * {
	display: inline;
	margin: 0 .25em 0 0;
}

.icon-box-horizontal .unit-left {
	min-width: 48px;
}

.icon-box-horizontal [class*='icon-md'] {
	margin-top: -2px;
}

.icon-box-horizontal [class*='icon-lg'] {
	margin-top: -5px;
}

.icon-box-horizontal * + p {
	margin-top: 9px;
}

.icon-box-vertical * + p {
	margin-top: 9px;
}

.icon-box-vertical-sm {
	max-width: 370px;
}

@media (max-width: 767px) {
	.icon-box-vertical-sm {
		margin-left: auto;
		margin-right: auto;
	}
}

.icon-box {
	position: relative;
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: column;
	-ms-flex-direction: column;
	flex-direction: column;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: center;
	-ms-flex-pack: center;
	justify-content: center;
	width: 100%;
	padding: 35px 30px;
	text-align: center;
	cursor: default;
}

@media (min-width: 768px) {
	.icon-box:before, .icon-box:after {
		content: '';
		position: absolute;
		width: 100%;
		height: 100%;
		border: 1px solid #e5e7e9;
		pointer-events: none;
		transition: .33s all ease;
	}
	.icon-box.icon-box-top-line:before {
		border-width: 1px 0 0 0;
	}
	.icon-box:before {
		top: 0;
		left: 0;
		border-width: 0 0 0 0;
	}
	.icon-box:after {
		bottom: 0;
		right: 0;
		border-width: 0 1px 1px 0;
	}
}

.icon-box .icon:after {
	opacity: 0;
}

.icon-box .btn:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.icon-box .divider {
	max-width: 100%;
	margin: 13px auto;
	transition: .33s all ease;
}

.icon-box .box-top,
.icon-box .box-body {
	position: relative;
	will-change: transform;
	transition: .33s all ease;
	-webkit-filter: blur(0);
}

.icon-box .box-top {
	top: 0;
}

.icon-box .box-body {
	max-width: 100%;
}

.icon-box .box-header {
	bottom: 0;
}

.icon-box .box-icon {
	min-height: 46px;
	display: -webkit-inline-box;
	display: -webkit-inline-flex;
	display: -ms-inline-flexbox;
	display: inline-flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: center;
	-ms-flex-pack: center;
	justify-content: center;
}

.icon-box * + .box-header {
	margin-top: 10px;
}

.icon-box * + .box-body {
	margin-top: 22px;
}

.icon-box .box-body + .btn {
	margin-top: 18px;
}

.icon-box.hover .box-top, .icon-box:hover .box-top {
	-webkit-transform: translateY(-7px);
	transform: translateY(-7px);
}

.icon-box.hover .btn,
.icon-box.hover .box-body, .icon-box:hover .btn,
.icon-box:hover .box-body {
	-webkit-transform: translateY(7px);
	transform: translateY(7px);
}

.icon-box.hover .divider, .icon-box:hover .divider {
	width: 168px;
}

@media (min-width: 992px) {
	.desktop .icon-box .icon-box-overlay {
		position: absolute;
		top: 0;
		bottom: 0;
		right: 0;
		left: 0;
		opacity: 0;
		background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
		transition: .2s ease-in-out;
	}
	.desktop .icon-box:hover .icon-box-overlay {
		opacity: 1;
		z-index: 5;
		-webkit-transform: scale(1.05);
		transform: scale(1.05);
	}
	.desktop .icon-box:hover .btn {
		z-index: 6;
	}
	.desktop .icon-box:hover .box-body,
	.desktop .icon-box:hover .box-top {
		z-index: 6;
	}
}

@media (min-width: 768px) {
	.icon-box {
		padding: 67px 37px 61px;
		margin-left: auto;
		margin-right: auto;
	}
}

@media (min-width: 1400px) {
	.icon-box {
		padding: 67px 110px 61px;
	}
}

@media (min-width: 1800px) {
	.icon-box {
		padding: 90px 165px 82px;
	}
}

.list-blocks {
	counter-reset: li;
}

.list-blocks > li {
	display: block;
}

.list-blocks .block-list-counter:before {
	position: relative;
	content: counter(li, decimal-leading-zero);
	counter-increment: li;
	font: 700 30px/30px "Roboto", Helvetica, Arial, sans-serif;
	letter-spacing: -.025em;
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.list-blocks > li + li {
	margin-top: 50px;
}

.block-image-plate {
	display: block;
	width: 100%;
}

.block-image-plate .block-header {
	max-width: 400px;
}

.block-image-plate .block-inner {
	position: relative;
	padding: 45px 30px;
}

.block-image-plate .block-inner:after {
	content: '';
	position: absolute;
	top: 0;
	right: 0;
	bottom: 0;
	left: 0;
	z-index: 0;
	background: rgba(0, 0, 0, 0.7);
}

.block-image-plate .block-inner > * {
	position: relative;
	z-index: 2;
}

.block-image-plate * + .block-text {
	margin-top: 18px;
}

.block-image-plate * + .block-body {
	margin-top: 22px;
}

@media (max-width: 767px) {
	.block-image-plate {
		margin-left: -16px;
		margin-right: -15px;
		width: calc(100% + 32px);
	}
}

@media (min-width: 768px) {
	.block-image-plate .block-header {
		max-width: 340px;
	}
	.block-image-plate .block-header h3 {
		line-height: 1.2;
	}
	.block-image-plate .block-inner {
		padding: 60px 12.5% 60px 8.33333%;
	}
	.block-image-plate .block-body {
		display: -ms-flexbox;
		display: -webkit-flex;
		display: flex;
		-webkit-flex-direction: row;
		-ms-flex-direction: row;
		flex-direction: row;
		-webkit-flex-wrap: nowrap;
		-ms-flex-wrap: nowrap;
		flex-wrap: nowrap;
		-webkit-align-items: flex-start;
		-ms-flex-align: start;
		align-items: flex-start;
		-webkit-justify-content: center;
		-ms-flex-pack: center;
		justify-content: center;
	}
	.block-image-plate .block-left {
		-webkit-flex-shrink: 0;
		-ms-flex-negative: 0;
		flex-shrink: 0;
		-webkit-flex-basis: 11.11111%;
		-ms-flex-preferred-size: 11.11111%;
		flex-basis: 11.11111%;
		max-width: 11.11111%;
		max-width: 100px;
	}
	.block-image-plate .block-body {
		-webkit-flex-grow: 1;
		-ms-flex-positive: 1;
		flex-grow: 1;
	}
	.block-image-plate * + .block-text {
		margin-top: 0;
	}
}

@media (min-width: 992px) {
	.block-image-plate .block-header {
		max-width: 410px;
	}
	.block-image-plate .block-inner {
		padding-right: 16%;
		padding-top: 90px;
		padding-bottom: 95px;
	}
}

.block-vacation {
	position: relative;
	width: 100%;
	padding: 39px 9% 45px;
	border-radius: 4px;
	background: #fff;
	box-shadow: -1px 0px 10px 0px rgba(65, 65, 65, 0.12);
}

.block-vacation, .block-vacation:active, .block-vacation:focus, .block-vacation:hover {
	color: #9f9f9f;
}

.block-vacation:hover {
	box-shadow: -3px 5px 12px 0px rgba(65, 65, 65, 0.16);
}

.block-vacation * + .block-meta {
	margin-top: 14px;
}

@media (min-width: 1200px) {
	.block-vacation * + .block-meta {
		margin-top: 5px;
	}
}

.block-shadow {
	position: relative;
	width: 100%;
	padding-top: 30px;
	overflow: hidden;
	border-radius: 0;
	background: #fff;
	box-shadow: 0px 1px 10px 0px rgba(65, 65, 65, 0.12);
	text-align: center;
}

.block-shadow .block-inner {
	padding: 0 40px;
}

.block-shadow * + .block-footer {
	margin-top: 32px;
}

.block-shadow * + .icon-block {
	margin-top: 40px;
}

@media (min-width: 768px) {
	.block-shadow {
		padding-top: 38px;
	}
	.block-shadow .block-inner {
		padding: 0 70px;
	}
	.block-shadow * + .icon-block {
		margin-top: 60px;
	}
}

.box-counter {
	text-align: center;
}

.box-counter .box-header {
	text-transform: uppercase;
}

.box-counter * + .box-header {
	margin-top: 10px;
}

@media (min-width: 768px) and (max-width: 1199px) {
	.box-counter .box-header {
		font-size: 15px;
	}
}

.box-counter-inverse .box-header {
	color: rgba(255, 255, 255, 0.2);
}

.box-counter-inverse .counter {
	color: #dedede;
}

.box-counter-inverse-lighter .box-header {
	color: rgba(255, 255, 255, 0.35);
}

.box-counter-inverse-lighter .counter {
	color: #dedede;
}

.box-container-small {
	display: inline-block;
	width: 100%;
	max-width: 280px;
}


.post-single .post-footer {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: wrap;
	-ms-flex-wrap: wrap;
	flex-wrap: wrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: space-between;
	-ms-flex-pack: justify;
	justify-content: space-between;
	position: relative;
	transform: translateY(-10px);
	margin-bottom: -10px;
}

.post-single .post-footer > * {
	margin-top: 10px;
}

.post-single .post-footer > *:not(:last-child) {
	margin-right: 20px;
}

.post-single * + .post-header {
	margin-top: 15px;
}

.post-single * + .post-meta {
	margin-top: 20px;
}

.post-single * + .post-body {
	margin-top: 20px;
}

.post-single * + .post-footer {
	margin-top: 42px;
}

.post-single + * {
	margin-top: 40px;
}

@media (min-width: 768px) {
	.post-single * + .post-header {
		margin-top: 22px;
	}
	.post-single * + .post-meta {
		margin-top: 10px;
	}
}

.post-info * + .post-main {
	margin-top: 30px;
}

.post-info * + .post-body {
	margin-top: 20px;
}

@media (min-width: 768px) {
	.post-info .post-main {
		display: -ms-flexbox;
		display: -webkit-flex;
		display: flex;
		-webkit-flex-direction: row;
		-ms-flex-direction: row;
		flex-direction: row;
		-webkit-flex-wrap: nowrap;
		-ms-flex-wrap: nowrap;
		flex-wrap: nowrap;
	}
	.post-info .post-left {
		-webkit-flex-basis: 33.33333%;
		-ms-flex-preferred-size: 33.33333%;
		flex-basis: 33.33333%;
		max-width: 33.33333%;
		padding-right: 25px;
	}
	.post-info .post-body {
		-webkit-flex-basis: 66.66667%;
		-ms-flex-preferred-size: 66.66667%;
		flex-basis: 66.66667%;
		max-width: 66.66667%;
	}
	.post-info * + .post-body {
		margin-top: 0;
	}
}

.post-minimal {
	position: relative;
	border-radius: 4px;
	overflow: hidden;
	background: #fff;
	box-shadow: -1px 0px 10px 0px rgba(65, 65, 65, 0.12);
}

.post-minimal .post-body {
	padding: 20px;
}

.post-minimal * + p {
	margin-top: 8px;
}

.post-minimal * + .post-meta {
	margin-top: 5px;
}

@media (max-width: 575px) {
	.post-minimal {
		display: inline-block;
		width: 100%;
		max-width: 300px;
	}
}

@media (min-width: 576px) {
	.post-minimal {
		display: -ms-flexbox;
		display: -webkit-flex;
		display: flex;
		-webkit-flex-direction: row;
		-ms-flex-direction: row;
		flex-direction: row;
		-webkit-flex-wrap: nowrap;
		-ms-flex-wrap: nowrap;
		flex-wrap: nowrap;
		-webkit-align-items: center;
		-ms-flex-align: center;
		align-items: center;
		-webkit-justify-content: center;
		-ms-flex-pack: center;
		justify-content: center;
	}
	.post-minimal .post-left {
		display: -ms-flexbox;
		display: -webkit-flex;
		display: flex;
		-webkit-flex-direction: column;
		-ms-flex-direction: column;
		flex-direction: column;
		-webkit-align-items: stretch;
		-ms-flex-align: stretch;
		align-items: stretch;
		-webkit-flex-shrink: 0;
		-ms-flex-negative: 0;
		flex-shrink: 0;
		-webkit-align-self: stretch;
		-ms-flex-item-align: stretch;
		align-self: stretch;
		width: 220px;
	}
	.post-minimal .post-image {
		position: relative;
		-webkit-flex-shrink: 0;
		-ms-flex-negative: 0;
		flex-shrink: 0;
		-webkit-align-self: stretch;
		-ms-flex-item-align: stretch;
		align-self: stretch;
		-webkit-flex-grow: 1;
		-ms-flex-positive: 1;
		flex-grow: 1;
		overflow: hidden;
	}
	.post-minimal .post-image img {
		position: absolute;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
		height: auto;
		width: auto;
		min-height: 100%;
		min-width: 100%;
		z-index: 1;
	}
	.post-minimal .post-body {
		padding: 30px 24px 30px 27px;
		-webkit-flex-grow: 1;
		-ms-flex-positive: 1;
		flex-grow: 1;
	}
}

@media (min-width: 1200px) {
	.post-minimal .post-body {
		padding: 40px 26px 40px 50px;
	}
}

.post-preview {
	max-width: 320px;
}

.post-preview a {
	display: block;
}

.post-preview .post-image,
.post-preview .post-image img {
	border-radius: 5px;
}

.post-preview .post-image img {
	width: auto;
}

.post-preview .post-header {
	line-height: 1.5;
	color: #000;
	transition: .33s all ease;
}

.post-preview .list-meta > li {
	display: inline-block;
	font-size: 12px;
	font-style: italic;
	color: #9b9b9b;
}

.post-preview .list-meta > li:not(:last-child):after {
	content: '/';
}

.post-preview:hover .post-header {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.post-preview * + .post-meta {
	margin-top: 5px;
}

.post-preview.post-preview-inverse > li {
	color: rgba(255, 255, 255, 0.5);
}

.post-preview.post-preview-inverse .post-header {
	color: #fff;
}

.post-preview.post-preview-inverse:hover .post-header {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.blog-timeline > dt {
	font: 700 25px "Roboto", Helvetica, Arial, sans-serif;
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.blog-timeline > dd {
	margin-top: 20px;
}

@media (min-width: 768px) {
	.blog-timeline {
		word-spacing: 0;
		white-space: nowrap;
	}
	.blog-timeline > * {
		display: inline-block;
	}
	.blog-timeline > dt {
		min-width: 65px;
		padding-right: 20px;
		margin-top: -.15em;
		vertical-align: top;
	}
	.blog-timeline > dd {
		margin-top: 0;
		width: calc(100% - 100px);
	}
}

@media (min-width: 992px) {
	.blog-timeline > dt {
		min-width: 100px;
		padding-right: 30px;
	}
}

.post-boxed {
	max-width: 330px;
	margin-right: auto;
	margin-left: auto;
	text-align: center;
	box-shadow: -1px 0px 10px 0px rgba(65, 65, 65, 0.12);
	transition: .3s all ease;
}

.post-boxed-img-wrap a {
	display: block;
}

.post-boxed-title {
	font: 500 18px/28px "Roboto", Helvetica, Arial, sans-serif;
}
.post-boxed-title {
    color: #000;
}
.post-boxed-title a {
	display: inline;
	color: #000;
}

.post-boxed-title a:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.post-boxed img {
	width: 30%;
}

.post-boxed .list-inline {
	font-size: 12px;
	letter-spacing: .05em;
}

.post-boxed-caption {
	padding: 20px;
}

.post-boxed .post-boxed-title + * {
	margin-top: 5px;
}

@media (min-width: 768px) {
	.post-boxed .post-boxed-caption {
		padding: 28px 42px 36px 28px;
	}
}

@media (min-width: 1200px) {
	.post-boxed:hover {
		box-shadow: -3px 5px 12px 0px rgba(65, 65, 65, 0.16);
	}
}

.post-minimal .post-image {
	height: 100%;
}

.post-minimal .post-image img {
	width: 100%;
	height: 100%;
	object-fit: cover;
}

.post-meta + .divider-fullwidth {
	margin-top: 15px;
}

* + .post-blockquote {
	margin-top: 30px;
}

.post-blockquote + * {
	margin-top: 30px;
}

@media (min-width: 768px) {
	* + .post-blockquote {
		margin-top: 50px;
	}
	.post-blockquote + * {
		margin-top: 50px;
	}
}

* + .post-comment-block, * + .post-comment-form {
	margin-top: 40px;
}

.post-comment-form h4 + * {
	margin-top: 15px;
}

.comment figure, .comment figure img {
	border-radius: 50%;
	max-width: 71px;
}

.comment time {
	font-size: 12px;
	line-height: 1;
	color: #9b9b9b;
}

.comment .user {
	font-size: 16px;
	line-height: 1.33333;
	font-weight: 700;
	text-transform: uppercase;
	color: #000;
}

.comment .list-icon-meta {
	position: relative;
	transform: translateY(0);
	margin-bottom: 0;
}

.comment .list-icon-meta > * {
	margin-top: 0;
}

.comment .list-icon-meta > *:not(:last-child) {
	margin-right: 8px;
}

.comment .list-icon-meta > li {
	display: inline-block;
}

.comment .list-icon-meta li {
	font-size: 12px;
	line-height: 1;
	font-weight: 400;
}

.comment .comment-body {
	padding: 17px 22px;
	border: 1px solid #dedede;
	border-radius: 7px;
}

.comment .comment-body-header {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-wrap: wrap;
	-ms-flex-wrap: wrap;
	flex-wrap: wrap;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-align-items: flex-start;
	-ms-flex-align: start;
	align-items: flex-start;
	-webkit-justify-content: space-between;
	-ms-flex-pack: justify;
	justify-content: space-between;
	position: relative;
	transform: translateY(-5px);
	margin-bottom: -5px;
}

.comment .comment-body-header > * {
	margin-top: 5px;
}

.comment .comment-body-header > *:not(:last-child) {
	margin-right: 5px;
}

@media (min-width: 768px) {
	.comment .comment-body-header {
		-webkit-align-items: center;
		-ms-flex-align: center;
		align-items: center;
	}
}

.comment .comment-body-header > * {
	-webkit-flex-shrink: 0;
	-ms-flex-negative: 0;
	flex-shrink: 0;
}

.comment .comment-meta {
	-webkit-flex-grow: 1;
	-ms-flex-positive: 1;
	flex-grow: 1;
	position: relative;
	transform: translateY(-5px);
	margin-bottom: -5px;
}

.comment .comment-meta > * {
	margin-top: 5px;
}

.comment .comment-meta > *:not(:last-child) {
	margin-right: 10px;
}

@media (min-width: 768px) {
	.comment .comment-meta > * {
		display: inline-block;
		vertical-align: baseline;
	}
}

.comment .comment-body-text {
	margin-top: 10px;
}

.comment-minimal .author {
	font: 700 14px/18px "Roboto", Helvetica, Arial, sans-serif;
	text-transform: uppercase;
	letter-spacing: -.025em;
	color: #000;
}

.comment-minimal * + .comment-body {
	margin-top: 10px;
}

* + .comment-minimal {
	margin-top: 35px;
}

.comment-group-reply {
	padding-left: 12%;
}

.comment + * {
	margin-top: 21px;
}

* + .comment-group {
	margin-top: 30px;
}

@media (min-width: 768px) {
	.comment > .unit > .unit-left {
		margin-top: 16px;
	}
	* + .comment-minimal {
		margin-top: 45px;
	}
}

@media (min-width: 992px) {
	* + .post-comment {
		margin-top: 80px;
	}
}

.page-title {
	text-align: center;
}

.page-title > * {
	letter-spacing: 0;
	text-transform: uppercase;
}

.page-title .page-title-inner {
	position: relative;
	display: inline-block;
}

.page-title .page-title-left,
.page-title .page-title-right {
	position: absolute;
	top: 50%;
	width: auto;
	overflow: hidden;
	white-space: nowrap;
	vertical-align: middle;
}

.page-title .page-title-left *,
.page-title .page-title-right * {
	display: inline;
	white-space: nowrap;
}

.page-title .page-title-left {
	left: 0;
	text-align: right;
	transform: translate(-100%, -50%);
}

.page-title .page-title-left * {
	padding-right: .85em;
}

.page-title .page-title-left *:nth-last-child(odd) {
	color: rgba(255, 255, 255, 0.1);
}

.page-title .page-title-left *:nth-last-child(even) {
	color: rgba(255, 255, 255, 0.2);
}

.page-title .page-title-right {
	right: 0;
	text-align: left;
	transform: translate(100%, -50%);
}

.page-title .page-title-right * {
	padding-left: .85em;
}

.page-title .page-title-right *:nth-child(odd) {
	color: rgba(255, 255, 255, 0.1);
}

.page-title .page-title-right *:nth-child(even) {
	color: rgba(255, 255, 255, 0.2);
}

.page-title-wrap {
	background: #000;
	background-attachment: fixed;
	-webkit-background-size: cover;
	background-size: cover;
	background-position: center 80%;
}

@media (min-width: 768px) {
	.page-title {
		text-align: left;
	}
}

/*
*
* Preloader
*/
.preloader {
	position: fixed;
	left: 0;
	top: 0;
	bottom: 0;
	right: 0;
	z-index: 10000;
	display: flex;
	justify-content: center;
	align-items: center;
	padding: 20px;
	background: #fff;
	transition: .3s all ease;
}

.preloader.loaded {
	opacity: 0;
	visibility: hidden;
}

.preloader-body {
	text-align: center;
}

.preloader-body p {
	position: relative;
	right: -8px;
}

.cssload-container {
	width: 100%;
	height: 36px;
	text-align: center;
}

.cssload-speeding-wheel {
	width: 36px;
	height: 36px;
	margin: 0 auto;
	border: 3px solid <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	border-radius: 50%;
	border-left-color: transparent;
	border-bottom-color: transparent;
	animation: cssload-spin .88s infinite linear;
}

@-webkit-keyframes cssload-spin {
	100% {
		transform: rotate(360deg);
	}
}

@keyframes cssload-spin {
	100% {
		transform: rotate(360deg);
	}
}

.pricing-table {
	overflow: hidden;
	background: #fff;
	text-align: center;
	box-shadow: -1px 2px 5px 0 rgba(65, 65, 65, 0.12);
}

.pricing-table-header {
	font-size: 18px;
	text-transform: uppercase;
	letter-spacing: .05em;
	color: #464a4d;
}

.pricing-table-body {
	padding: 35px 30px;
}

.pricing-table-label {
	padding: 17px 15px;
	text-align: center;
	background: #3a3c3e;
}

.pricing-table-label p {
	font: 700 14px "Roboto", Helvetica, Arial, sans-serif;
	letter-spacing: .05em;
	text-transform: uppercase;
	color: #fff;
}

.pricing-table .pricing-list {
	font-size: 16px;
	font-weight: 300;
	color: #00030a;
}

.pricing-table .pricing-list span {
	display: inline-block;
	margin-right: .25em;
}

.pricing-table .pricing-list > li + li {
	margin-top: 12px;
}

.pricing-table * + .price-object {
	margin-top: 22px;
}

.pricing-table * + .pricing-list {
	margin-top: 22px;
}

.pricing-object {
	font-family: "Roboto", Helvetica, Arial, sans-serif;
	font-weight: 900;
	font-size: 0;
	line-height: 0;
	color: #000;
}

.pricing-object > * {
	margin-top: 0;
}

.pricing-object .price {
	font-family: Helvetica, Arial, sans-serif;
	font-weight: 900;
}

.pricing-object .small {
	position: relative;
	font: 700 10px "Roboto", Helvetica, Arial, sans-serif;
	color: inherit;
	text-transform: uppercase;
}

.pricing-object .small-middle {
	vertical-align: middle;
}

.pricing-object .small-bottom {
	vertical-align: bottom;
}

.pricing-object-sm {
	font-size: 32px;
	line-height: .8;
}

.pricing-object-sm .small {
	font-size: 12px;
}

.pricing-object-sm .small-middle {
	margin-right: 3px;
}

.pricing-object-sm .small-bottom {
	margin-left: 1px;
	vertical-align: bottom;
}

.price-irrelevant {
	color: #9f9f9f;
	text-decoration: line-through;
}

.pricing-object-md {
	font-size: 53px;
	line-height: 1;
}

.pricing-object-md .price {
	line-height: .5;
}

.pricing-object-md .small {
	font-size: 17px;
	font-weight: 400;
}

.pricing-object-md .small-middle {
	font-size: 23px;
}

.pricing-object-md .small-bottom {
	bottom: -.25em;
}

.pricing-object-lg,
.pricing-object-xl {
	font-size: 64px;
	line-height: .7;
}

.pricing-object-lg .small,
.pricing-object-xl .small {
	font-size: 9px;
}

.pricing-object-lg .small-top,
.pricing-object-xl .small-top {
	top: 11px;
	margin-right: 5px;
	font-size: 14px;
	vertical-align: top;
	font-weight: 700;
}

.pricing-object-lg .small-bottom,
.pricing-object-xl .small-bottom {
	bottom: -10px;
	margin-left: -2px;
	font-weight: 700;
	vertical-align: bottom;
}

.price-current .small {
	position: relative;
	font-family: "Roboto", Helvetica, Arial, sans-serif;
	font-weight: 400;
}

.price-current .small-middle {
	vertical-align: middle;
	top: -.3em;
}

.price-current .small-bottom {
	top: .3em;
}

@media (min-width: 768px) {
	.pricing-object-lg {
		font-size: 72px;
	}
	.pricing-object-xl {
		font-size: 54px;
	}
	.pricing-object-xl .small-middle {
		font-size: 30px;
	}
	.pricing-object-xl .small-bottom {
		font-size: 25px;
	}
}

@media (min-width: 992px) {
	.pricing-object-xl {
		font-size: 76px;
	}
}

.panel.bg-accent.bg-default-outline-btn.text-center {
    background: transparent;
    border: 2px solid rgb(50, 120, 180);
}

.product .product-label {
	padding: 7px 11px;
	min-width: 90px;
	font: 700 12px/16px "Roboto", Helvetica, Arial, sans-serif;
	letter-spacing: .05em;
	text-align: center;
	border-radius: 0 0 7px 7px;
}

.product .product-rating {
	position: relative;
	transform: translateY(-2px);
	margin-bottom: -2px;
}

.product .product-rating > * {
	margin-top: 2px;
}

.product .product-rating > *:not(:last-child) {
	margin-right: 5px;
}

.product .product-rating > * {
	display: inline-block;
	vertical-align: middle;
}

.product .product-color {
	display: inline-block;
	width: 24px;
	height: 24px;
	font-size: 0;
	line-height: 0;
	border-radius: 50%;
	background: #000;
	vertical-align: middle;
}

.product .product-size {
	font: 700 14px/18px "Roboto", Helvetica, Arial, sans-serif;
	color: #000;
}

.product * + .product-brand,
.product .product-brand + * {
	margin-top: 0;
}

.product-item-default {
	position: relative;
	background: #fff;
	border-radius: 7px;
	box-shadow: -1px 0px 10px 0px rgba(65, 65, 65, 0.12);
	overflow: hidden;
	text-align: center;
}

.product-item-default .product-slider .owl-dots {
	position: absolute;
	left: 50%;
	transform: translateX(-50%);
	bottom: 10px;
	z-index: 5;
}

.product-item-default .product-slider .owl-dots .owl-dot {
	box-shadow: -1px 0px 10px 0px rgba(65, 65, 65, 0.12);
}

.product-item-default .product-label-wrap {
	display: inline-block;
	position: absolute;
	top: 240px;
	z-index: 2;
	width: auto;
}

.product-item-default .product-label-wrap-left {
	transform-origin: 0 0;
	transform: rotate(-90deg);
	left: 0;
}

.product-item-default .product-label-wrap-right {
	transform-origin: 100% 0;
	transform: rotate(90deg);
	right: 0;
}

.product-item-default .pricing-wrap {
	vertical-align: baseline;
}

.product-item-default .pricing-wrap > * {
	display: inline-block;
	vertical-align: baseline;
	margin-top: 0;
}

.product-item-default .pricing-wrap > * + * {
	margin-left: 7px;
}

.product-item-default .pricing-wrap > *:last-child {
	margin-right: 20px;
}

.product-item-default .product-control {
	width: 100%;
	min-height: 60px;
	border-radius: 0;
}

.product-item-default .product-control .icon {
	position: relative;
	top: -1px;
}

.product-item-default .product-main {
	padding-left: 15px;
	padding-right: 15px;
}

.product-item-default .product-footer {
	position: relative;
}

.product-item-default .product-footer-front {
	padding: 0 20px 30px;
}

.product-item-default * + .product-main {
	margin-top: 16px;
}

.product-item-default * + .product-footer {
	margin-top: 9px;
}

@media (max-width: 767px) {
	.product-item-default {
		max-width: 320px;
		margin-left: auto;
		margin-right: auto;
	}
}

@media (min-width: 992px) {
	.desktop .product-item-default .owl-dots {
		bottom: 2px;
		opacity: 0;
		visibility: hidden;
		transition: .33s all ease;
	}
	.desktop .product-item-default .product-footer > * {
		position: relative;
		transition: .33s all ease;
	}
	.desktop .product-item-default .product-footer-front {
		visibility: visible;
		opacity: 1;
		top: 0;
		z-index: 1;
	}
	.desktop .product-item-default .product-footer-behind {
		position: absolute;
		right: 0;
		bottom: 0;
		left: 0;
		opacity: 0;
		z-index: 2;
		visibility: hidden;
		transform: translateY(30px);
	}
	.desktop .product-item-default:hover .owl-dots {
		bottom: 10px;
		opacity: 1;
		visibility: visible;
	}
	.desktop .product-item-default:hover .product-footer-front {
		top: -10px;
		opacity: 0;
		visibility: hidden;
	}
	.desktop .product-item-default:hover .product-footer-behind {
		bottom: 0;
		visibility: visible;
		opacity: 1;
		transform: translateY(0);
	}
}

.product-item-fullwidth {
	border-radius: 7px;
	background: #fff;
	overflow: hidden;
	box-shadow: -1px 0px 10px 0px rgba(65, 65, 65, 0.12);
	text-align: center;
}

.product-item-fullwidth .product-slider {
	background: #f9f9f9;
}

.product-item-fullwidth .product-slider-inner {
	display: inline-block;
	width: 100%;
	max-width: 320px;
	padding: 19px 9px 19px;
}

.product-item-fullwidth .product-main {
	position: relative;
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
}

.product-item-fullwidth .product-body {
	padding: 60px 25px 36px;
}

.product-item-fullwidth .product-aside {
	border-style: solid;
	border-color: #f6f7fa;
	border-width: 1px 0 0 0;
	text-align: center;
}

.product-item-fullwidth .product-aside-top {
	padding: 20px;
}

.product-item-fullwidth .product-details {
	min-width: 170px;
}

.product-item-fullwidth .product-label-wrap {
	position: absolute;
	top: 0;
	left: 50%;
	transform: translateX(-50%);
}

.product-item-fullwidth .product-control {
	width: 100%;
	border-radius: 0;
}

.product-item-fullwidth .stepper-wrap {
	vertical-align: middle;
}

.product-item-fullwidth .stepper-wrap > * {
	display: inline-block;
	vertical-align: middle;
	margin-top: 0;
}

.product-item-fullwidth .stepper-wrap > *:first-child {
	margin-right: 5px;
}

.product-item-fullwidth .btn {
	padding-top: 18px;
	padding-bottom: 18px;
}

.product-item-fullwidth * + .product-aside-bottom {
	margin-top: 14px;
}

.product-item-fullwidth * + .product-rating {
	margin-top: 7px;
}

.product-item-fullwidth * + .product-description {
	margin-top: 17px;
}

.product-item-fullwidth * + .product-details {
	margin-top: 23px;
}

.product-item-fullwidth * + .product-control {
	margin-top: 12px;
}

.product-item-fullwidth * + .price-current {
	margin-top: 0;
}

* + .product-item-fullwidth {
	margin-top: 30px;
}

@media (min-width: 768px) {
	.product-item-fullwidth {
		display: -ms-flexbox;
		display: -webkit-flex;
		display: flex;
		-webkit-flex-direction: row;
		-ms-flex-direction: row;
		flex-direction: row;
		-webkit-flex-wrap: nowrap;
		-ms-flex-wrap: nowrap;
		flex-wrap: nowrap;
		text-align: left;
	}
	.product-item-fullwidth .product-slider,
	.product-item-fullwidth .product-aside {
		-webkit-flex-shrink: 0;
		-ms-flex-negative: 0;
		flex-shrink: 0;
	}
	.product-item-fullwidth .product-slider-inner {
		width: 270px;
	}
	.product-item-fullwidth .product-main {
		-webkit-flex-grow: 1;
		-ms-flex-positive: 1;
		flex-grow: 1;
	}
	.product-item-fullwidth .product-body {
		padding: 70px 40px 45px 35px;
	}
	.product-item-fullwidth .product-label-wrap {
		left: 35px;
		transform: none;
	}
	.product-item-fullwidth .product-brand {
		line-height: 1.2;
	}
	.product-item-fullwidth .product-aside {
		position: relative;
		overflow: hidden;
		-webkit-flex-shrink: 0;
		-ms-flex-negative: 0;
		flex-shrink: 0;
		min-width: 230px;
	}
	.product-item-fullwidth .product-aside,
	.product-item-fullwidth .product-aside .product-aside-top {
		display: -ms-flexbox;
		display: -webkit-flex;
		display: flex;
		-webkit-flex-direction: column;
		-ms-flex-direction: column;
		flex-direction: column;
		-webkit-flex-wrap: nowrap;
		-ms-flex-wrap: nowrap;
		flex-wrap: nowrap;
		-webkit-align-items: center;
		-ms-flex-align: center;
		align-items: center;
		-webkit-justify-content: center;
		-ms-flex-pack: center;
		justify-content: center;
	}
	.product-item-fullwidth .product-aside > * {
		width: 100%;
	}
	.product-item-fullwidth .product-aside-top {
		padding: 15px 10px 20px;
		-webkit-flex-grow: 1;
		-ms-flex-positive: 1;
		flex-grow: 1;
	}
	.product-item-fullwidth .stepper-wrap > * {
		display: block;
		margin-left: auto;
		margin-right: auto;
	}
	.product-item-fullwidth .stepper-wrap > *:first-child {
		margin-right: 0;
	}
	.product-item-fullwidth * + .product-aside-bottom {
		margin-top: 0;
	}
	.product-item-fullwidth * + .product-control {
		margin-top: 34px;
	}
}

@media (min-width: 992px) {
	.product-item-fullwidth .product-main-inner {
		display: -ms-flexbox;
		display: -webkit-flex;
		display: flex;
		-webkit-flex-direction: row;
		-ms-flex-direction: row;
		flex-direction: row;
		-webkit-flex-wrap: nowrap;
		-ms-flex-wrap: nowrap;
		flex-wrap: nowrap;
	}
	.product-item-fullwidth .product-aside {
		min-width: 270px;
		border-width: 0 0 0 1px;
	}
	.product-item-fullwidth .product-aside-top {
		padding: 20px 10px 40px;
	}
	.product-item-fullwidth .product-aside-bottom {
		padding-top: 20px;
		border-top: 1px solid #f6f7fa;
	}
	.product-item-fullwidth .product-control {
		border-radius: 0 0 5px 0;
	}
	.product-item-fullwidth * + .product-control {
		margin-top: 30px;
	}
}

@media (min-width: 1200px) {
	.product-item-fullwidth .product-body {
		padding: 85px 70px 67px 62px;
	}
	.product-item-fullwidth .product-label-wrap {
		left: 62px;
	}
}

.ie-10 .product-single .product-info > li dl,
.ie-11 .product-single .product-info > li dl {
	height: 70px;
}

.product-single {
	background: #fff;
}

.product-single .product-slider {
	padding: 0 10px;
}

.product-single .product-info {
	text-align: center;
}

.product-single .product-info > li {
	border-bottom: 1px solid #dedede;
}

.product-single .product-info dl {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: wrap;
	-ms-flex-wrap: wrap;
	flex-wrap: wrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: space-between;
	-ms-flex-pack: justify;
	justify-content: space-between;
	min-height: 70px;
	padding: 0 15px 0 16px;
	overflow: hidden;
}

.product-single .product-info dt {
	font: 700 16px/24px "Roboto", Helvetica, Arial, sans-serif;
	color: #000;
	margin-right: 10px;
}

.product-single .product-panel {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: wrap;
	-ms-flex-wrap: wrap;
	flex-wrap: wrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: center;
	-ms-flex-pack: center;
	justify-content: center;
}

.product-single .product-panel > * {
	display: inline-block;
	-webkit-flex-shrink: 0;
	-ms-flex-negative: 0;
	flex-shrink: 0;
	margin-top: 0;
}

.product-single .product-panel .pricing-wrap {
	margin-right: 20px;
}

.product-single .product-panel .product-control {
	min-width: 270px;
}

.product-single .pricing-wrap {
	top: -12px;
	position: relative;
	transform: translateY(-2px);
	margin-bottom: -2px;
}

.product-single .pricing-wrap > * {
	margin-top: 2px;
}

.product-single .pricing-wrap > *:not(:last-child) {
	margin-right: 15px;
}

.product-single .pricing-wrap > * {
	display: inline-block;
}

.product-single .product-rating .list-rating {
	position: relative;
	top: -1px;
}

.product-single .product-brand {
	line-height: 1;
}

.product-single .responsive-tabs {
	width: 100%;
}

.product-single * + .product-body {
	margin-top: 36px;
}

.product-single * + .product-footer {
	margin-top: 50px;
}

.product-single * + .product-rating {
	margin-top: 13px;
}

.product-single * + .product-panel {
	margin-top: 30px;
}

.product-single * + .product-tabs {
	margin-top: 25px;
}

@media (max-width: 767px) {
	.product-single .product-slider {
		max-width: 220px;
		margin-left: auto;
		margin-right: auto;
		overflow: hidden;
	}
	.product-single .responsive-tabs.product-tabs .resp-accordion {
		padding-left: 15px;
	}
	.product-single .responsive-tabs.product-tabs .resp-tab-content {
		padding: 20px 15px;
	}
}

@media (min-width: 576px) {
	.product-single .product-info dl {
		padding: 0 15px 0 32px;
	}
}

@media (min-width: 768px) {
	.product-single .product-main {
		display: -ms-flexbox;
		display: -webkit-flex;
		display: flex;
		-webkit-flex-direction: row;
		-ms-flex-direction: row;
		flex-direction: row;
		-webkit-flex-wrap: nowrap;
		-ms-flex-wrap: nowrap;
		flex-wrap: nowrap;
		width: 100%;
	}
	.product-single > * {
		-webkit-flex-shrink: 1;
		-ms-flex-negative: 1;
		flex-shrink: 1;
	}
	.product-single .product-slider {
		width: 38%;
	}
	.product-single .product-slider .owl-dots {
		margin-top: 30px;
	}
	.product-single .product-body {
		width: 62%;
		padding-left: 30px;
	}
	.product-single .product-info {
		-webkit-justify-content: space-between;
		-ms-flex-pack: justify;
		justify-content: space-between;
	}
	.product-single .responsive-tabs-vertical.product-tabs .resp-tabs-container {
		padding-left: 40px;
	}
	.product-single * + .product-body {
		margin-top: 0;
	}
}

@media (min-width: 992px) {
	.product-single .product-body {
		padding-left: 80px;
	}
	.product-single .responsive-tabs-vertical.product-tabs .resp-tabs-container {
		padding-left: 65px;
	}
}

@media (min-width: 1200px) {
	.product-single .product-body {
		padding-left: 130px;
	}
	.product-single .responsive-tabs-vertical.product-tabs .resp-tabs-container {
		padding-left: 100px;
	}
	.product-single * + .product-footer {
		margin-top: 70px;
	}
}

.product-cart-item {
	background: #fff;
	border-radius: 7px;
	overflow: hidden;
	box-shadow: -1px 0px 10px 0px rgba(65, 65, 65, 0.12);
}

.product-cart-item .product-image {
	padding: 0 12px;
	background: #f9f9f9;
	font-size: 0;
	line-height: 0;
}

.product-cart-item .product-image img {
	display: inline-block;
	width: auto;
	height: auto;
}

.product-cart-item .product-body {
	padding: 20px 30px;
}

.product-cart-item .product-aside {
	position: relative;
	padding: 20px 66px 20px 35px;
}

.product-cart-item .product-group {
	display: -webkit-inline-box;
	display: -webkit-inline-flex;
	display: -ms-inline-flexbox;
	display: inline-flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: wrap;
	-ms-flex-wrap: wrap;
	flex-wrap: wrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
}

.product-cart-item .pricing-object {
	position: relative;
	top: -5px;
}

.product-cart-item .product-control {
	position: absolute;
	right: 21px;
	top: 50%;
	margin: 0;
	transform: translateY(-50%);
}

* + .product-cart-item {
	margin-top: 30px;
}

@media (min-width: 576px) {
	.product-cart-item .product-main {
		display: -ms-flexbox;
		display: -webkit-flex;
		display: flex;
		-webkit-flex-direction: row;
		-ms-flex-direction: row;
		flex-direction: row;
		-webkit-flex-wrap: nowrap;
		-ms-flex-wrap: nowrap;
		flex-wrap: nowrap;
		-webkit-align-items: center;
		-ms-flex-align: center;
		align-items: center;
	}
	.product-cart-item .product-body {
		padding: 20px 20px;
	}
	.product-cart-item .product-aside {
		padding: 20px 40px 20px 20px;
	}
	.product-cart-item .product-control {
		right: 15px;
	}
}

@media (max-width: 767px) {
	.product-cart-item .product-group {
		margin-bottom: 20px;
		margin-left: -22px;
	}
	.product-cart-item .product-group > * {
		margin-top: 20px;
		margin-left: 22px;
	}
	.product-cart-item .product-image {
		text-align: center;
	}
	.product-cart-item .product-aside {
		border-top: 1px solid #dedede;
	}
}

@media (min-width: 768px) {
	.product-cart-item .product-group {
		margin-bottom: 20px;
		margin-left: -30px;
	}
	.product-cart-item .product-group > * {
		margin-top: 20px;
		margin-left: 30px;
	}
	.product-cart-item .product-aside {
		padding-right: 100px;
	}
	.product-cart-item .product-control {
		right: 27px;
	}
}

@media (min-width: 992px) {
	.product-cart-item {
		display: -ms-flexbox;
		display: -webkit-flex;
		display: flex;
		-webkit-flex-direction: row;
		-ms-flex-direction: row;
		flex-direction: row;
		-webkit-flex-wrap: nowrap;
		-ms-flex-wrap: nowrap;
		flex-wrap: nowrap;
		-webkit-align-items: center;
		-ms-flex-align: center;
		align-items: center;
	}
	.product-cart-item .product-main {
		-webkit-flex-grow: 1;
		-ms-flex-positive: 1;
		flex-grow: 1;
	}
}

.product-order-item {
	background: #fff;
	border-radius: 7px;
	overflow: hidden;
	box-shadow: -1px 0px 10px 0px rgba(65, 65, 65, 0.12);
}

.product-order-item .product-image {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: center;
	-ms-flex-pack: center;
	justify-content: center;
	-webkit-flex-shrink: 0;
	-ms-flex-negative: 0;
	flex-shrink: 0;
	background: #f9f9f9;
	font-size: 0;
	line-height: 0;
}

.product-order-item .product-image img {
	display: inline-block;
	width: auto;
	height: auto;
}

.product-order-item .product-body {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: wrap;
	-ms-flex-wrap: wrap;
	flex-wrap: wrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: flex-start;
	-ms-flex-pack: start;
	justify-content: flex-start;
	padding: 15px 30px;
	-webkit-flex-grow: 1;
	-ms-flex-positive: 1;
	flex-grow: 1;
	margin-left: -20px;
	margin-bottom: 14px;
}

.product-order-item .product-body > * {
	margin-left: 20px;
	margin-top: 14px;
}

.product-order-item .product-header {
	width: 100%;
}

.product-order-item .pricing-object {
	position: relative;
	top: -6px;
}

* + .product-order-item {
	margin-top: 30px;
}

@media (min-width: 576px) {
	.product-order-item {
		display: -ms-flexbox;
		display: -webkit-flex;
		display: flex;
		-webkit-flex-direction: row;
		-ms-flex-direction: row;
		flex-direction: row;
		-webkit-flex-wrap: nowrap;
		-ms-flex-wrap: nowrap;
		flex-wrap: nowrap;
		-webkit-align-items: stretch;
		-ms-flex-align: stretch;
		align-items: stretch;
	}
}

@media (min-width: 768px) {
	.product-order-item {
		-webkit-justify-content: space-between;
		-ms-flex-pack: justify;
		justify-content: space-between;
	}
	.product-order-item .product-header {
		width: auto;
	}
}

@media (min-width: 992px) and (max-width: 1799px) {
	.product-order-item .product-body {
		-webkit-justify-content: flex-start;
		-ms-flex-pack: start;
		justify-content: flex-start;
	}
	.product-order-item .product-header {
		width: 100%;
	}
}

@media (min-width: 1200px) {
	.product-order-item .product-body {
		-webkit-justify-content: space-between;
		-ms-flex-pack: justify;
		justify-content: space-between;
	}
	.product-order-item .product-header {
		max-width: 125px;
	}
}

.one-screen-page .page {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
}

.one-screen-page .page-inner {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: column;
	-ms-flex-direction: column;
	flex-direction: column;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: space-between;
	-ms-flex-pack: justify;
	justify-content: space-between;
	min-height: 100vh;
	text-align: center;
}

.one-screen-page .page-inner,
.one-screen-page .page-inner > * {
	width: 100%;
}

.one-screen-page .page-head,
.one-screen-page .page-foot {
	padding: 0;
	background: transparent;
}

.one-screen-page .page-head-inner {
	padding: calc(1em + 4vh) 0 calc(1em + 2vh);
}

.one-screen-page .page-content {
	padding: calc(1em + 4vh) 0;
}

.one-screen-page .page-foot-inner {
	padding: calc(1em + 2vh) 0 calc(1em + 4vh);
}

.one-screen-page .rights {
	color: #fff;
}

.one-screen-page .rights a, .one-screen-page .rights a:active, .one-screen-page .rights a:focus {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.one-screen-page .rights a:hover {
	color: #ababab;
}

@media (min-width: 576px) {
	.one-screen-page .page-inner {
		text-align: left;
	}
}

@media (min-width: 1800px) {
	.one-screen-page .page-head-inner {
		padding: 50px 0 10px;
	}
	.one-screen-page .page-content {
		padding: 30px 0;
	}
	.one-screen-page .page-foot-inner {
		padding: 50px 0 23px;
	}
}

.ie-10 .one-screen-page,
.ie-11 .one-screen-page {
	overflow-x: hidden;
	overflow-y: auto;
}

.inset-left-0 {
	padding-left: 0;
}

.inset-left-10 {
	padding-left: 10px;
}

.inset-left-15 {
	padding-left: 15px;
}

.inset-left-20 {
	padding-left: 20px;
}

.inset-left-30 {
	padding-left: 30px;
}

.inset-left-40 {
	padding-left: 40px;
}

.inset-left-50 {
	padding-left: 50px;
}

.inset-left-60 {
	padding-left: 60px;
}

.inset-left-70 {
	padding-left: 70px;
}

.inset-left-85 {
	padding-left: 85px;
}

.inset-left-100 {
	padding-left: 100px;
}

@media (min-width: 576px) {
	.inset-sm-left-0 {
		padding-left: 0;
	}
	.inset-sm-left-10 {
		padding-left: 10px;
	}
	.inset-sm-left-15 {
		padding-left: 15px;
	}
	.inset-sm-left-20 {
		padding-left: 20px;
	}
	.inset-sm-left-30 {
		padding-left: 30px;
	}
	.inset-sm-left-40 {
		padding-left: 40px;
	}
	.inset-sm-left-50 {
		padding-left: 50px;
	}
	.inset-sm-left-60 {
		padding-left: 60px;
	}
	.inset-sm-left-70 {
		padding-left: 70px;
	}
	.inset-sm-left-85 {
		padding-left: 85px;
	}
	.inset-sm-left-100 {
		padding-left: 100px;
	}
}

@media (min-width: 768px) {
	.inset-md-left-0 {
		padding-left: 0;
	}
	.inset-md-left-10 {
		padding-left: 10px;
	}
	.inset-md-left-15 {
		padding-left: 15px;
	}
	.inset-md-left-20 {
		padding-left: 20px;
	}
	.inset-md-left-30 {
		padding-left: 30px;
	}
	.inset-md-left-40 {
		padding-left: 40px;
	}
	.inset-md-left-50 {
		padding-left: 50px;
	}
	.inset-md-left-60 {
		padding-left: 60px;
	}
	.inset-md-left-70 {
		padding-left: 70px;
	}
	.inset-md-left-85 {
		padding-left: 85px;
	}
	.inset-md-left-100 {
		padding-left: 100px;
	}
}

@media (min-width: 992px) {
	.inset-lg-left-0 {
		padding-left: 0;
	}
	.inset-lg-left-10 {
		padding-left: 10px;
	}
	.inset-lg-left-15 {
		padding-left: 15px;
	}
	.inset-lg-left-20 {
		padding-left: 20px;
	}
	.inset-lg-left-30 {
		padding-left: 30px;
	}
	.inset-lg-left-40 {
		padding-left: 40px;
	}
	.inset-lg-left-50 {
		padding-left: 50px;
	}
	.inset-lg-left-60 {
		padding-left: 60px;
	}
	.inset-lg-left-70 {
		padding-left: 70px;
	}
	.inset-lg-left-85 {
		padding-left: 85px;
	}
	.inset-lg-left-100 {
		padding-left: 100px;
	}
}

@media (min-width: 1200px) {
	.inset-xl-left-0 {
		padding-left: 0;
	}
	.inset-xl-left-10 {
		padding-left: 10px;
	}
	.inset-xl-left-15 {
		padding-left: 15px;
	}
	.inset-xl-left-20 {
		padding-left: 20px;
	}
	.inset-xl-left-30 {
		padding-left: 30px;
	}
	.inset-xl-left-40 {
		padding-left: 40px;
	}
	.inset-xl-left-50 {
		padding-left: 50px;
	}
	.inset-xl-left-60 {
		padding-left: 60px;
	}
	.inset-xl-left-70 {
		padding-left: 70px;
	}
	.inset-xl-left-85 {
		padding-left: 85px;
	}
	.inset-xl-left-100 {
		padding-left: 100px;
	}
}

@media (min-width: 1800px) {
	.inset-xxl-left-0 {
		padding-left: 0;
	}
	.inset-xxl-left-10 {
		padding-left: 10px;
	}
	.inset-xxl-left-15 {
		padding-left: 15px;
	}
	.inset-xxl-left-20 {
		padding-left: 20px;
	}
	.inset-xxl-left-30 {
		padding-left: 30px;
	}
	.inset-xxl-left-40 {
		padding-left: 40px;
	}
	.inset-xxl-left-50 {
		padding-left: 50px;
	}
	.inset-xxl-left-60 {
		padding-left: 60px;
	}
	.inset-xxl-left-70 {
		padding-left: 70px;
	}
	.inset-xxl-left-85 {
		padding-left: 85px;
	}
	.inset-xxl-left-100 {
		padding-left: 100px;
	}
}

.inset-right-0 {
	padding-right: 0;
}

.inset-right-10 {
	padding-right: 10px;
}

.inset-right-15 {
	padding-right: 15px;
}

.inset-right-20 {
	padding-right: 20px;
}

.inset-right-30 {
	padding-right: 30px;
}

.inset-right-40 {
	padding-right: 40px;
}

.inset-right-50 {
	padding-right: 50px;
}

.inset-right-60 {
	padding-right: 60px;
}

.inset-right-70 {
	padding-right: 70px;
}

.inset-right-85 {
	padding-right: 85px;
}

.inset-right-100 {
	padding-right: 100px;
}

@media (min-width: 576px) {
	.inset-sm-right-0 {
		padding-right: 0;
	}
	.inset-sm-right-10 {
		padding-right: 10px;
	}
	.inset-sm-right-15 {
		padding-right: 15px;
	}
	.inset-sm-right-20 {
		padding-right: 20px;
	}
	.inset-sm-right-30 {
		padding-right: 30px;
	}
	.inset-sm-right-40 {
		padding-right: 40px;
	}
	.inset-sm-right-50 {
		padding-right: 50px;
	}
	.inset-sm-right-60 {
		padding-right: 60px;
	}
	.inset-sm-right-70 {
		padding-right: 70px;
	}
	.inset-sm-right-85 {
		padding-right: 85px;
	}
	.inset-sm-right-100 {
		padding-right: 100px;
	}
}

@media (min-width: 768px) {
	.inset-md-right-0 {
		padding-right: 0;
	}
	.inset-md-right-10 {
		padding-right: 10px;
	}
	.inset-md-right-15 {
		padding-right: 15px;
	}
	.inset-md-right-20 {
		padding-right: 20px;
	}
	.inset-md-right-30 {
		padding-right: 30px;
	}
	.inset-md-right-40 {
		padding-right: 40px;
	}
	.inset-md-right-50 {
		padding-right: 50px;
	}
	.inset-md-right-60 {
		padding-right: 60px;
	}
	.inset-md-right-70 {
		padding-right: 70px;
	}
	.inset-md-right-85 {
		padding-right: 85px;
	}
	.inset-md-right-100 {
		padding-right: 100px;
	}
}

@media (min-width: 992px) {
	.inset-lg-right-0 {
		padding-right: 0;
	}
	.inset-lg-right-10 {
		padding-right: 10px;
	}
	.inset-lg-right-15 {
		padding-right: 15px;
	}
	.inset-lg-right-20 {
		padding-right: 20px;
	}
	.inset-lg-right-30 {
		padding-right: 30px;
	}
	.inset-lg-right-40 {
		padding-right: 40px;
	}
	.inset-lg-right-50 {
		padding-right: 50px;
	}
	.inset-lg-right-60 {
		padding-right: 60px;
	}
	.inset-lg-right-70 {
		padding-right: 70px;
	}
	.inset-lg-right-85 {
		padding-right: 85px;
	}
	.inset-lg-right-100 {
		padding-right: 100px;
	}
}

@media (min-width: 1200px) {
	.inset-xl-right-0 {
		padding-right: 0;
	}
	.inset-xl-right-10 {
		padding-right: 10px;
	}
	.inset-xl-right-15 {
		padding-right: 15px;
	}
	.inset-xl-right-20 {
		padding-right: 20px;
	}
	.inset-xl-right-30 {
		padding-right: 30px;
	}
	.inset-xl-right-40 {
		padding-right: 40px;
	}
	.inset-xl-right-50 {
		padding-right: 50px;
	}
	.inset-xl-right-60 {
		padding-right: 60px;
	}
	.inset-xl-right-70 {
		padding-right: 70px;
	}
	.inset-xl-right-85 {
		padding-right: 85px;
	}
	.inset-xl-right-100 {
		padding-right: 100px;
	}
}

@media (min-width: 1800px) {
	.inset-xxl-right-0 {
		padding-right: 0;
	}
	.inset-xxl-right-10 {
		padding-right: 10px;
	}
	.inset-xxl-right-15 {
		padding-right: 15px;
	}
	.inset-xxl-right-20 {
		padding-right: 20px;
	}
	.inset-xxl-right-30 {
		padding-right: 30px;
	}
	.inset-xxl-right-40 {
		padding-right: 40px;
	}
	.inset-xxl-right-50 {
		padding-right: 50px;
	}
	.inset-xxl-right-60 {
		padding-right: 60px;
	}
	.inset-xxl-right-70 {
		padding-right: 70px;
	}
	.inset-xxl-right-85 {
		padding-right: 85px;
	}
	.inset-xxl-right-100 {
		padding-right: 100px;
	}
}

.container + .container {
	margin-top: 60px;
}

h3.section-title {
    color: #000;
}
h4 + .section-title {
	margin-top: 2px;
}

h4 + .comment-list {
	margin-top: 30px;
}

h3 + p {
	margin-top: 15px;
}

h3 + p.h4 {
	margin-top: 2px;
}

h3 + .row {
	margin-top: 40px;
}

h3 + * {
	margin-top: 40px;
}

.row + .row {
	margin-top: 60px;
}

* + .row.list-md-dashed {
	margin-top: 60px;
}

.row + .button-block {
	margin-top: 60px;
}

.slick-slider + .slick-slider.carousel-parent {
	margin-top: 35px;
}

.quote-left + .button-block {
	margin-top: 22px;
}

.aside-title + * {
	margin-top: 22px;
}

* + .button-group {
	margin-top: 25px;
}

html .page .offset-top-0 {
	margin-top: 0;
}

html .page .offset-top-2 {
	margin-top: 2px;
}

html .page .offset-top-5 {
	margin-top: 5px;
}

html .page .offset-top-10 {
	margin-top: 10px;
}

html .page .offset-top-15 {
	margin-top: 15px;
}

html .page .offset-top-22 {
	margin-top: 22px;
}

html .page .offset-top-27 {
	margin-top: 27px;
}

html .page .offset-top-30 {
	margin-top: 30px;
}

html .page .offset-top-35 {
	margin-top: 35px;
}

html .page .offset-top-40 {
	margin-top: 40px;
}

html .page .offset-top-45 {
	margin-top: 45px;
}

html .page .offset-top-50 {
	margin-top: 50px;
}

html .page .offset-top-60 {
	margin-top: 60px;
}

html .page .offset-top-75 {
	margin-top: 75px;
}

html .page .offset-top-90 {
	margin-top: 90px;
}

html .page .offset-top-100 {
	margin-top: 100px;
}

html .page .offset-top-120 {
	margin-top: 120px;
}

@media (min-width: 576px) {
	html .page .offset-sm-top-0 {
		margin-top: 0;
	}
	html .page .offset-sm-top-2 {
		margin-top: 2px;
	}
	html .page .offset-sm-top-5 {
		margin-top: 5px;
	}
	html .page .offset-sm-top-10 {
		margin-top: 10px;
	}
	html .page .offset-sm-top-15 {
		margin-top: 15px;
	}
	html .page .offset-sm-top-22 {
		margin-top: 22px;
	}
	html .page .offset-sm-top-27 {
		margin-top: 27px;
	}
	html .page .offset-sm-top-30 {
		margin-top: 30px;
	}
	html .page .offset-sm-top-35 {
		margin-top: 35px;
	}
	html .page .offset-sm-top-40 {
		margin-top: 40px;
	}
	html .page .offset-sm-top-45 {
		margin-top: 45px;
	}
	html .page .offset-sm-top-50 {
		margin-top: 50px;
	}
	html .page .offset-sm-top-60 {
		margin-top: 60px;
	}
	html .page .offset-sm-top-75 {
		margin-top: 75px;
	}
	html .page .offset-sm-top-90 {
		margin-top: 90px;
	}
	html .page .offset-sm-top-100 {
		margin-top: 100px;
	}
	html .page .offset-sm-top-120 {
		margin-top: 120px;
	}
}

@media (min-width: 768px) {
	html .page .offset-md-top-0 {
		margin-top: 0;
	}
	html .page .offset-md-top-2 {
		margin-top: 2px;
	}
	html .page .offset-md-top-5 {
		margin-top: 5px;
	}
	html .page .offset-md-top-10 {
		margin-top: 10px;
	}
	html .page .offset-md-top-15 {
		margin-top: 15px;
	}
	html .page .offset-md-top-22 {
		margin-top: 22px;
	}
	html .page .offset-md-top-27 {
		margin-top: 27px;
	}
	html .page .offset-md-top-30 {
		margin-top: 30px;
	}
	html .page .offset-md-top-35 {
		margin-top: 35px;
	}
	html .page .offset-md-top-40 {
		margin-top: 40px;
	}
	html .page .offset-md-top-45 {
		margin-top: 45px;
	}
	html .page .offset-md-top-50 {
		margin-top: 50px;
	}
	html .page .offset-md-top-60 {
		margin-top: 60px;
	}
	html .page .offset-md-top-75 {
		margin-top: 75px;
	}
	html .page .offset-md-top-90 {
		margin-top: 90px;
	}
	html .page .offset-md-top-100 {
		margin-top: 100px;
	}
	html .page .offset-md-top-120 {
		margin-top: 120px;
	}
}

@media (min-width: 992px) {
	html .page .offset-lg-top-0 {
		margin-top: 0;
	}
	html .page .offset-lg-top-2 {
		margin-top: 2px;
	}
	html .page .offset-lg-top-5 {
		margin-top: 5px;
	}
	html .page .offset-lg-top-10 {
		margin-top: 10px;
	}
	html .page .offset-lg-top-15 {
		margin-top: 15px;
	}
	html .page .offset-lg-top-22 {
		margin-top: 22px;
	}
	html .page .offset-lg-top-27 {
		margin-top: 27px;
	}
	html .page .offset-lg-top-30 {
		margin-top: 30px;
	}
	html .page .offset-lg-top-35 {
		margin-top: 35px;
	}
	html .page .offset-lg-top-40 {
		margin-top: 40px;
	}
	html .page .offset-lg-top-45 {
		margin-top: 45px;
	}
	html .page .offset-lg-top-50 {
		margin-top: 50px;
	}
	html .page .offset-lg-top-60 {
		margin-top: 60px;
	}
	html .page .offset-lg-top-75 {
		margin-top: 75px;
	}
	html .page .offset-lg-top-90 {
		margin-top: 90px;
	}
	html .page .offset-lg-top-100 {
		margin-top: 100px;
	}
	html .page .offset-lg-top-120 {
		margin-top: 120px;
	}
}

@media (min-width: 1200px) {
	html .page .offset-xl-top-0 {
		margin-top: 0;
	}
	html .page .offset-xl-top-2 {
		margin-top: 2px;
	}
	html .page .offset-xl-top-5 {
		margin-top: 5px;
	}
	html .page .offset-xl-top-10 {
		margin-top: 10px;
	}
	html .page .offset-xl-top-15 {
		margin-top: 15px;
	}
	html .page .offset-xl-top-22 {
		margin-top: 22px;
	}
	html .page .offset-xl-top-27 {
		margin-top: 27px;
	}
	html .page .offset-xl-top-30 {
		margin-top: 30px;
	}
	html .page .offset-xl-top-35 {
		margin-top: 35px;
	}
	html .page .offset-xl-top-40 {
		margin-top: 40px;
	}
	html .page .offset-xl-top-45 {
		margin-top: 45px;
	}
	html .page .offset-xl-top-50 {
		margin-top: 50px;
	}
	html .page .offset-xl-top-60 {
		margin-top: 60px;
	}
	html .page .offset-xl-top-75 {
		margin-top: 75px;
	}
	html .page .offset-xl-top-90 {
		margin-top: 90px;
	}
	html .page .offset-xl-top-100 {
		margin-top: 100px;
	}
	html .page .offset-xl-top-120 {
		margin-top: 120px;
	}
}

@media (min-width: 1800px) {
	html .page .offset-xxl-top-0 {
		margin-top: 0;
	}
	html .page .offset-xxl-top-2 {
		margin-top: 2px;
	}
	html .page .offset-xxl-top-5 {
		margin-top: 5px;
	}
	html .page .offset-xxl-top-10 {
		margin-top: 10px;
	}
	html .page .offset-xxl-top-15 {
		margin-top: 15px;
	}
	html .page .offset-xxl-top-22 {
		margin-top: 22px;
	}
	html .page .offset-xxl-top-27 {
		margin-top: 27px;
	}
	html .page .offset-xxl-top-30 {
		margin-top: 30px;
	}
	html .page .offset-xxl-top-35 {
		margin-top: 35px;
	}
	html .page .offset-xxl-top-40 {
		margin-top: 40px;
	}
	html .page .offset-xxl-top-45 {
		margin-top: 45px;
	}
	html .page .offset-xxl-top-50 {
		margin-top: 50px;
	}
	html .page .offset-xxl-top-60 {
		margin-top: 60px;
	}
	html .page .offset-xxl-top-75 {
		margin-top: 75px;
	}
	html .page .offset-xxl-top-90 {
		margin-top: 90px;
	}
	html .page .offset-xxl-top-100 {
		margin-top: 100px;
	}
	html .page .offset-xxl-top-120 {
		margin-top: 120px;
	}
}

@media (min-width: 768px) {
	.shift-sm-top-1 {
		margin-top: -18px;
	}
}

@media (min-width: 992px) {
	.shift-sm-top-1 {
		margin-top: -23px;
	}
}

@media (min-width: 992px) {
	.shift-md-top-1 {
		margin-top: -33px;
	}
}

@media (min-width: 1200px) {
	.shift-md-top-1 {
		margin-top: -43px;
	}
}

.row-0 {
	margin-bottom: 0px;
}

.row-0:empty {
	margin-bottom: 0;
}

.row-0 > * {
	margin-bottom: 0px;
}

.row-15 {
	margin-bottom: -15px;
}

.row-15:empty {
	margin-bottom: 0;
}

.row-15 > * {
	margin-bottom: 15px;
}

.row-20 {
	margin-bottom: -20px;
}

.row-20:empty {
	margin-bottom: 0;
}

.row-20 > * {
	margin-bottom: 20px;
}

.row-30 {
	margin-bottom: -30px;
}

.row-30:empty {
	margin-bottom: 0;
}

.row-30 > * {
	margin-bottom: 30px;
}

.row-40 {
	margin-bottom: -40px;
}

.row-40:empty {
	margin-bottom: 0;
}

.row-40 > * {
	margin-bottom: 40px;
}

.row-50 {
	margin-bottom: -50px;
}

.row-50:empty {
	margin-bottom: 0;
}

.row-50 > * {
	margin-bottom: 50px;
}

.row-60 {
	margin-bottom: -60px;
}

.row-60:empty {
	margin-bottom: 0;
}

.row-60 > * {
	margin-bottom: 60px;
}

@media (min-width: 576px) {
	.row-sm-50 {
		margin-bottom: -50px;
	}
	.row-sm-50:empty {
		margin-bottom: 0;
	}
	.row-sm-50 > * {
		margin-bottom: 50px;
	}
	.row-sm-0 {
		margin-bottom: 0px;
	}
	.row-sm-0:empty {
		margin-bottom: 0;
	}
	.row-sm-0 > * {
		margin-bottom: 0px;
	}
}

@media (min-width: 768px) {
	.row-md-60 {
		margin-bottom: -60px;
	}
	.row-md-60:empty {
		margin-bottom: 0;
	}
	.row-md-60 > * {
		margin-bottom: 60px;
	}
}

@media (min-width: 992px) {
	.row-md-30 {
		margin-bottom: -30px;
	}
	.row-md-30:empty {
		margin-bottom: 0;
	}
	.row-md-30 > * {
		margin-bottom: 30px;
	}
}

@media (min-width: 1200px) {
	.row-xl-100 {
		margin-bottom: -100px;
	}
	.row-xl-100:empty {
		margin-bottom: 0;
	}
	.row-xl-100 > * {
		margin-bottom: 100px;
	}
	.row-xl-90 {
		margin-bottom: -90px;
	}
	.row-xl-90:empty {
		margin-bottom: 0;
	}
	.row-xl-90 > * {
		margin-bottom: 90px;
	}
}

.link {
	display: inline-block;
}

.link-inline {
	font: inherit;
	line-height: inherit;
	text-decoration: underline;
}

.link-underline, .link-underline:active, .link-underline:focus {
	text-decoration: underline;
}

.link-underline:hover {
	text-decoration: none;
}

.link-circle {
	border-radius: 50%;
}

.link-circle .icon,
.link-circle .icon:before {
	position: static;
}

.link-bold {
	font: 700 18px/22px "Roboto", Helvetica, Arial, sans-serif;
}

.link-group {
	white-space: nowrap;
}

.link-group * {
	vertical-align: middle;
}

.link-group span {
	display: inline-block;
}

.link-group span + *,
.link-group * + span {
	margin-left: 5px;
}

.link-group.link-group-animated .icon {
	position: relative;
	right: 0;
	transition: .22s;
}

.link-group.link-group-animated:hover .icon {
	right: -5px;
}

.link-group-baseline * {
	vertical-align: baseline;
}

.link-icon, .link-icon * {
	vertical-align: middle;
}

.link-icon .icon {
	margin-right: 5px;
}

.link-icon-mod .icon {
	position: relative;
	top: -3px;
}

.link-image img {
	width: auto;
	transition: .44s all ease;
	opacity: .5;
}

.link-image:hover img {
	opacity: 1;
}

.link-image-wrap {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: center;
	-ms-flex-pack: center;
	justify-content: center;
	min-height: 126px;
}

* + .link-image-wrap {
	margin-top: 13px;
}

.page .link-primary-inline {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.page .link-primary-inline.active, .page .link-primary-inline:active, .page .link-primary-inline:focus {
	color: #9b9b9b;
}

.page .link-primary-inline.hover, .page .link-primary-inline:hover {
	color: #42b294;
}

.page .link-default, .page .link-default:active, .page .link-default:focus {
	color: #9f9f9f;
}

.page .link-default:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.page .link-primary, .page .link-primary:active, .page .link-primary:focus {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.page .link-primary:hover {
	color: #00030a;
}

.page .link-primary-inverse, .page .link-primary-inverse:active, .page .link-primary-inverse:focus {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.page .link-primary-inverse:hover {
	color: #ddd;
}

.page .link-primary-inverse-v2, .page .link-primary-inverse-v2:active, .page .link-primary-inverse-v2:focus {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.page .link-primary-inverse-v2:hover {
	color: #fff;
}

.page .link-secondary, .page .link-secondary:active, .page .link-secondary:focus {
	color: #00030a;
}

.page .link-secondary:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.page .link-tundora, .page .link-tundora:active, .page .link-tundora:focus {
	color: #414141;
}

.page .link-tundora:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.page .link-tundora-inverse, .page .link-tundora-inverse:active, .page .link-tundora-inverse:focus {
	color: #414141;
}

.page .link-tundora-inverse:hover {
	color: #fff;
}

.page .link-secondary, .page .link-secondary:active, .page .link-secondary:focus {
	color: #000;
}

.page .link-secondary:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.page .link-gray-light, .page .link-gray-light:active, .page .link-gray-light:focus {
	color: #dedede;
}

.page .link-gray-light:hover {
	color: #000;
}

.page .link-white, .page .link-white:active, .page .link-white:focus {
	color: #fff;
}
.page .link-white:hover
{
    color: #fff;
}

.page .link-black, .page .link-black:active, .page .link-black:focus {
	color: #000;
}

.page .link-black:hover {
	color: <?php echo empty($website->maincolorbis) ? 'rgb(50, 120, 180)' : '#'.$website->maincolorbis; ?>;
}

.page .link-black:hover {
	text-decoration: underline;
}

.page .link-gray-dark-filled, .page .link-gray-dark-filled:active, .page .link-gray-dark-filled:focus {
	color: #fff;
	background: #2a2b2b;
}

.page .link-gray-dark-filled:hover {
	color: #fff;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.page .link-shop {
	width: 25px;
	height: 25px;
	font-size: 25px;
	line-height: 25px;
}

.page .link-shop, .page .link-shop:active, .page .link-shop:focus {
	color: #00030a;
}

.page .link-shop:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

ul,
ol {
	list-style: none;
	padding: 0;
	margin: 0;
}

dl {
	margin: 0;
}

dt {
	font-weight: inherit;
}

.list > li + li {
	margin-top: 5px;
}

.list-xl > li + li {
	margin-top: 44px;
}

.list-inline {
	margin-left: -5px;
	margin-right: -5px;
	vertical-align: baseline;
}

.list-inline > li {
	display: inline-block;
	padding-left: 5px;
	padding-right: 5px;
}

.list-inline-reset {
	font-size: 0;
	line-height: 0;
}

.list-inline-xs {
	margin-left: -6px;
	margin-right: -6px;
}

.list-inline-xs > li {
	display: inline-block;
	padding-left: 6px;
	padding-right: 6px;
}

.list-inline-sm {
	margin-left: -10px;
	margin-right: -10px;
}

.list-inline-sm > li {
	display: inline-block;
	padding-left: 10px;
	padding-right: 10px;
}

.list-inline-md {
	margin-left: -15px;
	margin-right: -15px;
}

.list-inline-md > li {
	display: inline-block;
	padding-left: 15px;
	padding-right: 15px;
}

.list-objects-inline {
	margin-bottom: -4px;
	margin-left: -22px;
	transform: translateY(-4px);
}

.list-objects-inline > *, .list-objects-inline > *:first-child {
	display: inline-block;
	vertical-align: middle;
	margin-top: 4px;
	margin-left: 22px;
}

.list-objects-inline > li > * {
	display: inline-block;
	vertical-align: middle;
}

.list-objects-inline > li > * + * {
	margin-left: 5px;
}

.list-terms dt + dd {
	margin-top: 10px;
}

.list-terms dd + dt {
	margin-top: 31px;
}

.list-terms-variant-1 dt {
	font: 700 16px/22px "Roboto", Helvetica, Arial, sans-serif;
	letter-spacing: -.025em;
	color: #000;
}

.list-terms-variant-1 dt + dd {
	margin-top: 18px;
}

.list-terms-variant-1 dd + dt {
	margin-top: 40px;
}

@media (min-width: 1200px) {
	.list-terms-variant-1 dt {
		font-size: 24px;
		line-height: 1.2;
	}
	.list-terms-variant-1 dd + dt {
		margin-top: 50px;
	}
}

.list-inline-dashed {
	margin-left: -15px;
}

.list-inline-dashed li {
	padding-left: 15px;
	padding-right: 10px;
}

.list-inline-dashed li:after {
	content: '|';
	position: relative;
	right: -12.5px;
	color: #e5e7e9;
}

.list-inline-dashed li:last-child {
	padding-right: 0;
}

.list-inline-dashed li:last-child:after {
	display: none;
}

@media (min-width: 992px) {
	.list-md-dashed > * {
		position: relative;
	}
	.list-md-dashed > *:after {
		content: '';
		position: absolute;
		font-weight: 100;
		top: 0;
		right: -6%;
		height: 73px;
		-webkit-transform: translateX(-50%) skew(-21deg);
		transform: translateX(-50%) skew(-21deg);
		width: 1px;
		background: #48494a;
	}
}

@media (min-width: 992px) and (min-width: 1200px) {
	.list-md-dashed > *:after {
		right: -3%;
		height: 120px;
	}
}

@media (min-width: 992px) {
	.list-md-dashed > *:last-child::after {
		display: none;
	}
}

.dl-inline {
	vertical-align: middle;
}

.dl-inline dt,
.dl-inline dd {
	display: inline-block;
	vertical-align: middle;
}

.dl-inline dt {
	padding-right: 5px;
}

.dl-inline dt:after {
	content: ':';
}

.dl-inline .pricing-object-sm {
	position: relative;
	top: -5px;
}

.list-terms-inline dt, .list-terms-inline dd {
	display: inline-block;
}

.list-terms-inline dt {
	color: #000;
}

.list-terms-inline dd {
	color: #9f9f9f;
}

.list-terms-inline dt:after {
	content: ':';
}

.list-index {
	counter-reset: li;
}

.list-index > li .list-index-counter:before {
	content: counter(li, decimal-leading-zero);
	counter-increment: li;
}

.list-marked li {
	color: #000;
	position: relative;
	padding-left: 32px;
}

.list-marked li:before {
	position: absolute;
	top: 1px;
	left: 0;
	content: '\e005';
	font-family: "fl-flat-icons-set-2";
	display: inline-block;
	margin-right: 11px;
	font-size: 13px;
	line-height: inherit;
	vertical-align: middle;
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.list-marked li:not(:last-child):after {
	content: ';';
}

.list-marked li:last-child:after {
	content: '.';
}

.list-marked li + li {
	margin-top: 11px;
}

.list-marked-spacing-lg li {
	padding-left: 26px;
}

@media (min-width: 992px) and (max-width: 1799px) {
	.list-marked li {
		padding-left: 24px;
		font-size: 13px;
	}
	.list-marked li:before {
		font-size: 11px;
	}
}

.list-marked-variant-2 > li > a {
	position: relative;
	display: inline-block;
}

.list-marked-variant-2 > li > a:hover:before {
	left: 4px;
}

.list-marked-variant-2 > li + li {
	margin-top: 14px;
}

.list-ordered {
	counter-reset: li;
}

.list-ordered li {
	color: #000;
}

.list-ordered li:before {
	display: inline-block;
	margin-right: 13px;
	width: 15px;
	content: counter(li, decimal) ".";
	counter-increment: li;
}

.list-ordered li:not(:last-child):after {
	content: ';';
}

.list-ordered li:last-child:after {
	content: '.';
}

.list-ordered li + li {
	margin-top: 11px;
}

.list-tags > li {
	display: inline-block;
	font-style: italic;
}

.list-tags > li a, .list-tags > li a:active, .list-tags > li a:focus {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.list-tags > li a:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.list-tags > li:after {
	content: ',';
	display: inline-block;
	color: #f9f9f9;
}

.list-tags > li:last-child:after {
	display: none;
}

.list-numbered {
	counter-reset: li;
}

.list-numbered > li {
	position: relative;
	padding-left: 30px;
}

.list-numbered > li:before {
	position: absolute;
	top: 0;
	left: 0;
	content: counter(li, decimal) ".";
	counter-increment: li;
}

.list-numbered > li + li {
	margin-top: 10px;
}

.list-icon-pack {
	margin-top: 6px;
}

.list-icon-pack > li {
	margin-top: 25px;
}

.list-icon-pack > li span {
	display: block;
}

.list-icon-pack > li span + span {
	margin-left: .25em;
}

.list-icon-pack h6 + *,
.list-icon-pack .h6 + * {
	margin-top: 2px;
}

.list-links > li {
	display: inline-block;
}

.list-links > li:after {
	content: ';';
}

.list-links > li:last-child:after {
	display: none;
}

.list-hashtags > li {
	display: inline-block;
}

.list-hashtags > li a {
	color: inherit;
}

.list-hashtags > li a:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.list-hashtags > li > a:before {
	content: '#';
}

.list-marked-bordered {
	color: #000;
}

.list-marked-bordered li a {
	display: block;
	padding: 10px 7px;
	border-bottom: 1px solid #f9f9f9;
}

.list-marked-bordered li a:before {
	position: relative;
	display: inline-block;
	padding-right: 10px;
	font: 400 18px "FontAwesome";
	line-height: inherit;
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	content: '\f105';
}

.list-marked-bordered li a span {
	color: inherit;
	transition: color .33s;
}

.list-marked-bordered li a span:first-child {
	color: #000;
}

.list-marked-bordered li a:hover, .list-marked-bordered li a:hover span:nth-child(n) {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.list-marked-bordered li span:not(:last-child) {
	margin-right: .25em;
}

.list-bordered-horizontal {
	position: relative;
	transform: translateY(-7px);
	margin-bottom: -7px;
}

.list-bordered-horizontal > * {
	margin-top: 7px;
}

.list-bordered-horizontal > *:not(:last-child) {
	margin-right: 35px;
}

@media (min-width: 768px) {
	.list-bordered-horizontal > li {
		display: inline-block;
	}
	.list-bordered-horizontal > li:not(:last-child) {
		position: relative;
	}
	.list-bordered-horizontal > li:not(:last-child):after {
		content: '';
		position: absolute;
		top: 50%;
		transform: translateY(-50%);
		right: -20px;
		width: 1px;
		height: 22px;
		background: #dedede;
	}
}

.list-tag-blocks {
	position: relative;
	transform: translateY(-6px);
	margin-bottom: -6px;
}

.list-tag-blocks > * {
	margin-top: 6px;
}

.list-tag-blocks > *:not(:last-child) {
	margin-right: 6px;
}

.list-tag-blocks li {
	display: inline-block;
	font-size: 11px;
	font-weight: 700;
	text-transform: uppercase;
}

.list-tag-blocks li a {
	display: inline-block;
	padding: 6px 19px;
	border-radius: 0;
	border: 1px solid transparent;
}

.list-tag-blocks li a, .list-tag-blocks li a:active, .list-tag-blocks li a:focus {
	color: #000;
	background: #fff;
}

.list-tag-blocks li a:hover {
	background: transparent;
	border-color: #cdcdcd;
}

.list-progress {
	font-family: "Roboto", Helvetica, Arial, sans-serif;
	color: #00030a;
}

.list-progress li + li {
	margin-top: 23px;
}

.list-progress p {
	padding-right: 40px;
}

.list-tags-inline > li {
	display: inline;
}

.list-tags-inline > li a {
	color: inherit;
}

.list-tags-inline > li a:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.list-tags-inline > li:not(:last-child):after {
	content: ',';
}

.list-rating {
	font-size: 0;
	line-height: 0;
}

.list-rating > li {
	display: inline-block;
}

.list-rating .icon {
	color: #ffd400;
}

.list-wide-bordered {
	color: #00030a;
	font: 400 14px/22px "Roboto", Helvetica, Arial, sans-serif;
	border-top: 1px solid #dedede;
}

.list-wide-bordered dl {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: space-between;
	-ms-flex-pack: justify;
	justify-content: space-between;
	width: 100%;
	font-weight: 700;
}

.list-wide-bordered dl dt {
	padding-right: 15px;
}

.list-wide-bordered dl dd {
	font-weight: 700;
	font-size: 14px;
}

.list-wide-bordered li {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	min-height: 54px;
	padding: 10px 20px;
	border-bottom: 1px solid #dedede;
}

.list-wide-bordered + .list-wide-bordered {
	border-top: 0;
}

@media (min-width: 768px) {
	.list-wide-bordered {
		font-size: 16px;
	}
	.list-wide-bordered li {
		min-height: 73px;
		padding: 20px 30px;
	}
}

.object-wrap {
	position: relative;
	overflow: hidden;
}

.object-wrap-right > .object-wrap-body {
	right: 0;
}

.object-wrap-left > .object-wrap-body {
	left: 0;
}

@media (min-width: 768px) {
	.object-wrap-sm-right > .object-wrap-body {
		right: 0;
	}
	.object-wrap-sm-left > .object-wrap-body {
		left: 0;
	}
}

@media (max-width: 767px) {
	.object-wrap-body {
		position: relative;
		overflow: hidden;
		min-height: 300px;
		width: 100%;
	}
	.object-wrap-body > img {
		position: absolute;
		min-width: 100%;
		max-width: none;
		height: auto;
		max-height: none;
		top: 20%;
		left: 50%;
		transform: translate(-50%, -20%);
	}
}

@media (min-width: 768px) {
	.object-wrap-body {
		overflow: hidden;
		position: absolute;
		top: 0;
		bottom: 0;
		width: 100vw;
		min-width: 1px;
		max-width: none;
		height: 100%;
		min-height: 100%;
		max-height: none;
		margin: 0;
		background: inherit;
		z-index: 0;
	}
	.object-wrap-body > img {
		position: relative;
		height: auto;
		min-height: 100.5%;
		width: auto;
		min-width: 102%;
		max-width: none;
		left: 50%;
		transform: translateX(-50%);
	}
	.object-wrap-body + * {
		margin-top: 0;
	}
}

@media (min-width: 768px) {
	.sm-width-c6 {
		width: calc(50vw - 720px / 2 + (720px / 12) * 6);
	}
}

@media (min-width: 992px) {
	.md-width-c7d20 {
		width: calc(50vw - 960px / 2 + 20px + (960px / 12) * 7);
	}
}

@media (min-width: 1200px) {
	.md-width-c7d20 {
		width: calc(50vw - 1170px / 2 + 20px + (1170px / 12) * 7);
	}
}

@media (min-width: 992px) {
	.md-width-c5dm20 {
		width: calc(50vw - 960px / 2 - 20px + (960px / 12) * 5);
	}
}

@media (min-width: 1200px) {
	.md-width-c5dm20 {
		width: calc(50vw - 1170px / 2 - 20px + (1170px / 12) * 5);
	}
}

.bg-wrap {
	position: relative;
}

.bg-wrap:before {
	content: '';
	position: absolute;
	top: 0;
	bottom: 0;
	width: 120vw;
	left: 50%;
	transform: translateX(-50%);
	background: inherit;
	z-index: -1;
}

.bg-wrap-sm-left {
	z-index: 1;
}

@media (min-width: 992px) {
	.bg-wrap-sm-left:before {
		width: 100vw;
		right: 0;
		transform: none;
	}
}

.bg-wrap-sm-right {
	z-index: 1;
}

@media (min-width: 992px) {
	.bg-wrap-sm-right:before {
		width: 100vw;
		left: 0;
		transform: none;
	}
}

@media (min-width: 576px) {
	.wrap-justify {
		display: -ms-flexbox;
		display: -webkit-flex;
		display: flex;
		-webkit-flex-direction: row;
		-ms-flex-direction: row;
		flex-direction: row;
		-webkit-flex-wrap: nowrap;
		-ms-flex-wrap: nowrap;
		flex-wrap: nowrap;
		-webkit-align-items: center;
		-ms-flex-align: center;
		align-items: center;
		-webkit-justify-content: space-around;
		-ms-flex-pack: distribute;
		justify-content: space-around;
	}
	.wrap-justify > * + * {
		margin-top: 0;
	}
}

@media (min-width: 768px) {
	.wrap-justify {
		-webkit-justify-content: space-between;
		-ms-flex-pack: justify;
		justify-content: space-between;
	}
}

@media (min-width: 1200px) {
	.wrap-justify {
		padding-right: 30px;
	}
}

.link-wrap {
	line-height: 1;
}

.link-wrap a {
	display: inline;
	line-height: 1;
}

[class*='bg-decoration-wrap'] {
	position: relative;
	overflow: hidden;
}

[class*='bg-decoration-wrap'] .bg-decoration-content {
	position: relative;
	z-index: 2;
}

[class*='bg-decoration-wrap'] .bg-decoration-object {
	top: 0;
	bottom: auto;
}

.bg-decoration-bottom .bg-decoration-object {
	top: auto;
	bottom: 0;
}

@media (min-width: 768px) {
	.bg-decoration-wrap-sm .bg-decoration-object {
		height: 50%;
		position: absolute;
		right: 0;
		left: 0;
	}
	.bg-decoration-bottom-sm .bg-decoration-object {
		height: 34%;
	}
}

@media (min-width: 1200px) {
	.bg-decoration-object {
		height: 50%;
		position: absolute;
		right: 0;
		left: 0;
	}
	.bg-decoration-bottom-mod .bg-decoration-object {
		height: 45%;
	}
}

.image-group {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: flex-end;
	-ms-flex-align: end;
	align-items: flex-end;
}

.image-group img {
	position: relative;
	height: auto !important;
	max-width: none;
	width: 100% !important;
}

.image-group figure {
	position: relative;
}

.image-group figure:nth-child(1) {
	z-index: 3;
	max-width: 194px;
	min-width: 29%;
}

.image-group figure:nth-child(1) img {
	transform: translateY(-1.7%);
	left: -3px;
}

.image-group figure:nth-child(2) {
	z-index: 2;
	max-width: 404px;
	min-width: 60%;
	margin-left: -29.5%;
}

.image-group figure:nth-child(2) img {
	transform: translateY(8%);
}

.image-group figure:nth-child(3) {
	z-index: 1;
	max-width: 546px;
	min-width: 82%;
	margin-left: -42.5%;
}

.image-group figure:nth-child(3) img {
	transform: translateY(-1.9%);
}

.image-group-extended {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: flex-end;
	-ms-flex-align: end;
	align-items: flex-end;
}

@media (min-width: 768px) {
	.image-wrap-1 {
		padding-right: 15px;
	}
}

@media (min-width: 1200px) {
	.image-wrap-1 {
		padding-right: 0;
		margin-right: -10px;
	}
}

.image-wrap-1 img {
	max-width: 107%;
}

@media (min-width: 992px) {
	.image-wrap-2 {
		position: relative;
		right: -14px;
		top: 12px;
	}
}

.image-wrap-3 {
	position: relative;
	transform: translate3d(0, 0, 0) scale(1.02);
	margin-top: -5px;
	margin-left: -53px;
}

.divider {
	width: 49px;
	height: 2px;
	margin-left: auto;
	margin-right: auto;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.divider-fullwidth {
	height: 1px;
	width: 100%;
}

.divider-circle {
	position: relative;
	width: 100%;
	height: 10px;
}

.divider-circle:after {
	content: '';
	position: absolute;
	top: 50%;
	left: 50%;
	width: 10px;
	height: 10px;
	transform: translate(-50%, -50%);
	border-radius: 50px;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.divider-triangle {
	height: 8px;
}

.hr {
	border: none;
	height: 1px;
	width: 100%;
}

.divider-md {
	height: 1px;
	width: 119px;
}

* + .divider-triangle,
* + .divider-circle {
	margin-top: 32px;
}

@media (min-width: 768px) {
	* + .divider-circle {
		margin-top: 50px;
	}
}

.tabs-custom .nav-tabs {
	display: block;
	word-spacing: 0;
	border: 0;
}

.tabs-custom .nav-tabs:before, .tabs-custom .nav-tabs:after {
	display: none;
}

.tabs-custom .nav-tabs .nav-item {
	float: none;
	border: 0;
	cursor: pointer;
	transition: .33s all ease;
}

.tabs-custom .nav-tabs .nav-item .nav-link.active {
	cursor: default;
	border: 0;
}

.tabs-custom .nav-tabs .nav-link {
	margin: 0;
	border: 0;
}

* + .tabs-custom {
	margin-top: 35px;
}

@media (min-width: 992px) {
	* + .tabs-custom {
		margin-top: 50px;
	}
}

.tabs-custom.tabs-corporate .nav-tabs, .tabs-custom.tabs-line .nav-tabs, .tabs-custom.tabs-minimal .nav-tabs {
	font-size: 0;
	line-height: 0;
}

.tabs-custom.tabs-corporate .nav-tabs {
	border: 1px solid #dedede;
}

.tabs-custom.tabs-corporate .nav-tabs li {
	margin: -1px 0;
}

.tabs-custom.tabs-corporate .nav-tabs .nav-item .nav-link {
	padding: 8px 10px;
	font: 700 11px/18px "Roboto", Helvetica, Arial, sans-serif;
	color: #000;
	background: transparent;
	border-bottom: 1px solid #dedede;
	text-align: center;
	vertical-align: middle;
}

.tabs-custom.tabs-corporate .nav-tabs .nav-item .nav-link:after {
	font: 400 17px 'Material Design Icons';
	color: transparent;
	position: relative;
	top: -12px;
	display: inline-block;
	margin-left: 5px;
	content: '\f236';
	vertical-align: middle;
	transition: .33s all ease;
}

.tabs-custom.tabs-corporate .nav-tabs .nav-item .nav-link:first-child {
	border-top: 1px solid #dedede;
}

.tabs-custom.tabs-corporate .nav-tabs .nav-item .nav-link:hover,
.tabs-custom.tabs-corporate .nav-tabs .nav-item .active.nav-link {
	color: #fff;
	background: #3a3c3e;
	border-color: #3a3c3e;
}

.tabs-custom.tabs-corporate .nav-tabs .nav-item .nav-link:hover:after,
.tabs-custom.tabs-corporate .nav-tabs .nav-item .active.nav-link:after {
	top: -1px;
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.tabs-custom.tabs-corporate .tab-content {
	padding: 22px 0 0;
}

.tabs-custom.tabs-line .nav-tabs .nav-item, .tabs-custom.tabs-minimal .nav-tabs .nav-item {
	margin: 0;
}

.tabs-custom.tabs-line .nav-tabs .nav-item + .nav-item, .tabs-custom.tabs-minimal .nav-tabs .nav-item + .nav-item {
	margin-top: -1px;
}

.tabs-custom.tabs-line .tab-content, .tabs-custom.tabs-minimal .tab-content {
	padding: 22px 0 0;
}

.tabs-custom.tabs-line .nav-tabs .nav-item .nav-link {
	font: 400 11px/16px "Roboto", Helvetica, Arial, sans-serif;
	letter-spacing: -.05em;
	text-transform: uppercase;
	color: #9b9b9b;
}

.tabs-custom.tabs-line .nav-tabs .nav-item .nav-link:hover,
.tabs-custom.tabs-line .nav-tabs .nav-item .active.nav-link {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.tabs-custom.tabs-minimal .nav-tabs .nav-item .nav-link {
	font: 700 11px/24px "Roboto", Helvetica, Arial, sans-serif;
	color: #000;
}

.tabs-custom.tabs-minimal .nav-tabs .nav-item .nav-link:hover,
.tabs-custom.tabs-minimal .nav-tabs .nav-item .active.nav-link {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.tabs-custom.tabs-line .nav-tabs {
	text-align: center;
}

.tabs-custom.tabs-line .nav-tabs .nav-item {
	display: block;
	margin: 0 -1px;
}

.tabs-custom.tabs-line .nav-tabs .nav-item .nav-link {
	padding: 8px 15px;
	border: 1px solid #e5e7e9;
}

.tabs-custom.tabs-line .nav-tabs .nav-item .nav-link:last-child {
	margin-right: 0;
	border-bottom-width: 1px;
}

.tabs-custom.tabs-line .nav-tabs .nav-item .nav-link:hover,
.tabs-custom.tabs-line .nav-tabs .nav-item .active.nav-link {
	color: #fff;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	border-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.tabs-custom.tabs-minimal .nav-tabs {
	text-align: center;
}

.tabs-custom.tabs-minimal .nav-tabs .nav-item {
	display: block;
}

.tabs-custom.tabs-minimal .nav-tabs .nav-item .nav-link {
	padding: 7px 15px;
	border: 1px solid #e5e7e9;
}

.tabs-custom.tabs-minimal .nav-tabs .nav-item .nav-link:last-child {
	border-bottom-width: 1px;
}

.tabs-custom.tabs-minimal .nav-tabs .nav-item .nav-link:hover,
.tabs-custom.tabs-minimal .nav-tabs .nav-item .active.nav-link {
	color: #fff;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	border-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

@media (min-width: 768px) {
	.tabs-custom.tabs-line .nav-item, .tabs-custom.tabs-minimal .nav-item {
		margin: 0;
	}
	.tabs-custom.tabs-line .nav-tabs .nav-item .nav-link {
		font-size: 14px;
		line-height: 24px;
	}
	.tabs-custom.tabs-minimal .nav-tabs .nav-item .nav-link {
		font-size: 14px;
		line-height: 24px;
	}
	.tabs-custom.tabs-horizontal.tabs-corporate .nav-tabs, .tabs-custom.tabs-horizontal.tabs-line .nav-tabs {
		display: -ms-flexbox;
		display: -webkit-flex;
		display: flex;
		-webkit-flex-direction: row;
		-ms-flex-direction: row;
		flex-direction: row;
		-webkit-align-items: center;
		-ms-flex-align: center;
		align-items: center;
		width: 100%;
		text-align: left;
	}
	.tabs-custom.tabs-horizontal.tabs-line .nav-tabs .nav-item .nav-link, .tabs-custom.tabs-horizontal.tabs-minimal .nav-tabs .nav-item .nav-link {
		position: relative;
		z-index: 10;
		display: inline-block;
		border: 0;
	}
	.tabs-custom.tabs-horizontal.tabs-line .nav-tabs .nav-item + .nav-item, .tabs-custom.tabs-horizontal.tabs-minimal .nav-tabs .nav-item + .nav-item {
		margin-top: 0;
	}
	.tabs-custom.tabs-horizontal.tabs-line .tab-content, .tabs-custom.tabs-horizontal.tabs-minimal .tab-content {
		padding: 40px 0 0;
	}
	.tabs-custom.tabs-horizontal.tabs-corporate .nav-tabs .nav-item, .tabs-custom.tabs-horizontal.tabs-corporate .nav-tabs .nav-link {
		display: block;
		border: 0;
	}
	.tabs-custom.tabs-horizontal.tabs-line .nav-tabs {
		-webkit-justify-content: space-between;
		-ms-flex-pack: justify;
		justify-content: space-between;
		border-bottom: 2px solid #e5e7e9;
	}
	.tabs-custom.tabs-horizontal.tabs-line .nav-tabs .nav-item .nav-link {
		padding: 8px 0 8px 0;
		margin: 0 30px 0 0;
		font-weight: 700;
		background: transparent;
	}
	.tabs-custom.tabs-horizontal.tabs-line .nav-tabs .nav-item .nav-link:after {
		content: '';
		position: absolute;
		left: 0;
		right: 100%;
		bottom: -1px;
		border-bottom: 2px solid <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
		opacity: 0;
		visibility: hidden;
		transition: .33s all ease;
	}
	.tabs-custom.tabs-horizontal.tabs-line .nav-tabs .nav-item .nav-link:hover,
	.tabs-custom.tabs-horizontal.tabs-line .nav-tabs .nav-item .active.nav-link {
		color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
		background: transparent;
	}
	.tabs-custom.tabs-horizontal.tabs-line .nav-tabs .nav-item .active.nav-link:after {
		right: 0;
		opacity: 1;
		visibility: visible;
	}
	.tabs-custom.tabs-horizontal.tabs-minimal .nav-tabs {
		margin-top: -10px;
	}
	.tabs-custom.tabs-horizontal.tabs-minimal .nav-tabs .nav-item {
		display: inline-block;
		margin: 10px 15px 0 0;
	}
	.tabs-custom.tabs-horizontal.tabs-minimal .nav-tabs .nav-item .nav-link {
		position: relative;
		bottom: -1px;
		z-index: 10;
		display: inline-block;
		padding: 0 0 5px 0;
	}
	.tabs-custom.tabs-horizontal.tabs-minimal .nav-tabs .nav-item .nav-link:after {
		content: '';
		position: absolute;
		left: 0;
		right: 100%;
		bottom: 0;
		border-bottom: 2px solid <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
		opacity: 0;
		visibility: hidden;
		transition: .33s all ease;
	}
	.tabs-custom.tabs-horizontal.tabs-minimal .nav-tabs .nav-item .nav-link:last-child {
		margin-right: 0;
	}
	.tabs-custom.tabs-horizontal.tabs-minimal .nav-tabs .nav-item .nav-link:hover,
	.tabs-custom.tabs-horizontal.tabs-minimal .nav-tabs .nav-item .active.nav-link {
		color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
		background: transparent;
	}
	.tabs-custom.tabs-horizontal.tabs-minimal .nav-tabs .nav-item .active.nav-link:after {
		right: 0;
		opacity: 1;
		visibility: visible;
	}
}

.tabs-vertical .nav-tabs {
	position: relative;
}

.tabs-vertical .nav-tabs > .nav-item {
	z-index: 10;
	display: block;
	-webkit-flex-grow: 1;
	-ms-flex-positive: 1;
	flex-grow: 1;
}

.tabs-vertical.tabs-corporate .nav-tabs {
	width: 100%;
}

.tabs-vertical.tabs-corporate .nav-tabs .nav-item {
	display: block;
}

.tabs-vertical.tabs-corporate .nav-tabs .nav-item .nav-link {
	position: relative;
	padding: 8px 10px;
}

.tabs-vertical.tabs-corporate .nav-tabs .nav-item .nav-link:hover,
.tabs-vertical.tabs-corporate .nav-tabs .nav-item .active.nav-link {
	border-color: #3a3c3e;
}

.tabs-vertical.tabs-corporate .tab-content {
	padding: 30px 0 0;
}

.tabs-vertical.tabs-minimal .nav-tabs {
	border-right: 1px solid #ddd;
}

.tabs-vertical.tabs-minimal .nav-tabs .nav-item .nav-link {
	position: relative;
	right: -1px;
	padding: 0 16px 0 0;
	text-align: right;
	border-right: 1px solid transparent;
	background-color: transparent;
}

.tabs-vertical.tabs-minimal .nav-tabs .nav-item .nav-link:hover, .tabs-vertical.tabs-minimal .nav-tabs .nav-item .nav-link.resp-tab-active {
	border-right-color: #00030a;
}

.tabs-vertical.tabs-minimal .nav-tabs .nav-item + .nav-item {
	margin-top: 16px;
}

@media (min-width: 768px) {
	.tabs-custom.tabs-corporate .nav-tabs .nav-item .nav-link {
		font-size: 16px;
		line-height: 26px;
	}
	.tabs-custom.tabs-corporate .nav-tabs .nav-item .nav-link:after {
		font-size: 25px;
	}
	.tabs-custom.tabs-horizontal.tabs-corporate .nav-tabs {
		position: relative;
		-webkit-justify-content: center;
		-ms-flex-pack: center;
		justify-content: center;
	}
	.tabs-custom.tabs-horizontal.tabs-corporate .nav-tabs .nav-item {
		-webkit-flex-grow: 1;
		-ms-flex-positive: 1;
		flex-grow: 1;
		-webkit-flex-shrink: 0;
		-ms-flex-negative: 0;
		flex-shrink: 0;
	}
	.tabs-custom.tabs-horizontal.tabs-corporate .nav-tabs .nav-item .nav-link {
		display: block;
		padding: 21px 10px 19px;
	}
	.tabs-custom.tabs-horizontal.tabs-corporate .tab-content {
		padding: 30px 0 0;
	}
	.tabs-custom.tabs-vertical {
		display: -ms-flexbox;
		display: -webkit-flex;
		display: flex;
		-webkit-flex-direction: row;
		-ms-flex-direction: row;
		flex-direction: row;
		-webkit-flex-wrap: nowrap;
		-ms-flex-wrap: nowrap;
		flex-wrap: nowrap;
		-webkit-align-items: flex-start;
		-ms-flex-align: start;
		align-items: flex-start;
	}
	.tabs-custom.tabs-vertical .nav-tabs {
		display: -ms-flexbox;
		display: -webkit-flex;
		display: flex;
		-webkit-flex-direction: column;
		-ms-flex-direction: column;
		flex-direction: column;
		-webkit-flex-wrap: nowrap;
		-ms-flex-wrap: nowrap;
		flex-wrap: nowrap;
		-webkit-align-items: stretch;
		-ms-flex-align: stretch;
		align-items: stretch;
		-webkit-flex-shrink: 0;
		-ms-flex-negative: 0;
		flex-shrink: 0;
		max-width: 50%;
	}
	.tabs-custom.tabs-vertical .nav-tabs .nav-item {
		width: 100%;
	}
	.tabs-custom.tabs-vertical .nav-tabs .nav-item .nav-link {
		text-align: left;
	}
	.tabs-custom.tabs-vertical .nav-tabs .nav-item .nav-link:hover,
	.tabs-custom.tabs-vertical .nav-tabs .nav-item .active.nav-link {
		border-color: #3a3c3e;
	}
	.tabs-custom.tabs-vertical .nav-tabs .nav-item .nav-link:hover:after,
	.tabs-custom.tabs-vertical .nav-tabs .nav-item .active.nav-link:after {
		right: 15px;
	}
	.tabs-custom.tabs-vertical .tab-content {
		-webkit-flex-grow: 1;
		-ms-flex-positive: 1;
		flex-grow: 1;
	}
	.tabs-custom.tabs-vertical.tabs-corporate .nav-tabs {
		width: auto;
		min-width: 240px;
		border-width: 0 0 1px 0;
	}
	.tabs-custom.tabs-vertical.tabs-corporate .nav-tabs .nav-item {
		margin: 0;
	}
	.tabs-custom.tabs-vertical.tabs-corporate .nav-tabs .nav-item .nav-link {
		padding: 23px 44px 22px 30px;
		border-width: 1px 0 0 0;
		text-align: left;
	}
	.tabs-custom.tabs-vertical.tabs-corporate .nav-tabs .nav-item .nav-link:after {
		position: absolute;
		top: 50%;
		transform: translateY(-50%);
		right: 26px;
		content: '\f238';
		transition: .33s all ease;
	}
	.tabs-custom.tabs-vertical.tabs-corporate .nav-tabs .nav-item .nav-link:hover:after,
	.tabs-custom.tabs-vertical.tabs-corporate .nav-tabs .nav-item .active.nav-link:after {
		right: 15px;
		top: 50%;
	}
	.tabs-custom.tabs-vertical.tabs-corporate .tab-content {
		padding: 0 0 0 30px;
		margin-top: -5px;
	}
}

@media (min-width: 992px) {
	.tabs-custom.tabs-vertical.tabs-corporate .nav-tabs {
		min-width: 300px;
	}
	.tabs-custom.tabs-vertical.tabs-corporate .tab-content {
		padding: 0 0 0 44px;
	}
}

.card-group.card-group-custom {
	margin-bottom: 0;
}

.card-group.card-group-custom .card-heading + .card-collapse > .card-body,
.card-group.card-group-custom .card-heading + .card-collapse > .list-group {
	border-top: 0;
}

.card-group.card-group-custom .card + .card {
	margin-top: 0;
}

.card-group.card-group-corporate .card + .card {
	margin-top: 30px;
}

.card-custom {
	margin: 0;
	background: inherit;
	border: 0;
	border-radius: 0;
	box-shadow: none;
}

.card-custom a {
	display: block;
}

.card-custom .card-heading {
	padding: 0;
	border-bottom: 0;
	border-top-left-radius: 0;
	border-top-right-radius: 0;
}

.card-custom .card-body {
	padding: 0;
	border: 0;
}

* + .card-group-custom {
	margin-top: 35px;
}

@media (min-width: 768px) {
	* + .card-group-custom {
		margin-top: 50px;
	}
}

.card-light:first-child .card-title {
	border-top: 1px solid #dedede;
}

.card-light .card-title {
	border-bottom: 1px solid #dedede;
}

.card-light .card-title:nth-child(n + 2) {
	margin-top: -1px;
}

.card-light .card-title a {
	position: relative;
	padding: 24px 55px 22px 32px;
	font: 500 18px/24px "Roboto", Helvetica, Arial, sans-serif;
	color: #000;
	transition: 1.5s all ease;
}

.card-light .card-title a .card-arrow:after {
	opacity: 0;
	visibility: hidden;
}

.card-light .card-title a.collapsed .card-arrow:after {
	opacity: 1;
	visibility: visible;
}

.card-light .card-arrow {
	position: absolute;
	top: 50%;
	transform: translateY(-50%);
	right: 26px;
	transition: .33s;
	will-change: transform;
}

.card-light .card-arrow:before, .card-light .card-arrow:after {
	content: '';
	position: absolute;
	top: 50%;
	transform: translateY(-50%);
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.card-light .card-arrow:before {
	width: 14px;
	height: 2px;
	right: 0;
}

.card-light .card-arrow:after {
	width: 2px;
	height: 14px;
	right: 6px;
	transition: .2s all ease;
}

.card-light .card-collapse {
	position: relative;
	margin-top: -1px;
	border-bottom: 1px solid #dedede;
	color: #9f9f9f;
	will-change: transform;
}

.card-light .card-body {
	padding: 25px 44px 25px 32px;
}

@media (max-width: 767px) {
	.card-light .card-title a,
	.card-light .card-body {
		padding-left: 15px;
	}
}

.card-corporate .card-title a,
.card-corporate .card-collapse {
	background: #fff;
	box-shadow: -1px 0px 10px 0px rgba(65, 65, 65, 0.12);
}

.card-corporate .card-collapse.in {
	box-shadow: -1px 0 5px 0 rgba(65, 65, 65, 0.12);
}

.card-corporate .card-collapse.in:before {
	content: '';
	position: absolute;
	top: -1px;
	height: 1px;
	background: #ededed;
	left: 0;
	width: 100%;
}

.card-corporate .card-title a {
	position: relative;
	z-index: 1;
	padding: 24px 82px 22px 32px;
	font: 500 18px/24px "Roboto", Helvetica, Arial, sans-serif;
	color: #000;
	transition: 1.3s all ease;
	letter-spacing: -.025em;
	border-radius: 6px 6px 0 0;
}

.card-corporate .card-title a .card-arrow:after {
	opacity: 0;
	visibility: hidden;
}

.card-corporate .card-title a.collapsed {
	border-radius: 6px;
}

.card-corporate .card-title a.collapsed .card-arrow {
	border-radius: 0 6px 6px 0;
}

.card-corporate .card-title a.collapsed .card-arrow:after {
	opacity: 1;
	visibility: visible;
}

.card-corporate .card-arrow {
	position: absolute;
	top: 0;
	bottom: 0;
	right: 0;
	z-index: 2;
	width: 70px;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	border-radius: 0 6px 0 0;
	transition: 1.3s all ease;
}

.card-corporate .card-arrow:before, .card-corporate .card-arrow:after {
	content: '';
	position: absolute;
	top: 50%;
	z-index: 4;
	transform: translateY(-50%);
	background: #fff;
}

.card-corporate .card-arrow:before {
	width: 14px;
	height: 2px;
	right: 28px;
}

.card-corporate .card-arrow:after {
	width: 2px;
	height: 14px;
	right: 34px;
}

.card-corporate .card-collapse {
	position: relative;
	z-index: 2;
	color: #9f9f9f;
	border-radius: 0 0 6px 6px;
}

.card-corporate .card-body {
	padding: 25px 44px 25px 32px;
}

@media (max-width: 767px) {
	.card-corporate .card-title a,
	.card-corporate .card-body {
		padding-left: 25px;
	}
}

.card-lg {
	position: relative;
	padding: 50px 15px;
}

.card-lg:before {
	content: '';
	position: absolute;
	top: -45px;
	left: 50%;
	width: 55px;
	height: 55px;
	margin-left: -10px;
	background: #fff;
	transform: translateX(-50%) rotate(-45deg);
}

@media (min-width: 768px) {
	.card-lg {
		padding: 90px 35px 100px;
	}
}

table {
	background-color: transparent;
}

caption {
	padding-top: 17px 25px 18px;
	padding-bottom: 17px 25px 18px;
	color: #dedede;
	text-align: left;
}

th {
	text-align: left;
}

.table {
	width: 100%;
	max-width: 100%;
	margin-bottom: 0;
	color: #00030a;
}

.table > thead > tr > th,
.table > thead > tr > td,
.table > tbody > tr > th,
.table > tbody > tr > td,
.table > tfoot > tr > th,
.table > tfoot > tr > td {
	line-height: 1.71429;
	vertical-align: top;
	border-top: 0;
}

.table > tbody > tr > th,
.table > tbody > tr > td,
.table > tfoot > tr > th,
.table > tfoot > tr > td {
	padding: 17px 25px 18px;
	line-height: 1.71429;
	vertical-align: top;
	border-bottom: 1px solid #d9d9d9;
}

.table > thead > tr > th {
	font-family: "Playfair Display", Helvetica, Arial, sans-serif;
	font-size: 16px;
	font-weight: 700;
	padding: 26px 25px;
	vertical-align: bottom;
	background: #f6f7fa;
	border-bottom: 0;
}

@media (min-width: 576px) {
	.table > thead > tr > th {
		padding: 34px 25px 29px;
	}
}

.table > tfoot > tr > td {
	font-weight: 700;
}

.table > caption + thead > tr:first-child > th,
.table > caption + thead > tr:first-child > td,
.table > colgroup + thead > tr:first-child > th,
.table > colgroup + thead > tr:first-child > td,
.table > thead:first-child > tr:first-child > th,
.table > thead:first-child > tr:first-child > td {
	border-top: 0;
}

.table > tbody + tbody {
	border-top: 0;
}

.table .table {
	background-color: #fff;
}

.table-condensed > thead > tr > th,
.table-condensed > thead > tr > td,
.table-condensed > tbody > tr > th,
.table-condensed > tbody > tr > td,
.table-condensed > tfoot > tr > th,
.table-condensed > tfoot > tr > td {
	padding: 5px;
}

.table-bordered {
	border: 1px solid #d9d9d9;
}

.table-bordered > thead > tr > th,
.table-bordered > thead > tr > td,
.table-bordered > tbody > tr > th,
.table-bordered > tbody > tr > td,
.table-bordered > tfoot > tr > th,
.table-bordered > tfoot > tr > td {
	border: 1px solid #d9d9d9;
}

.table-bordered > thead > tr > th,
.table-bordered > thead > tr > td {
	border-bottom-width: 2px;
}

.table-primary {
	background: #fff;
}

.table-primary thead > tr > th {
	color: #fff;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.table-striped > tbody > tr:nth-of-type(even) {
	background-color: #f6f7fa;
}

.table-striped > tbody > tr:nth-of-type(odd) {
	background-color: #fff;
}

.table-striped > tbody > tr > td {
	border-bottom: 0;
}

.table-hover > tbody > tr:hover {
	background-color: #f6f7fa;
}

table col[class*="col-"] {
	position: static;
	float: none;
	display: table-column;
}

table td[class*="col-"],
table th[class*="col-"] {
	position: static;
	float: none;
	display: table-cell;
}

.table-active,
.table-active > th,
.table-active > td {
	background-color: #f6f7fa;
}

.table-hover .table-active:hover {
	background-color: #e6e8f1;
}

.table-hover .table-active:hover > td,
.table-hover .table-active:hover > th {
	background-color: #e6e8f1;
}

.table-success,
.table-success > th,
.table-success > td {
	background-color: #dff0d8;
}

.table-hover .table-success:hover {
	background-color: #d0e9c6;
}

.table-hover .table-success:hover > td,
.table-hover .table-success:hover > th {
	background-color: #d0e9c6;
}

.table-info,
.table-info > th,
.table-info > td {
	background-color: #d9edf7;
}

.table-hover .table-info:hover {
	background-color: #c4e3f3;
}

.table-hover .table-info:hover > td,
.table-hover .table-info:hover > th {
	background-color: #c4e3f3;
}

.table-warning,
.table-warning > th,
.table-warning > td {
	background-color: #fcf8e3;
}

.table-hover .table-warning:hover {
	background-color: #faf2cc;
}

.table-hover .table-warning:hover > td,
.table-hover .table-warning:hover > th {
	background-color: #faf2cc;
}

.table-danger,
.table-danger > th,
.table-danger > td {
	background-color: #fe4a21;
}

.table-hover .table-danger:hover {
	background-color: #fe3508;
}

.table-hover .table-danger:hover > td,
.table-hover .table-danger:hover > th {
	background-color: #fe3508;
}

.table-responsive {
	overflow-x: auto;
	min-height: 0.01%;
}

@media (max-width: 575px) {
	.table-responsive {
		width: 100%;
		margin-bottom: 1.28571;
		overflow-y: hidden;
		-ms-overflow-style: -ms-autohiding-scrollbar;
		border: 1px solid #d9d9d9;
	}
	.table-responsive > .table {
		margin-bottom: 0;
	}
	.table-responsive > .table > thead > tr > th,
	.table-responsive > .table > thead > tr > td,
	.table-responsive > .table > tbody > tr > th,
	.table-responsive > .table > tbody > tr > td,
	.table-responsive > .table > tfoot > tr > th,
	.table-responsive > .table > tfoot > tr > td {
		white-space: nowrap;
	}
	.table-responsive > .table-bordered {
		border: 0;
	}
	.table-responsive > .table-bordered > thead > tr > th:first-child,
	.table-responsive > .table-bordered > thead > tr > td:first-child,
	.table-responsive > .table-bordered > tbody > tr > th:first-child,
	.table-responsive > .table-bordered > tbody > tr > td:first-child,
	.table-responsive > .table-bordered > tfoot > tr > th:first-child,
	.table-responsive > .table-bordered > tfoot > tr > td:first-child {
		border-left: 0;
	}
	.table-responsive > .table-bordered > thead > tr > th:last-child,
	.table-responsive > .table-bordered > thead > tr > td:last-child,
	.table-responsive > .table-bordered > tbody > tr > th:last-child,
	.table-responsive > .table-bordered > tbody > tr > td:last-child,
	.table-responsive > .table-bordered > tfoot > tr > th:last-child,
	.table-responsive > .table-bordered > tfoot > tr > td:last-child {
		border-right: 0;
	}
	.table-responsive > .table-bordered > tbody > tr:last-child > th,
	.table-responsive > .table-bordered > tbody > tr:last-child > td,
	.table-responsive > .table-bordered > tfoot > tr:last-child > th,
	.table-responsive > .table-bordered > tfoot > tr:last-child > td {
		border-bottom: 0;
	}
}

.jumbotron-custom {
	font-weight: 900;
	font-size: 35px;
	line-height: 1.2;
	letter-spacing: .01em;
}

.jumbotron-custom > span {
	font-size: 31px;
	line-height: 1.2;
}

@media (min-width: 768px) {
	.jumbotron-custom {
		font-size: 45px;
	}
	.jumbotron-custom > span {
		font-size: 41px;
	}
}

@media (min-width: 992px) {
	.jumbotron-custom {
		font-size: 55px;
	}
	.jumbotron-custom > span {
		font-size: 51px;
	}
}

@media (min-width: 1200px) {
	.jumbotron-custom {
		font-size: 65px;
	}
	.jumbotron-custom > span {
		font-size: 61px;
	}
}


[class^="thin-icon-"]:before,
[class*=" thin-icon-"]:before,
.thin-ico {
	font-family: "Thin Regular";
	font-weight: 400;
	font-style: normal;
	font-size: inherit;
	text-transform: none;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
}

.thin-icon-volume-on:before {
	content: '\e800';
}

.thin-icon-gift:before {
	content: '\e801';
}

.thin-icon-cup:before {
	content: '\e802';
}

.thin-icon-folder:before {
	content: '\e803';
}

.thin-icon-dublicate:before {
	content: '\e804';
}

.thin-icon-tag:before {
	content: '\e805';
}

.thin-icon-chat:before {
	content: '\e806';
}

.thin-icon-clock:before {
	content: '\e807';
}

.thin-icon-microphone:before {
	content: '\e808';
}

.thin-icon-map-marker:before {
	content: '\e809';
}

.thin-icon-mobile:before {
	content: '\e80a';
}

.thin-icon-cloud-charge:before {
	content: '\e80b';
}

.thin-icon-resize:before {
	content: '\e80c';
}

.thin-icon-cake:before {
	content: '\e80d';
}

.thin-icon-case:before {
	content: '\e80e';
}

.thin-icon-address:before {
	content: '\e80f';
}

.thin-icon-phone-support:before {
	content: '\e810';
}

.thin-icon-fullscreen:before {
	content: '\e811';
}

.thin-icon-db:before {
	content: '\e812';
}

.thin-icon-music:before {
	content: '\e813';
}

.thin-icon-network:before {
	content: '\e814';
}

.thin-icon-db-network:before {
	content: '\e815';
}

.thin-icon-dropbox-upload:before {
	content: '\e816';
}

.thin-icon-phone-call:before {
	content: '\e817';
}

.thin-icon-briefcase-2:before {
	content: '\e818';
}

.thin-icon-card:before {
	content: '\e819';
}

.thin-icon-support:before {
	content: '\e81a';
}

.thin-icon-pull:before {
	content: '\e81b';
}

.thin-icon-desktop:before {
	content: '\e81c';
}

.thin-icon-pass:before {
	content: '\e81d';
}

.thin-icon-picture:before {
	content: '\e81e';
}

.thin-icon-email:before {
	content: '\e81f';
}

.thin-icon-push:before {
	content: '\e820';
}

.thin-icon-house:before {
	content: '\e821';
}

.thin-icon-download:before {
	content: '\e822';
}

.thin-icon-storage:before {
	content: '\e823';
}

.thin-icon-milk:before {
	content: '\e824';
}

.thin-icon-external-right:before {
	content: '\e825';
}

.thin-icon-email-open:before {
	content: '\e826';
}

.thin-icon-planet:before {
	content: '\e827';
}

.thin-icon-pointer:before {
	content: '\e828';
}

.thin-icon-email-search:before {
	content: '\e829';
}

.thin-icon-external-left:before {
	content: '\e82a';
}

.thin-icon-shirt:before {
	content: '\e82b';
}

.thin-icon-document-edit:before {
	content: '\e82c';
}

.thin-icon-document-delete:before {
	content: '\e82d';
}

.thin-icon-money:before {
	content: '\e82e';
}

.thin-icon-eye:before {
	content: '\e82f';
}

.thin-icon-settings:before {
	content: '\e830';
}

.thin-icon-arrow-bottom-right:before {
	content: '\e831';
}

.thin-icon-arrow-right:before {
	content: '\e832';
}

.thin-icon-flag:before {
	content: '\e833';
}

.thin-icon-star:before {
	content: '\e834';
}

.thin-icon-calculator:before {
	content: '\e835';
}

.thin-icon-safe:before {
	content: '\e836';
}

.thin-icon-cart:before {
	content: '\e837';
}

.thin-icon-bullhorn:before {
	content: '\e838';
}

.thin-icon-anchor:before {
	content: '\e839';
}

.thin-icon-globe:before {
	content: '\e83a';
}

.thin-icon-statistics:before {
	content: '\e83b';
}

.thin-icon-thumb-up:before {
	content: '\e83c';
}

.thin-icon-headphones:before {
	content: '\e83d';
}

.thin-icon-bell:before {
	content: '\e83e';
}

.thin-icon-study:before {
	content: '\e83f';
}

.thin-icon-cart-add:before {
	content: '\e840';
}

.thin-icon-cart-delete:before {
	content: '\e841';
}

.thin-icon-satelite:before {
	content: '\e842';
}

.thin-icon-home:before {
	content: '\e843';
}

.thin-icon-time:before {
	content: '\e844';
}

.thin-icon-book:before {
	content: '\e845';
}

.thin-icon-bookmark:before {
	content: '\e846';
}

.thin-icon-key:before {
	content: '\e847';
}

.thin-icon-timer:before {
	content: '\e848';
}

.thin-icon-saturn:before {
	content: '\e849';
}

.thin-icon-notes:before {
	content: '\e84a';
}

.thin-icon-ambulance:before {
	content: '\e84b';
}

.thin-icon-briefcase:before {
	content: '\e84c';
}

.thin-icon-layers:before {
	content: '\e84d';
}

.thin-icon-delivery:before {
	content: '\e84e';
}

.thin-icon-tint:before {
	content: '\e84f';
}

.thin-icon-trash:before {
	content: '\e850';
}

.thin-icon-lightbulb:before {
	content: '\e851';
}

.thin-icon-calendar:before {
	content: '\e852';
}

.thin-icon-chart:before {
	content: '\e853';
}

.thin-icon-documents:before {
	content: '\e854';
}

.thin-icon-checklist:before {
	content: '\e855';
}

.thin-icon-camera-web:before {
	content: '\e856';
}

.thin-icon-camera:before {
	content: '\e857';
}

.thin-icon-lock:before {
	content: '\e858';
}

.thin-icon-umbrella:before {
	content: '\e859';
}

.thin-icon-user:before {
	content: '\e85a';
}

.thin-icon-love:before {
	content: '\e85b';
}

.thin-icon-hanger:before {
	content: '\e85c';
}

.thin-icon-car:before {
	content: '\e85d';
}

.thin-icon-cloth:before {
	content: '\e85e';
}

.thin-icon-box:before {
	content: '\e85f';
}

.thin-icon-attachment:before {
	content: '\e860';
}

.thin-icon-cd:before {
	content: '\e861';
}

.thin-icon-love-broken:before {
	content: '\e862';
}

.thin-icon-volume-off:before {
	content: '\e863';
}

/*
 * Custom Plugins
 */
/**
* @subsection   Animate.css
*
* @description  A bunch of cool, fun, and cross-browser animations
*               for you to use.
*
* @author       Daniel Eden
* @link         http://daneden.me/animate
* @license      MIT license - http://opensource.org/licenses/MIT
*/
.animated {
	-webkit-animation-duration: 1s;
	animation-duration: 1s;
	-webkit-animation-fill-mode: both;
	animation-fill-mode: both;
	opacity: 1;
}

.animated:not(.page) {
	will-change: transform;
}

.animated.infinite {
	-webkit-animation-iteration-count: infinite;
	animation-iteration-count: infinite;
}

.animated.hinge {
	-webkit-animation-duration: 2s;
	animation-duration: 2s;
}

html:not(.lt-ie10) .not-animated {
	opacity: 0;
}

/**
* Bounce Keyframes Animation
*/
@-webkit-keyframes bounce {
	0%, 20%, 53%, 80%, 100% {
		-webkit-transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
		transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
	40%, 43% {
		-webkit-transition-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
		transition-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
		-webkit-transform: translate3d(0, -30px, 0);
		transform: translate3d(0, -30px, 0);
	}
	70% {
		-webkit-transition-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
		transition-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
		-webkit-transform: translate3d(0, -15px, 0);
		transform: translate3d(0, -15px, 0);
	}
	90% {
		-webkit-transform: translate3d(0, -4px, 0);
		transform: translate3d(0, -4px, 0);
	}
}

.bounce {
	-webkit-animation-name: bounce;
	animation-name: bounce;
	-webkit-transform-origin: center bottom;
	transform-origin: center bottom;
}

/**
* Flas Keyframes Animation
*/
@-webkit-keyframes flash {
	0%, 50%, 100% {
		opacity: 1;
	}
	25%, 75% {
		opacity: 0;
	}
}

@keyframes flash {
	0%, 50%, 100% {
		opacity: 1;
	}
	25%, 75% {
		opacity: 0;
	}
}

.flash {
	-webkit-animation-name: flash;
	animation-name: flash;
}

/**
* Pulse Keyframes Animation
*
* @author Nick Pettit
* @link https://github.com/nickpettit/glide
*/
@-webkit-keyframes pulse {
	0% {
		-webkit-transform: scale3d(1, 1, 1);
		transform: scale3d(1, 1, 1);
	}
	50% {
		-webkit-transform: scale3d(1.05, 1.05, 1.05);
		transform: scale3d(1.05, 1.05, 1.05);
	}
	100% {
		-webkit-transform: scale3d(1, 1, 1);
		transform: scale3d(1, 1, 1);
	}
}

@keyframes pulse {
	0% {
		-webkit-transform: scale3d(1, 1, 1);
		transform: scale3d(1, 1, 1);
	}
	50% {
		-webkit-transform: scale3d(1.05, 1.05, 1.05);
		transform: scale3d(1.05, 1.05, 1.05);
	}
	100% {
		-webkit-transform: scale3d(1, 1, 1);
		transform: scale3d(1, 1, 1);
	}
}

.pulse {
	-webkit-animation-name: pulse;
	animation-name: pulse;
}

/**
* RubberBand Keyframes Animation
*/
@-webkit-keyframes rubberBand {
	0% {
		-webkit-transform: scale3d(1, 1, 1);
		transform: scale3d(1, 1, 1);
	}
	30% {
		-webkit-transform: scale3d(1.25, 0.75, 1);
		transform: scale3d(1.25, 0.75, 1);
	}
	40% {
		-webkit-transform: scale3d(0.75, 1.25, 1);
		transform: scale3d(0.75, 1.25, 1);
	}
	50% {
		-webkit-transform: scale3d(1.15, 0.85, 1);
		transform: scale3d(1.15, 0.85, 1);
	}
	65% {
		-webkit-transform: scale3d(0.95, 1.05, 1);
		transform: scale3d(0.95, 1.05, 1);
	}
	75% {
		-webkit-transform: scale3d(1.05, 0.95, 1);
		transform: scale3d(1.05, 0.95, 1);
	}
	100% {
		-webkit-transform: scale3d(1, 1, 1);
		transform: scale3d(1, 1, 1);
	}
}

@keyframes rubberBand {
	0% {
		-webkit-transform: scale3d(1, 1, 1);
		transform: scale3d(1, 1, 1);
	}
	30% {
		-webkit-transform: scale3d(1.25, 0.75, 1);
		transform: scale3d(1.25, 0.75, 1);
	}
	40% {
		-webkit-transform: scale3d(0.75, 1.25, 1);
		transform: scale3d(0.75, 1.25, 1);
	}
	50% {
		-webkit-transform: scale3d(1.15, 0.85, 1);
		transform: scale3d(1.15, 0.85, 1);
	}
	65% {
		-webkit-transform: scale3d(0.95, 1.05, 1);
		transform: scale3d(0.95, 1.05, 1);
	}
	75% {
		-webkit-transform: scale3d(1.05, 0.95, 1);
		transform: scale3d(1.05, 0.95, 1);
	}
	100% {
		-webkit-transform: scale3d(1, 1, 1);
		transform: scale3d(1, 1, 1);
	}
}

.rubberBand {
	-webkit-animation-name: rubberBand;
	animation-name: rubberBand;
}

/**
* Shake Keyframes Animation
*/
@-webkit-keyframes shake {
	0%, 100% {
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
	10%, 30%, 50%, 70%, 90% {
		-webkit-transform: translate3d(-10px, 0, 0);
		transform: translate3d(-10px, 0, 0);
	}
	20%, 40%, 60%, 80% {
		-webkit-transform: translate3d(10px, 0, 0);
		transform: translate3d(10px, 0, 0);
	}
}

@keyframes shake {
	0%, 100% {
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
	10%, 30%, 50%, 70%, 90% {
		-webkit-transform: translate3d(-10px, 0, 0);
		transform: translate3d(-10px, 0, 0);
	}
	20%, 40%, 60%, 80% {
		-webkit-transform: translate3d(10px, 0, 0);
		transform: translate3d(10px, 0, 0);
	}
}

.shake {
	-webkit-animation-name: shake;
	animation-name: shake;
}

/**
* Swing Keyframes Animation
*/
@-webkit-keyframes swing {
	20% {
		-webkit-transform: rotate3d(0, 0, 1, 15deg);
		transform: rotate3d(0, 0, 1, 15deg);
	}
	40% {
		-webkit-transform: rotate3d(0, 0, 1, -10deg);
		transform: rotate3d(0, 0, 1, -10deg);
	}
	60% {
		-webkit-transform: rotate3d(0, 0, 1, 5deg);
		transform: rotate3d(0, 0, 1, 5deg);
	}
	80% {
		-webkit-transform: rotate3d(0, 0, 1, -5deg);
		transform: rotate3d(0, 0, 1, -5deg);
	}
	100% {
		-webkit-transform: rotate3d(0, 0, 1, 0deg);
		transform: rotate3d(0, 0, 1, 0deg);
	}
}

@keyframes swing {
	20% {
		-webkit-transform: rotate3d(0, 0, 1, 15deg);
		transform: rotate3d(0, 0, 1, 15deg);
	}
	40% {
		-webkit-transform: rotate3d(0, 0, 1, -10deg);
		transform: rotate3d(0, 0, 1, -10deg);
	}
	60% {
		-webkit-transform: rotate3d(0, 0, 1, 5deg);
		transform: rotate3d(0, 0, 1, 5deg);
	}
	80% {
		-webkit-transform: rotate3d(0, 0, 1, -5deg);
		transform: rotate3d(0, 0, 1, -5deg);
	}
	100% {
		-webkit-transform: rotate3d(0, 0, 1, 0deg);
		transform: rotate3d(0, 0, 1, 0deg);
	}
}

.swing {
	-webkit-transform-origin: top center;
	transform-origin: top center;
	-webkit-animation-name: swing;
	animation-name: swing;
}

/**
* Tada Keyframes Animation
*/
@-webkit-keyframes tada {
	0% {
		-webkit-transform: scale3d(1, 1, 1);
		transform: scale3d(1, 1, 1);
	}
	10%, 20% {
		-webkit-transform: scale3d(0.9, 0.9, 0.9) rotate3d(0, 0, 1, -3deg);
		transform: scale3d(0.9, 0.9, 0.9) rotate3d(0, 0, 1, -3deg);
	}
	30%, 50%, 70%, 90% {
		-webkit-transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg);
		transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg);
	}
	40%, 60%, 80% {
		-webkit-transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg);
		transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg);
	}
	100% {
		-webkit-transform: scale3d(1, 1, 1);
		transform: scale3d(1, 1, 1);
	}
}

@keyframes tada {
	0% {
		-webkit-transform: scale3d(1, 1, 1);
		transform: scale3d(1, 1, 1);
	}
	10%, 20% {
		-webkit-transform: scale3d(0.9, 0.9, 0.9) rotate3d(0, 0, 1, -3deg);
		transform: scale3d(0.9, 0.9, 0.9) rotate3d(0, 0, 1, -3deg);
	}
	30%, 50%, 70%, 90% {
		-webkit-transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg);
		transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg);
	}
	40%, 60%, 80% {
		-webkit-transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg);
		transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg);
	}
	100% {
		-webkit-transform: scale3d(1, 1, 1);
		transform: scale3d(1, 1, 1);
	}
}

.tada {
	-webkit-animation-name: tada;
	animation-name: tada;
}

/**
* Wobble Keyframes Animation
*
* @author Nick Pettit
* @link https://github.com/nickpettit/glide
*/
@-webkit-keyframes wobble {
	0% {
		-webkit-transform: none;
		transform: none;
	}
	15% {
		-webkit-transform: translate3d(-25%, 0, 0) rotate3d(0, 0, 1, -5deg);
		transform: translate3d(-25%, 0, 0) rotate3d(0, 0, 1, -5deg);
	}
	30% {
		-webkit-transform: translate3d(20%, 0, 0) rotate3d(0, 0, 1, 3deg);
		transform: translate3d(20%, 0, 0) rotate3d(0, 0, 1, 3deg);
	}
	45% {
		-webkit-transform: translate3d(-15%, 0, 0) rotate3d(0, 0, 1, -3deg);
		transform: translate3d(-15%, 0, 0) rotate3d(0, 0, 1, -3deg);
	}
	60% {
		-webkit-transform: translate3d(10%, 0, 0) rotate3d(0, 0, 1, 2deg);
		transform: translate3d(10%, 0, 0) rotate3d(0, 0, 1, 2deg);
	}
	75% {
		-webkit-transform: translate3d(-5%, 0, 0) rotate3d(0, 0, 1, -1deg);
		transform: translate3d(-5%, 0, 0) rotate3d(0, 0, 1, -1deg);
	}
	100% {
		-webkit-transform: none;
		transform: none;
	}
}

@keyframes wobble {
	0% {
		-webkit-transform: none;
		transform: none;
	}
	15% {
		-webkit-transform: translate3d(-25%, 0, 0) rotate3d(0, 0, 1, -5deg);
		transform: translate3d(-25%, 0, 0) rotate3d(0, 0, 1, -5deg);
	}
	30% {
		-webkit-transform: translate3d(20%, 0, 0) rotate3d(0, 0, 1, 3deg);
		transform: translate3d(20%, 0, 0) rotate3d(0, 0, 1, 3deg);
	}
	45% {
		-webkit-transform: translate3d(-15%, 0, 0) rotate3d(0, 0, 1, -3deg);
		transform: translate3d(-15%, 0, 0) rotate3d(0, 0, 1, -3deg);
	}
	60% {
		-webkit-transform: translate3d(10%, 0, 0) rotate3d(0, 0, 1, 2deg);
		transform: translate3d(10%, 0, 0) rotate3d(0, 0, 1, 2deg);
	}
	75% {
		-webkit-transform: translate3d(-5%, 0, 0) rotate3d(0, 0, 1, -1deg);
		transform: translate3d(-5%, 0, 0) rotate3d(0, 0, 1, -1deg);
	}
	100% {
		-webkit-transform: none;
		transform: none;
	}
}

.wobble {
	-webkit-animation-name: wobble;
	animation-name: wobble;
}

/**
* BounceIn Keyframes Animation
*/
@-webkit-keyframes bounceIn {
	0%, 20%, 40%, 60%, 80%, 100% {
		-webkit-transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
		transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
	}
	0% {
		opacity: 0;
		-webkit-transform: scale3d(0.3, 0.3, 0.3);
		transform: scale3d(0.3, 0.3, 0.3);
	}
	20% {
		-webkit-transform: scale3d(1.1, 1.1, 1.1);
		transform: scale3d(1.1, 1.1, 1.1);
	}
	40% {
		-webkit-transform: scale3d(0.9, 0.9, 0.9);
		transform: scale3d(0.9, 0.9, 0.9);
	}
	60% {
		opacity: 1;
		-webkit-transform: scale3d(1.03, 1.03, 1.03);
		transform: scale3d(1.03, 1.03, 1.03);
	}
	80% {
		-webkit-transform: scale3d(0.97, 0.97, 0.97);
		transform: scale3d(0.97, 0.97, 0.97);
	}
	100% {
		opacity: 1;
		-webkit-transform: scale3d(1, 1, 1);
		transform: scale3d(1, 1, 1);
	}
}

@keyframes bounceIn {
	0%, 20%, 40%, 60%, 80%, 100% {
		-webkit-transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
		transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
	}
	0% {
		opacity: 0;
		-webkit-transform: scale3d(0.3, 0.3, 0.3);
		transform: scale3d(0.3, 0.3, 0.3);
	}
	20% {
		-webkit-transform: scale3d(1.1, 1.1, 1.1);
		transform: scale3d(1.1, 1.1, 1.1);
	}
	40% {
		-webkit-transform: scale3d(0.9, 0.9, 0.9);
		transform: scale3d(0.9, 0.9, 0.9);
	}
	60% {
		opacity: 1;
		-webkit-transform: scale3d(1.03, 1.03, 1.03);
		transform: scale3d(1.03, 1.03, 1.03);
	}
	80% {
		-webkit-transform: scale3d(0.97, 0.97, 0.97);
		transform: scale3d(0.97, 0.97, 0.97);
	}
	100% {
		opacity: 1;
		-webkit-transform: scale3d(1, 1, 1);
		transform: scale3d(1, 1, 1);
	}
}

.bounceIn {
	-webkit-animation-name: bounceIn;
	animation-name: bounceIn;
	-webkit-animation-duration: .75s;
	animation-duration: .75s;
}

/**
* BounceInDown Keyframes Animation
*/
@-webkit-keyframes bounceInDown {
	0%, 60%, 75%, 90%, 100% {
		-webkit-transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
		transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
	}
	0% {
		opacity: 0;
		-webkit-transform: translate3d(0, -3000px, 0);
		transform: translate3d(0, -3000px, 0);
	}
	60% {
		opacity: 1;
		-webkit-transform: translate3d(0, 25px, 0);
		transform: translate3d(0, 25px, 0);
	}
	75% {
		-webkit-transform: translate3d(0, -10px, 0);
		transform: translate3d(0, -10px, 0);
	}
	90% {
		-webkit-transform: translate3d(0, 5px, 0);
		transform: translate3d(0, 5px, 0);
	}
	100% {
		-webkit-transform: none;
		transform: none;
	}
}

@keyframes bounceInDown {
	0%, 60%, 75%, 90%, 100% {
		-webkit-transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
		transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
	}
	0% {
		opacity: 0;
		-webkit-transform: translate3d(0, -3000px, 0);
		transform: translate3d(0, -3000px, 0);
	}
	60% {
		opacity: 1;
		-webkit-transform: translate3d(0, 25px, 0);
		transform: translate3d(0, 25px, 0);
	}
	75% {
		-webkit-transform: translate3d(0, -10px, 0);
		transform: translate3d(0, -10px, 0);
	}
	90% {
		-webkit-transform: translate3d(0, 5px, 0);
		transform: translate3d(0, 5px, 0);
	}
	100% {
		-webkit-transform: none;
		transform: none;
	}
}

.bounceInDown {
	-webkit-animation-name: bounceInDown;
	animation-name: bounceInDown;
}

/**
* BounceInLeft Keyframes Animation
*/
@-webkit-keyframes bounceInLeft {
	0%, 60%, 75%, 90%, 100% {
		-webkit-transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
		transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
	}
	0% {
		opacity: 0;
		-webkit-transform: translate3d(-3000px, 0, 0);
		transform: translate3d(-3000px, 0, 0);
	}
	60% {
		opacity: 1;
		-webkit-transform: translate3d(25px, 0, 0);
		transform: translate3d(25px, 0, 0);
	}
	75% {
		-webkit-transform: translate3d(-10px, 0, 0);
		transform: translate3d(-10px, 0, 0);
	}
	90% {
		-webkit-transform: translate3d(5px, 0, 0);
		transform: translate3d(5px, 0, 0);
	}
	100% {
		-webkit-transform: none;
		transform: none;
	}
}

@keyframes bounceInLeft {
	0%, 60%, 75%, 90%, 100% {
		-webkit-transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
		transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
	}
	0% {
		opacity: 0;
		-webkit-transform: translate3d(-3000px, 0, 0);
		transform: translate3d(-3000px, 0, 0);
	}
	60% {
		opacity: 1;
		-webkit-transform: translate3d(25px, 0, 0);
		transform: translate3d(25px, 0, 0);
	}
	75% {
		-webkit-transform: translate3d(-10px, 0, 0);
		transform: translate3d(-10px, 0, 0);
	}
	90% {
		-webkit-transform: translate3d(5px, 0, 0);
		transform: translate3d(5px, 0, 0);
	}
	100% {
		-webkit-transform: none;
		transform: none;
	}
}

.bounceInLeft {
	-webkit-animation-name: bounceInLeft;
	animation-name: bounceInLeft;
}

/**
* BounceInRight Keyframes Animation
*/
@-webkit-keyframes bounceInRight {
	0%, 60%, 75%, 90%, 100% {
		-webkit-transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
		transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
	}
	0% {
		opacity: 0;
		-webkit-transform: translate3d(3000px, 0, 0);
		transform: translate3d(3000px, 0, 0);
	}
	60% {
		opacity: 1;
		-webkit-transform: translate3d(-25px, 0, 0);
		transform: translate3d(-25px, 0, 0);
	}
	75% {
		-webkit-transform: translate3d(10px, 0, 0);
		transform: translate3d(10px, 0, 0);
	}
	90% {
		-webkit-transform: translate3d(-5px, 0, 0);
		transform: translate3d(-5px, 0, 0);
	}
	100% {
		-webkit-transform: none;
		transform: none;
	}
}

@keyframes bounceInRight {
	0%, 60%, 75%, 90%, 100% {
		-webkit-transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
		transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
	}
	0% {
		opacity: 0;
		-webkit-transform: translate3d(3000px, 0, 0);
		transform: translate3d(3000px, 0, 0);
	}
	60% {
		opacity: 1;
		-webkit-transform: translate3d(-25px, 0, 0);
		transform: translate3d(-25px, 0, 0);
	}
	75% {
		-webkit-transform: translate3d(10px, 0, 0);
		transform: translate3d(10px, 0, 0);
	}
	90% {
		-webkit-transform: translate3d(-5px, 0, 0);
		transform: translate3d(-5px, 0, 0);
	}
	100% {
		-webkit-transform: none;
		transform: none;
	}
}

.bounceInRight {
	-webkit-animation-name: bounceInRight;
	animation-name: bounceInRight;
}

/**
* BounceInUp Keyframes Animation
*/
@-webkit-keyframes bounceInUp {
	0%, 60%, 75%, 90%, 100% {
		-webkit-transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
		transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
	}
	0% {
		opacity: 0;
		-webkit-transform: translate3d(0, 3000px, 0);
		transform: translate3d(0, 3000px, 0);
	}
	60% {
		opacity: 1;
		-webkit-transform: translate3d(0, -20px, 0);
		transform: translate3d(0, -20px, 0);
	}
	75% {
		-webkit-transform: translate3d(0, 10px, 0);
		transform: translate3d(0, 10px, 0);
	}
	90% {
		-webkit-transform: translate3d(0, -5px, 0);
		transform: translate3d(0, -5px, 0);
	}
	100% {
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
}

@keyframes bounceInUp {
	0%, 60%, 75%, 90%, 100% {
		-webkit-transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
		transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
	}
	0% {
		opacity: 0;
		-webkit-transform: translate3d(0, 3000px, 0);
		transform: translate3d(0, 3000px, 0);
	}
	60% {
		opacity: 1;
		-webkit-transform: translate3d(0, -20px, 0);
		transform: translate3d(0, -20px, 0);
	}
	75% {
		-webkit-transform: translate3d(0, 10px, 0);
		transform: translate3d(0, 10px, 0);
	}
	90% {
		-webkit-transform: translate3d(0, -5px, 0);
		transform: translate3d(0, -5px, 0);
	}
	100% {
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
}

.bounceInUp {
	-webkit-animation-name: bounceInUp;
	animation-name: bounceInUp;
}

/**
* BounceOut Keyframes Animation
*/
@-webkit-keyframes bounceOut {
	20% {
		-webkit-transform: scale3d(0.9, 0.9, 0.9);
		transform: scale3d(0.9, 0.9, 0.9);
	}
	50%, 55% {
		opacity: 1;
		-webkit-transform: scale3d(1.1, 1.1, 1.1);
		transform: scale3d(1.1, 1.1, 1.1);
	}
	100% {
		opacity: 0;
		-webkit-transform: scale3d(0.3, 0.3, 0.3);
		transform: scale3d(0.3, 0.3, 0.3);
	}
}

@keyframes bounceOut {
	20% {
		-webkit-transform: scale3d(0.9, 0.9, 0.9);
		transform: scale3d(0.9, 0.9, 0.9);
	}
	50%, 55% {
		opacity: 1;
		-webkit-transform: scale3d(1.1, 1.1, 1.1);
		transform: scale3d(1.1, 1.1, 1.1);
	}
	100% {
		opacity: 0;
		-webkit-transform: scale3d(0.3, 0.3, 0.3);
		transform: scale3d(0.3, 0.3, 0.3);
	}
}

.bounceOut {
	-webkit-animation-name: bounceOut;
	animation-name: bounceOut;
	-webkit-animation-duration: .75s;
	animation-duration: .75s;
}

/**
* BounceOutDown Keyframes Animation
*/
@-webkit-keyframes bounceOutDown {
	20% {
		-webkit-transform: translate3d(0, 10px, 0);
		transform: translate3d(0, 10px, 0);
	}
	40%, 45% {
		opacity: 1;
		-webkit-transform: translate3d(0, -20px, 0);
		transform: translate3d(0, -20px, 0);
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(0, 2000px, 0);
		transform: translate3d(0, 2000px, 0);
	}
}

@keyframes bounceOutDown {
	20% {
		-webkit-transform: translate3d(0, 10px, 0);
		transform: translate3d(0, 10px, 0);
	}
	40%, 45% {
		opacity: 1;
		-webkit-transform: translate3d(0, -20px, 0);
		transform: translate3d(0, -20px, 0);
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(0, 2000px, 0);
		transform: translate3d(0, 2000px, 0);
	}
}

.bounceOutDown {
	-webkit-animation-name: bounceOutDown;
	animation-name: bounceOutDown;
}

/**
* BounceOutLeft Keyframes Animation
*/
@-webkit-keyframes bounceOutLeft {
	20% {
		opacity: 1;
		-webkit-transform: translate3d(20px, 0, 0);
		transform: translate3d(20px, 0, 0);
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(-2000px, 0, 0);
		transform: translate3d(-2000px, 0, 0);
	}
}

@keyframes bounceOutLeft {
	20% {
		opacity: 1;
		-webkit-transform: translate3d(20px, 0, 0);
		transform: translate3d(20px, 0, 0);
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(-2000px, 0, 0);
		transform: translate3d(-2000px, 0, 0);
	}
}

.bounceOutLeft {
	-webkit-animation-name: bounceOutLeft;
	animation-name: bounceOutLeft;
}

/**
* BounceOutRight Keyframes Animation
*/
@-webkit-keyframes bounceOutRight {
	20% {
		opacity: 1;
		-webkit-transform: translate3d(-20px, 0, 0);
		transform: translate3d(-20px, 0, 0);
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(2000px, 0, 0);
		transform: translate3d(2000px, 0, 0);
	}
}

@keyframes bounceOutRight {
	20% {
		opacity: 1;
		-webkit-transform: translate3d(-20px, 0, 0);
		transform: translate3d(-20px, 0, 0);
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(2000px, 0, 0);
		transform: translate3d(2000px, 0, 0);
	}
}

.bounceOutRight {
	-webkit-animation-name: bounceOutRight;
	animation-name: bounceOutRight;
}

/**
* BounceOutUp Keyframes Animation
*/
@-webkit-keyframes bounceOutUp {
	20% {
		-webkit-transform: translate3d(0, -10px, 0);
		transform: translate3d(0, -10px, 0);
	}
	40%, 45% {
		opacity: 1;
		-webkit-transform: translate3d(0, 20px, 0);
		transform: translate3d(0, 20px, 0);
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(0, -2000px, 0);
		transform: translate3d(0, -2000px, 0);
	}
}

@keyframes bounceOutUp {
	20% {
		-webkit-transform: translate3d(0, -10px, 0);
		transform: translate3d(0, -10px, 0);
	}
	40%, 45% {
		opacity: 1;
		-webkit-transform: translate3d(0, 20px, 0);
		transform: translate3d(0, 20px, 0);
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(0, -2000px, 0);
		transform: translate3d(0, -2000px, 0);
	}
}

.bounceOutUp {
	-webkit-animation-name: bounceOutUp;
	animation-name: bounceOutUp;
}

/**
* FadeIn Keyframes Animation
*/
@-webkit-keyframes fadeIn {
	0% {
		opacity: 0;
	}
	100% {
		opacity: 1;
	}
}

@keyframes fadeIn {
	0% {
		opacity: 0;
	}
	100% {
		opacity: 1;
	}
}

.fadeIn {
	-webkit-animation-name: fadeIn;
	animation-name: fadeIn;
}

/**
* FadeInDown Keyframes Animation
*/
@-webkit-keyframes fadeInDown {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(0, -100%, 0);
		transform: translate3d(0, -100%, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

@keyframes fadeInDown {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(0, -100%, 0);
		transform: translate3d(0, -100%, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

.fadeInDown {
	-webkit-animation-name: fadeInDown;
	animation-name: fadeInDown;
}

/**
* FadeInDownBig Keyframes Animation
*/
@-webkit-keyframes fadeInDownBig {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(0, -2000px, 0);
		transform: translate3d(0, -2000px, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

@keyframes fadeInDownBig {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(0, -2000px, 0);
		transform: translate3d(0, -2000px, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

.fadeInDownBig {
	-webkit-animation-name: fadeInDownBig;
	animation-name: fadeInDownBig;
}

/**
* FadeInLeftSmall Keyframes Animation
*/
@-webkit-keyframes fadeInLeftSmall {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(-33%, 0, 0);
		transform: translate3d(-33%, 0, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

@keyframes fadeInLeftSmall {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(-33%, 0, 0);
		transform: translate3d(-33%, 0, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

.fadeInLeftSmall {
	-webkit-animation-name: fadeInLeftSmall;
	animation-name: fadeInLeftSmall;
}

/**
* FadeInLeft Keyframes Animation
*/
@-webkit-keyframes fadeInLeft {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(-100%, 0, 0);
		transform: translate3d(-100%, 0, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

@keyframes fadeInLeft {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(-100%, 0, 0);
		transform: translate3d(-100%, 0, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

.fadeInLeft {
	-webkit-animation-name: fadeInLeft;
	animation-name: fadeInLeft;
}

/**
* FadeInLeftBig Keyframes Animation
*/
@-webkit-keyframes fadeInLeftBig {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(-2000px, 0, 0);
		transform: translate3d(-2000px, 0, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

@keyframes fadeInLeftBig {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(-2000px, 0, 0);
		transform: translate3d(-2000px, 0, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

.fadeInLeftBig {
	-webkit-animation-name: fadeInLeftBig;
	animation-name: fadeInLeftBig;
}

/**
* FadeInRight Keyframes Animation
*/
@-webkit-keyframes fadeInRight {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(100%, 0, 0);
		transform: translate3d(100%, 0, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

@keyframes fadeInRight {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(100%, 0, 0);
		transform: translate3d(100%, 0, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

.fadeInRight {
	-webkit-animation-name: fadeInRight;
	animation-name: fadeInRight;
}

/**
* FadeInRightSmall Keyframes Animation
*/
@-webkit-keyframes fadeInRightSmall {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(33%, 0, 0);
		transform: translate3d(33%, 0, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

@keyframes fadeInRightSmall {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(33%, 0, 0);
		transform: translate3d(33%, 0, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

.fadeInRightSmall {
	-webkit-animation-name: fadeInRightSmall;
	animation-name: fadeInRightSmall;
}

/**
* FadeInRightMedium Keyframes Animation
*/
@-webkit-keyframes fadeInRightMedium {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(66%, 0, 0);
		transform: translate3d(66%, 0, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

@keyframes fadeInRightMedium {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(66%, 0, 0);
		transform: translate3d(66%, 0, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

.fadeInRightMedium {
	-webkit-animation-name: fadeInRightMedium;
	animation-name: fadeInRightMedium;
}

/**
* FadeInRightBig Keyframes Animation
*/
@-webkit-keyframes fadeInRightBig {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(2000px, 0, 0);
		transform: translate3d(2000px, 0, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

@keyframes fadeInRightBig {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(2000px, 0, 0);
		transform: translate3d(2000px, 0, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

.fadeInRightBig {
	-webkit-animation-name: fadeInRightBig;
	animation-name: fadeInRightBig;
}

/**
* FadeInUp Keyframes Animation
*/
@-webkit-keyframes fadeInUp {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(0, 100%, 0);
		transform: translate3d(0, 100%, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

@keyframes fadeInUp {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(0, 100%, 0);
		transform: translate3d(0, 100%, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

.fadeInUp {
	-webkit-animation-name: fadeInUp;
	animation-name: fadeInUp;
}

/**
* FadeInUpBig Keyframes Animation
*/
@-webkit-keyframes fadeInUpBig {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(0, 2000px, 0);
		transform: translate3d(0, 2000px, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

@keyframes fadeInUpBig {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(0, 2000px, 0);
		transform: translate3d(0, 2000px, 0);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

.fadeInUpBig {
	-webkit-animation-name: fadeInUpBig;
	animation-name: fadeInUpBig;
}

/**
* FadeOut Keyframes Animation
*/
@-webkit-keyframes fadeOut {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
	}
}

@keyframes fadeOut {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
	}
}

.fadeOut {
	-webkit-animation-name: fadeOut;
	animation-name: fadeOut;
}

/**
* FadeOutDown Keyframes Animation
*/
@-webkit-keyframes fadeOutDown {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(0, 100%, 0);
		transform: translate3d(0, 100%, 0);
	}
}

@keyframes fadeOutDown {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(0, 100%, 0);
		transform: translate3d(0, 100%, 0);
	}
}

.fadeOutDown {
	-webkit-animation-name: fadeOutDown;
	animation-name: fadeOutDown;
}

/**
* FadeOutDownBig Keyframes Animation
*/
@-webkit-keyframes fadeOutDownBig {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(0, 2000px, 0);
		transform: translate3d(0, 2000px, 0);
	}
}

@keyframes fadeOutDownBig {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(0, 2000px, 0);
		transform: translate3d(0, 2000px, 0);
	}
}

.fadeOutDownBig {
	-webkit-animation-name: fadeOutDownBig;
	animation-name: fadeOutDownBig;
}

/**
* FadeOutLeft Keyframes Animation
*/
@-webkit-keyframes fadeOutLeft {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(-100%, 0, 0);
		transform: translate3d(-100%, 0, 0);
	}
}

@keyframes fadeOutLeft {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(-100%, 0, 0);
		transform: translate3d(-100%, 0, 0);
	}
}

.fadeOutLeft {
	-webkit-animation-name: fadeOutLeft;
	animation-name: fadeOutLeft;
}

/**
* FadeOutLeftBig Keyframes Animation
*/
@-webkit-keyframes fadeOutLeftBig {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(-2000px, 0, 0);
		transform: translate3d(-2000px, 0, 0);
	}
}

@keyframes fadeOutLeftBig {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(-2000px, 0, 0);
		transform: translate3d(-2000px, 0, 0);
	}
}

.fadeOutLeftBig {
	-webkit-animation-name: fadeOutLeftBig;
	animation-name: fadeOutLeftBig;
}

/**
* FadeOutRight Keyframes Animation
*/
@-webkit-keyframes fadeOutRight {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(100%, 0, 0);
		transform: translate3d(100%, 0, 0);
	}
}

@keyframes fadeOutRight {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(100%, 0, 0);
		transform: translate3d(100%, 0, 0);
	}
}

.fadeOutRight {
	-webkit-animation-name: fadeOutRight;
	animation-name: fadeOutRight;
}

/**
* FadeOutRightBig Keyframes Animation
*/
@-webkit-keyframes fadeOutRightBig {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(2000px, 0, 0);
		transform: translate3d(2000px, 0, 0);
	}
}

@keyframes fadeOutRightBig {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(2000px, 0, 0);
		transform: translate3d(2000px, 0, 0);
	}
}

.fadeOutRightBig {
	-webkit-animation-name: fadeOutRightBig;
	animation-name: fadeOutRightBig;
}

/**
* FadeOutUp Keyframes Animation
*/
@-webkit-keyframes fadeOutUp {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(0, -100%, 0);
		transform: translate3d(0, -100%, 0);
	}
}

@keyframes fadeOutUp {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(0, -100%, 0);
		transform: translate3d(0, -100%, 0);
	}
}

.fadeOutUp {
	-webkit-animation-name: fadeOutUp;
	animation-name: fadeOutUp;
}

/**
* FadeOutUpBig Keyframes Animation
*/
@-webkit-keyframes fadeOutUpBig {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(0, -2000px, 0);
		transform: translate3d(0, -2000px, 0);
	}
}

@keyframes fadeOutUpBig {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(0, -2000px, 0);
		transform: translate3d(0, -2000px, 0);
	}
}

.fadeOutUpBig {
	-webkit-animation-name: fadeOutUpBig;
	animation-name: fadeOutUpBig;
}

/**
* Flip Keyframes Animation
*/
@-webkit-keyframes flip {
	0% {
		-webkit-transform: perspective(400px) rotate3d(0, 1, 0, -360deg);
		transform: perspective(400px) rotate3d(0, 1, 0, -360deg);
		-webkit-animation-timing-function: ease-out;
		animation-timing-function: ease-out;
	}
	40% {
		-webkit-transform: perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -190deg);
		transform: perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -190deg);
		-webkit-animation-timing-function: ease-out;
		animation-timing-function: ease-out;
	}
	50% {
		-webkit-transform: perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -170deg);
		transform: perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -170deg);
		-webkit-animation-timing-function: ease-in;
		animation-timing-function: ease-in;
	}
	80% {
		-webkit-transform: perspective(400px) scale3d(0.95, 0.95, 0.95);
		transform: perspective(400px) scale3d(0.95, 0.95, 0.95);
		-webkit-animation-timing-function: ease-in;
		animation-timing-function: ease-in;
	}
	100% {
		-webkit-transform: perspective(400px);
		transform: perspective(400px);
		-webkit-animation-timing-function: ease-in;
		animation-timing-function: ease-in;
	}
}

@keyframes flip {
	0% {
		-webkit-transform: perspective(400px) rotate3d(0, 1, 0, -360deg);
		transform: perspective(400px) rotate3d(0, 1, 0, -360deg);
		-webkit-animation-timing-function: ease-out;
		animation-timing-function: ease-out;
	}
	40% {
		-webkit-transform: perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -190deg);
		transform: perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -190deg);
		-webkit-animation-timing-function: ease-out;
		animation-timing-function: ease-out;
	}
	50% {
		-webkit-transform: perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -170deg);
		transform: perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -170deg);
		-webkit-animation-timing-function: ease-in;
		animation-timing-function: ease-in;
	}
	80% {
		-webkit-transform: perspective(400px) scale3d(0.95, 0.95, 0.95);
		transform: perspective(400px) scale3d(0.95, 0.95, 0.95);
		-webkit-animation-timing-function: ease-in;
		animation-timing-function: ease-in;
	}
	100% {
		-webkit-transform: perspective(400px);
		transform: perspective(400px);
		-webkit-animation-timing-function: ease-in;
		animation-timing-function: ease-in;
	}
}

.animated.flip {
	-webkit-backface-visibility: visible;
	backface-visibility: visible;
	-webkit-animation-name: flip;
	animation-name: flip;
}

/**
* FlipInX Keyframes Animation
*/
@-webkit-keyframes flipInX {
	0% {
		-webkit-transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
		transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
		-webkit-transition-timing-function: ease-in;
		transition-timing-function: ease-in;
		opacity: 0;
	}
	40% {
		-webkit-transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
		transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
		-webkit-transition-timing-function: ease-in;
		transition-timing-function: ease-in;
	}
	60% {
		-webkit-transform: perspective(400px) rotate3d(1, 0, 0, 10deg);
		transform: perspective(400px) rotate3d(1, 0, 0, 10deg);
		opacity: 1;
	}
	80% {
		-webkit-transform: perspective(400px) rotate3d(1, 0, 0, -5deg);
		transform: perspective(400px) rotate3d(1, 0, 0, -5deg);
	}
	100% {
		-webkit-transform: perspective(400px);
		transform: perspective(400px);
	}
}

@keyframes flipInX {
	0% {
		-webkit-transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
		transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
		-webkit-transition-timing-function: ease-in;
		transition-timing-function: ease-in;
		opacity: 0;
	}
	40% {
		-webkit-transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
		transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
		-webkit-transition-timing-function: ease-in;
		transition-timing-function: ease-in;
	}
	60% {
		-webkit-transform: perspective(400px) rotate3d(1, 0, 0, 10deg);
		transform: perspective(400px) rotate3d(1, 0, 0, 10deg);
		opacity: 1;
	}
	80% {
		-webkit-transform: perspective(400px) rotate3d(1, 0, 0, -5deg);
		transform: perspective(400px) rotate3d(1, 0, 0, -5deg);
	}
	100% {
		-webkit-transform: perspective(400px);
		transform: perspective(400px);
	}
}

.flipInX {
	-webkit-backface-visibility: visible !important;
	backface-visibility: visible !important;
	-webkit-animation-name: flipInX;
	animation-name: flipInX;
}

/**
* FlipInY Keyframes Animation
*/
@-webkit-keyframes flipInY {
	0% {
		-webkit-transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
		transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
		-webkit-transition-timing-function: ease-in;
		transition-timing-function: ease-in;
		opacity: 0;
	}
	40% {
		-webkit-transform: perspective(400px) rotate3d(0, 1, 0, -20deg);
		transform: perspective(400px) rotate3d(0, 1, 0, -20deg);
		-webkit-transition-timing-function: ease-in;
		transition-timing-function: ease-in;
	}
	60% {
		-webkit-transform: perspective(400px) rotate3d(0, 1, 0, 10deg);
		transform: perspective(400px) rotate3d(0, 1, 0, 10deg);
		opacity: 1;
	}
	80% {
		-webkit-transform: perspective(400px) rotate3d(0, 1, 0, -5deg);
		transform: perspective(400px) rotate3d(0, 1, 0, -5deg);
	}
	100% {
		-webkit-transform: perspective(400px);
		transform: perspective(400px);
	}
}

@keyframes flipInY {
	0% {
		-webkit-transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
		transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
		-webkit-transition-timing-function: ease-in;
		transition-timing-function: ease-in;
		opacity: 0;
	}
	40% {
		-webkit-transform: perspective(400px) rotate3d(0, 1, 0, -20deg);
		transform: perspective(400px) rotate3d(0, 1, 0, -20deg);
		-webkit-transition-timing-function: ease-in;
		transition-timing-function: ease-in;
	}
	60% {
		-webkit-transform: perspective(400px) rotate3d(0, 1, 0, 10deg);
		transform: perspective(400px) rotate3d(0, 1, 0, 10deg);
		opacity: 1;
	}
	80% {
		-webkit-transform: perspective(400px) rotate3d(0, 1, 0, -5deg);
		transform: perspective(400px) rotate3d(0, 1, 0, -5deg);
	}
	100% {
		-webkit-transform: perspective(400px);
		transform: perspective(400px);
	}
}

.flipInY {
	-webkit-backface-visibility: visible !important;
	backface-visibility: visible !important;
	-webkit-animation-name: flipInY;
	animation-name: flipInY;
}

/**
* FlipOutX Keyframes Animation
*/
@-webkit-keyframes flipOutX {
	0% {
		-webkit-transform: perspective(400px);
		transform: perspective(400px);
	}
	30% {
		-webkit-transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
		transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
		opacity: 1;
	}
	100% {
		-webkit-transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
		transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
		opacity: 0;
	}
}

@keyframes flipOutX {
	0% {
		-webkit-transform: perspective(400px);
		transform: perspective(400px);
	}
	30% {
		-webkit-transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
		transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
		opacity: 1;
	}
	100% {
		-webkit-transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
		transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
		opacity: 0;
	}
}

.flipOutX {
	-webkit-animation-name: flipOutX;
	animation-name: flipOutX;
	-webkit-animation-duration: .75s;
	animation-duration: .75s;
	-webkit-backface-visibility: visible !important;
	backface-visibility: visible !important;
}

/**
* FlipOutY Keyframes Animation
*/
@-webkit-keyframes flipOutY {
	0% {
		-webkit-transform: perspective(400px);
		transform: perspective(400px);
	}
	30% {
		-webkit-transform: perspective(400px) rotate3d(0, 1, 0, -15deg);
		transform: perspective(400px) rotate3d(0, 1, 0, -15deg);
		opacity: 1;
	}
	100% {
		-webkit-transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
		transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
		opacity: 0;
	}
}

@keyframes flipOutY {
	0% {
		-webkit-transform: perspective(400px);
		transform: perspective(400px);
	}
	30% {
		-webkit-transform: perspective(400px) rotate3d(0, 1, 0, -15deg);
		transform: perspective(400px) rotate3d(0, 1, 0, -15deg);
		opacity: 1;
	}
	100% {
		-webkit-transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
		transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
		opacity: 0;
	}
}

.flipOutY {
	-webkit-backface-visibility: visible !important;
	backface-visibility: visible !important;
	-webkit-animation-name: flipOutY;
	animation-name: flipOutY;
	-webkit-animation-duration: .75s;
	animation-duration: .75s;
}

/**
* LightSpeedIn Keyframes Animation
*/
@-webkit-keyframes lightSpeedIn {
	0% {
		-webkit-transform: translate3d(100%, 0, 0) skewX(-30deg);
		transform: translate3d(100%, 0, 0) skewX(-30deg);
		opacity: 0;
	}
	60% {
		-webkit-transform: skewX(20deg);
		transform: skewX(20deg);
		opacity: 1;
	}
	80% {
		-webkit-transform: skewX(-5deg);
		transform: skewX(-5deg);
		opacity: 1;
	}
	100% {
		-webkit-transform: none;
		transform: none;
		opacity: 1;
	}
}

@keyframes lightSpeedIn {
	0% {
		-webkit-transform: translate3d(100%, 0, 0) skewX(-30deg);
		transform: translate3d(100%, 0, 0) skewX(-30deg);
		opacity: 0;
	}
	60% {
		-webkit-transform: skewX(20deg);
		transform: skewX(20deg);
		opacity: 1;
	}
	80% {
		-webkit-transform: skewX(-5deg);
		transform: skewX(-5deg);
		opacity: 1;
	}
	100% {
		-webkit-transform: none;
		transform: none;
		opacity: 1;
	}
}

.lightSpeedIn {
	-webkit-animation-name: lightSpeedIn;
	animation-name: lightSpeedIn;
	-webkit-animation-timing-function: ease-out;
	animation-timing-function: ease-out;
}

/**
* LightSpeedOut Keyframes Animation
*/
@-webkit-keyframes lightSpeedOut {
	0% {
		opacity: 1;
	}
	100% {
		-webkit-transform: translate3d(100%, 0, 0) skewX(30deg);
		transform: translate3d(100%, 0, 0) skewX(30deg);
		opacity: 0;
	}
}

@keyframes lightSpeedOut {
	0% {
		opacity: 1;
	}
	100% {
		-webkit-transform: translate3d(100%, 0, 0) skewX(30deg);
		transform: translate3d(100%, 0, 0) skewX(30deg);
		opacity: 0;
	}
}

.lightSpeedOut {
	-webkit-animation-name: lightSpeedOut;
	animation-name: lightSpeedOut;
	-webkit-animation-timing-function: ease-in;
	animation-timing-function: ease-in;
}

/**
* RotateIn Keyframes Animation
*/
@-webkit-keyframes rotateIn {
	0% {
		-webkit-transform-origin: center;
		transform-origin: center;
		-webkit-transform: rotate3d(0, 0, 1, -200deg);
		transform: rotate3d(0, 0, 1, -200deg);
		opacity: 0;
	}
	100% {
		-webkit-transform-origin: center;
		transform-origin: center;
		-webkit-transform: none;
		transform: none;
		opacity: 1;
	}
}

@keyframes rotateIn {
	0% {
		-webkit-transform-origin: center;
		transform-origin: center;
		-webkit-transform: rotate3d(0, 0, 1, -200deg);
		transform: rotate3d(0, 0, 1, -200deg);
		opacity: 0;
	}
	100% {
		-webkit-transform-origin: center;
		transform-origin: center;
		-webkit-transform: none;
		transform: none;
		opacity: 1;
	}
}

.rotateIn {
	-webkit-animation-name: rotateIn;
	animation-name: rotateIn;
}

/**
* RotateInDownLeft Keyframes Animation
*/
@-webkit-keyframes rotateInDownLeft {
	0% {
		-webkit-transform-origin: left bottom;
		transform-origin: left bottom;
		-webkit-transform: rotate3d(0, 0, 1, -45deg);
		transform: rotate3d(0, 0, 1, -45deg);
		opacity: 0;
	}
	100% {
		-webkit-transform-origin: left bottom;
		transform-origin: left bottom;
		-webkit-transform: none;
		transform: none;
		opacity: 1;
	}
}

@keyframes rotateInDownLeft {
	0% {
		-webkit-transform-origin: left bottom;
		transform-origin: left bottom;
		-webkit-transform: rotate3d(0, 0, 1, -45deg);
		transform: rotate3d(0, 0, 1, -45deg);
		opacity: 0;
	}
	100% {
		-webkit-transform-origin: left bottom;
		transform-origin: left bottom;
		-webkit-transform: none;
		transform: none;
		opacity: 1;
	}
}

.rotateInDownLeft {
	-webkit-animation-name: rotateInDownLeft;
	animation-name: rotateInDownLeft;
}

/**
* RotateInDownRight Keyframes Animation
*/
@-webkit-keyframes rotateInDownRight {
	0% {
		-webkit-transform-origin: right bottom;
		transform-origin: right bottom;
		-webkit-transform: rotate3d(0, 0, 1, 45deg);
		transform: rotate3d(0, 0, 1, 45deg);
		opacity: 0;
	}
	100% {
		-webkit-transform-origin: right bottom;
		transform-origin: right bottom;
		-webkit-transform: none;
		transform: none;
		opacity: 1;
	}
}

@keyframes rotateInDownRight {
	0% {
		-webkit-transform-origin: right bottom;
		transform-origin: right bottom;
		-webkit-transform: rotate3d(0, 0, 1, 45deg);
		transform: rotate3d(0, 0, 1, 45deg);
		opacity: 0;
	}
	100% {
		-webkit-transform-origin: right bottom;
		transform-origin: right bottom;
		-webkit-transform: none;
		transform: none;
		opacity: 1;
	}
}

.rotateInDownRight {
	-webkit-animation-name: rotateInDownRight;
	animation-name: rotateInDownRight;
}

/**
* RotateInUpLeft Keyframes Animation
*/
@-webkit-keyframes rotateInUpLeft {
	0% {
		-webkit-transform-origin: left bottom;
		transform-origin: left bottom;
		-webkit-transform: rotate3d(0, 0, 1, 45deg);
		transform: rotate3d(0, 0, 1, 45deg);
		opacity: 0;
	}
	100% {
		-webkit-transform-origin: left bottom;
		transform-origin: left bottom;
		-webkit-transform: none;
		transform: none;
		opacity: 1;
	}
}

@keyframes rotateInUpLeft {
	0% {
		-webkit-transform-origin: left bottom;
		transform-origin: left bottom;
		-webkit-transform: rotate3d(0, 0, 1, 45deg);
		transform: rotate3d(0, 0, 1, 45deg);
		opacity: 0;
	}
	100% {
		-webkit-transform-origin: left bottom;
		transform-origin: left bottom;
		-webkit-transform: none;
		transform: none;
		opacity: 1;
	}
}

.rotateInUpLeft {
	-webkit-animation-name: rotateInUpLeft;
	animation-name: rotateInUpLeft;
}

/**
* RotateInUpRight Keyframes Animation
*/
@-webkit-keyframes rotateInUpRight {
	0% {
		-webkit-transform-origin: right bottom;
		transform-origin: right bottom;
		-webkit-transform: rotate3d(0, 0, 1, -90deg);
		transform: rotate3d(0, 0, 1, -90deg);
		opacity: 0;
	}
	100% {
		-webkit-transform-origin: right bottom;
		transform-origin: right bottom;
		-webkit-transform: none;
		transform: none;
		opacity: 1;
	}
}

@keyframes rotateInUpRight {
	0% {
		-webkit-transform-origin: right bottom;
		transform-origin: right bottom;
		-webkit-transform: rotate3d(0, 0, 1, -90deg);
		transform: rotate3d(0, 0, 1, -90deg);
		opacity: 0;
	}
	100% {
		-webkit-transform-origin: right bottom;
		transform-origin: right bottom;
		-webkit-transform: none;
		transform: none;
		opacity: 1;
	}
}

.rotateInUpRight {
	-webkit-animation-name: rotateInUpRight;
	animation-name: rotateInUpRight;
}

/**
* RotateOut Keyframes Animation
*/
@-webkit-keyframes rotateOut {
	0% {
		-webkit-transform-origin: center;
		transform-origin: center;
		opacity: 1;
	}
	100% {
		-webkit-transform-origin: center;
		transform-origin: center;
		-webkit-transform: rotate3d(0, 0, 1, 200deg);
		transform: rotate3d(0, 0, 1, 200deg);
		opacity: 0;
	}
}

@keyframes rotateOut {
	0% {
		-webkit-transform-origin: center;
		transform-origin: center;
		opacity: 1;
	}
	100% {
		-webkit-transform-origin: center;
		transform-origin: center;
		-webkit-transform: rotate3d(0, 0, 1, 200deg);
		transform: rotate3d(0, 0, 1, 200deg);
		opacity: 0;
	}
}

.rotateOut {
	-webkit-animation-name: rotateOut;
	animation-name: rotateOut;
}

/**
* RotateOutDownLeft Keyframes Animation
*/
@-webkit-keyframes rotateOutDownLeft {
	0% {
		-webkit-transform-origin: left bottom;
		transform-origin: left bottom;
		opacity: 1;
	}
	100% {
		-webkit-transform-origin: left bottom;
		transform-origin: left bottom;
		-webkit-transform: rotate3d(0, 0, 1, 45deg);
		transform: rotate3d(0, 0, 1, 45deg);
		opacity: 0;
	}
}

@keyframes rotateOutDownLeft {
	0% {
		-webkit-transform-origin: left bottom;
		transform-origin: left bottom;
		opacity: 1;
	}
	100% {
		-webkit-transform-origin: left bottom;
		transform-origin: left bottom;
		-webkit-transform: rotate3d(0, 0, 1, 45deg);
		transform: rotate3d(0, 0, 1, 45deg);
		opacity: 0;
	}
}

.rotateOutDownLeft {
	-webkit-animation-name: rotateOutDownLeft;
	animation-name: rotateOutDownLeft;
}

/**
* RotateOutDownRight Keyframes Animation
*/
@-webkit-keyframes rotateOutDownRight {
	0% {
		-webkit-transform-origin: right bottom;
		transform-origin: right bottom;
		opacity: 1;
	}
	100% {
		-webkit-transform-origin: right bottom;
		transform-origin: right bottom;
		-webkit-transform: rotate3d(0, 0, 1, -45deg);
		transform: rotate3d(0, 0, 1, -45deg);
		opacity: 0;
	}
}

@keyframes rotateOutDownRight {
	0% {
		-webkit-transform-origin: right bottom;
		transform-origin: right bottom;
		opacity: 1;
	}
	100% {
		-webkit-transform-origin: right bottom;
		transform-origin: right bottom;
		-webkit-transform: rotate3d(0, 0, 1, -45deg);
		transform: rotate3d(0, 0, 1, -45deg);
		opacity: 0;
	}
}

.rotateOutDownRight {
	-webkit-animation-name: rotateOutDownRight;
	animation-name: rotateOutDownRight;
}

/**
* RotateOutUpLeft Keyframes Animation
*/
@-webkit-keyframes rotateOutUpLeft {
	0% {
		-webkit-transform-origin: left bottom;
		transform-origin: left bottom;
		opacity: 1;
	}
	100% {
		-webkit-transform-origin: left bottom;
		transform-origin: left bottom;
		-webkit-transform: rotate3d(0, 0, 1, -45deg);
		transform: rotate3d(0, 0, 1, -45deg);
		opacity: 0;
	}
}

@keyframes rotateOutUpLeft {
	0% {
		-webkit-transform-origin: left bottom;
		transform-origin: left bottom;
		opacity: 1;
	}
	100% {
		-webkit-transform-origin: left bottom;
		transform-origin: left bottom;
		-webkit-transform: rotate3d(0, 0, 1, -45deg);
		transform: rotate3d(0, 0, 1, -45deg);
		opacity: 0;
	}
}

.rotateOutUpLeft {
	-webkit-animation-name: rotateOutUpLeft;
	animation-name: rotateOutUpLeft;
}

/**
* RotateOutUpRight Keyframes Animation
*/
@-webkit-keyframes rotateOutUpRight {
	0% {
		-webkit-transform-origin: right bottom;
		transform-origin: right bottom;
		opacity: 1;
	}
	100% {
		-webkit-transform-origin: right bottom;
		transform-origin: right bottom;
		-webkit-transform: rotate3d(0, 0, 1, 90deg);
		transform: rotate3d(0, 0, 1, 90deg);
		opacity: 0;
	}
}

@keyframes rotateOutUpRight {
	0% {
		-webkit-transform-origin: right bottom;
		transform-origin: right bottom;
		opacity: 1;
	}
	100% {
		-webkit-transform-origin: right bottom;
		transform-origin: right bottom;
		-webkit-transform: rotate3d(0, 0, 1, 90deg);
		transform: rotate3d(0, 0, 1, 90deg);
		opacity: 0;
	}
}

.rotateOutUpRight {
	-webkit-animation-name: rotateOutUpRight;
	animation-name: rotateOutUpRight;
}

/**
* Hinge Keyframes Animation
*/
@-webkit-keyframes hinge {
	0% {
		-webkit-transform-origin: top left;
		transform-origin: top left;
		-webkit-animation-timing-function: ease-in-out;
		animation-timing-function: ease-in-out;
	}
	20%, 60% {
		-webkit-transform: rotate3d(0, 0, 1, 80deg);
		transform: rotate3d(0, 0, 1, 80deg);
		-webkit-transform-origin: top left;
		transform-origin: top left;
		-webkit-animation-timing-function: ease-in-out;
		animation-timing-function: ease-in-out;
	}
	40%, 80% {
		-webkit-transform: rotate3d(0, 0, 1, 60deg);
		transform: rotate3d(0, 0, 1, 60deg);
		-webkit-transform-origin: top left;
		transform-origin: top left;
		-webkit-animation-timing-function: ease-in-out;
		animation-timing-function: ease-in-out;
		opacity: 1;
	}
	100% {
		-webkit-transform: translate3d(0, 700px, 0);
		transform: translate3d(0, 700px, 0);
		opacity: 0;
	}
}

@keyframes hinge {
	0% {
		-webkit-transform-origin: top left;
		transform-origin: top left;
		-webkit-animation-timing-function: ease-in-out;
		animation-timing-function: ease-in-out;
	}
	20%, 60% {
		-webkit-transform: rotate3d(0, 0, 1, 80deg);
		transform: rotate3d(0, 0, 1, 80deg);
		-webkit-transform-origin: top left;
		transform-origin: top left;
		-webkit-animation-timing-function: ease-in-out;
		animation-timing-function: ease-in-out;
	}
	40%, 80% {
		-webkit-transform: rotate3d(0, 0, 1, 60deg);
		transform: rotate3d(0, 0, 1, 60deg);
		-webkit-transform-origin: top left;
		transform-origin: top left;
		-webkit-animation-timing-function: ease-in-out;
		animation-timing-function: ease-in-out;
		opacity: 1;
	}
	100% {
		-webkit-transform: translate3d(0, 700px, 0);
		transform: translate3d(0, 700px, 0);
		opacity: 0;
	}
}

.hinge {
	-webkit-animation-name: hinge;
	animation-name: hinge;
}

/**
* RollIn Keyframes Animation
*
* @author Nick Pettit
* @link https://github.com/nickpettit/glide
*/
@-webkit-keyframes rollIn {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -120deg);
		transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -120deg);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		transform: none;
	}
}

@keyframes rollIn {
	0% {
		opacity: 0;
		-webkit-transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -120deg);
		-ms-transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -120deg);
		transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -120deg);
	}
	100% {
		opacity: 1;
		-webkit-transform: none;
		-ms-transform: none;
		transform: none;
	}
}

.rollIn {
	-webkit-animation-name: rollIn;
	animation-name: rollIn;
}

/**
* RollOut Keyframes Animation
*
* @author Nick Pettit
* @link https://github.com/nickpettit/glide
*/
@-webkit-keyframes rollOut {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(100%, 0, 0) rotate3d(0, 0, 1, 120deg);
		transform: translate3d(100%, 0, 0) rotate3d(0, 0, 1, 120deg);
	}
}

@keyframes rollOut {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
		-webkit-transform: translate3d(100%, 0, 0) rotate3d(0, 0, 1, 120deg);
		transform: translate3d(100%, 0, 0) rotate3d(0, 0, 1, 120deg);
	}
}

.rollOut {
	-webkit-animation-name: rollOut;
	animation-name: rollOut;
}

/**
* ZoomIn Keyframes Animation
*/
@-webkit-keyframes zoomIn {
	0% {
		opacity: 0;
		-webkit-transform: scale3d(0.3, 0.3, 0.3);
		transform: scale3d(0.3, 0.3, 0.3);
	}
	50% {
		opacity: 1;
	}
}

@keyframes zoomIn {
	0% {
		opacity: 0;
		-webkit-transform: scale3d(0.3, 0.3, 0.3);
		transform: scale3d(0.3, 0.3, 0.3);
	}
	50% {
		opacity: 1;
	}
}

.zoomIn {
	-webkit-animation-name: zoomIn;
	animation-name: zoomIn;
}

/**
* ZoomInDown Keyframes Animation
*/
@-webkit-keyframes zoomInDown {
	0% {
		opacity: 0;
		-webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(0, -1000px, 0);
		transform: scale3d(0.1, 0.1, 0.1) translate3d(0, -1000px, 0);
		-webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
		animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
	}
	60% {
		opacity: 1;
		-webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0);
		transform: scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0);
		-webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
		animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
	}
}

@keyframes zoomInDown {
	0% {
		opacity: 0;
		-webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(0, -1000px, 0);
		transform: scale3d(0.1, 0.1, 0.1) translate3d(0, -1000px, 0);
		-webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
		animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
	}
	60% {
		opacity: 1;
		-webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0);
		transform: scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0);
		-webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
		animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
	}
}

.zoomInDown {
	-webkit-animation-name: zoomInDown;
	animation-name: zoomInDown;
}

/**
* ZoomInLeft Keyframes Animation
*/
@-webkit-keyframes zoomInLeft {
	0% {
		opacity: 0;
		-webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(-1000px, 0, 0);
		transform: scale3d(0.1, 0.1, 0.1) translate3d(-1000px, 0, 0);
		-webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
		animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
	}
	60% {
		opacity: 1;
		-webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(10px, 0, 0);
		transform: scale3d(0.475, 0.475, 0.475) translate3d(10px, 0, 0);
		-webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
		animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
	}
}

@keyframes zoomInLeft {
	0% {
		opacity: 0;
		-webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(-1000px, 0, 0);
		transform: scale3d(0.1, 0.1, 0.1) translate3d(-1000px, 0, 0);
		-webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
		animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
	}
	60% {
		opacity: 1;
		-webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(10px, 0, 0);
		transform: scale3d(0.475, 0.475, 0.475) translate3d(10px, 0, 0);
		-webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
		animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
	}
}

.zoomInLeft {
	-webkit-animation-name: zoomInLeft;
	animation-name: zoomInLeft;
}

/**
* ZoomInRight Keyframes Animation
*/
@-webkit-keyframes zoomInRight {
	0% {
		opacity: 0;
		-webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(1000px, 0, 0);
		transform: scale3d(0.1, 0.1, 0.1) translate3d(1000px, 0, 0);
		-webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
		animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
	}
	60% {
		opacity: 1;
		-webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(-10px, 0, 0);
		transform: scale3d(0.475, 0.475, 0.475) translate3d(-10px, 0, 0);
		-webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
		animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
	}
}

@keyframes zoomInRight {
	0% {
		opacity: 0;
		-webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(1000px, 0, 0);
		transform: scale3d(0.1, 0.1, 0.1) translate3d(1000px, 0, 0);
		-webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
		animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
	}
	60% {
		opacity: 1;
		-webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(-10px, 0, 0);
		transform: scale3d(0.475, 0.475, 0.475) translate3d(-10px, 0, 0);
		-webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
		animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
	}
}

.zoomInRight {
	-webkit-animation-name: zoomInRight;
	animation-name: zoomInRight;
}

/**
* ZoomInUp Keyframes Animation
*/
@-webkit-keyframes zoomInUp {
	0% {
		opacity: 0;
		-webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 1000px, 0);
		transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 1000px, 0);
		-webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
		animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
	}
	60% {
		opacity: 1;
		-webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
		transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
		-webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
		animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
	}
}

@keyframes zoomInUp {
	0% {
		opacity: 0;
		-webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 1000px, 0);
		transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 1000px, 0);
		-webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
		animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
	}
	60% {
		opacity: 1;
		-webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
		transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
		-webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
		animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
	}
}

.zoomInUp {
	-webkit-animation-name: zoomInUp;
	animation-name: zoomInUp;
}

/**
* ZoomOut Keyframes Animation
*/
@-webkit-keyframes zoomOut {
	0% {
		opacity: 1;
	}
	50% {
		opacity: 0;
		-webkit-transform: scale3d(0.3, 0.3, 0.3);
		transform: scale3d(0.3, 0.3, 0.3);
	}
	100% {
		opacity: 0;
	}
}

@keyframes zoomOut {
	0% {
		opacity: 1;
	}
	50% {
		opacity: 0;
		-webkit-transform: scale3d(0.3, 0.3, 0.3);
		transform: scale3d(0.3, 0.3, 0.3);
	}
	100% {
		opacity: 0;
	}
}

.zoomOut {
	-webkit-animation-name: zoomOut;
	animation-name: zoomOut;
}

/**
* ZoomOutDown Keyframes Animation
*/
@-webkit-keyframes zoomOutDown {
	40% {
		opacity: 1;
		-webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
		transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
		-webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
		animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
	}
	100% {
		opacity: 0;
		-webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 2000px, 0);
		transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 2000px, 0);
		-webkit-transform-origin: center bottom;
		transform-origin: center bottom;
		-webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
		animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
	}
}

@keyframes zoomOutDown {
	40% {
		opacity: 1;
		-webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
		transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
		-webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
		animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
	}
	100% {
		opacity: 0;
		-webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 2000px, 0);
		transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 2000px, 0);
		-webkit-transform-origin: center bottom;
		transform-origin: center bottom;
		-webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
		animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
	}
}

.zoomOutDown {
	-webkit-animation-name: zoomOutDown;
	animation-name: zoomOutDown;
}

/**
* ZoomOutLeft Keyframes Animation
*/
@-webkit-keyframes zoomOutLeft {
	40% {
		opacity: 1;
		-webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(42px, 0, 0);
		transform: scale3d(0.475, 0.475, 0.475) translate3d(42px, 0, 0);
	}
	100% {
		opacity: 0;
		-webkit-transform: scale(0.1) translate3d(-2000px, 0, 0);
		transform: scale(0.1) translate3d(-2000px, 0, 0);
		-webkit-transform-origin: left center;
		transform-origin: left center;
	}
}

@keyframes zoomOutLeft {
	40% {
		opacity: 1;
		-webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(42px, 0, 0);
		transform: scale3d(0.475, 0.475, 0.475) translate3d(42px, 0, 0);
	}
	100% {
		opacity: 0;
		-webkit-transform: scale(0.1) translate3d(-2000px, 0, 0);
		transform: scale(0.1) translate3d(-2000px, 0, 0);
		-webkit-transform-origin: left center;
		transform-origin: left center;
	}
}

.zoomOutLeft {
	-webkit-animation-name: zoomOutLeft;
	animation-name: zoomOutLeft;
}

/**
* ZoomOutRight Keyframes Animation
*/
@-webkit-keyframes zoomOutRight {
	40% {
		opacity: 1;
		-webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(-42px, 0, 0);
		transform: scale3d(0.475, 0.475, 0.475) translate3d(-42px, 0, 0);
	}
	100% {
		opacity: 0;
		-webkit-transform: scale(0.1) translate3d(2000px, 0, 0);
		transform: scale(0.1) translate3d(2000px, 0, 0);
		-webkit-transform-origin: right center;
		transform-origin: right center;
	}
}

@keyframes zoomOutRight {
	40% {
		opacity: 1;
		-webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(-42px, 0, 0);
		transform: scale3d(0.475, 0.475, 0.475) translate3d(-42px, 0, 0);
	}
	100% {
		opacity: 0;
		-webkit-transform: scale(0.1) translate3d(2000px, 0, 0);
		transform: scale(0.1) translate3d(2000px, 0, 0);
		-webkit-transform-origin: right center;
		transform-origin: right center;
	}
}

.zoomOutRight {
	-webkit-animation-name: zoomOutRight;
	animation-name: zoomOutRight;
}

/**
* ZoomOutUp Keyframes Animation
*/
@-webkit-keyframes zoomOutUp {
	40% {
		opacity: 1;
		-webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0);
		transform: scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0);
		-webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
		animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
	}
	100% {
		opacity: 0;
		-webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(0, -2000px, 0);
		transform: scale3d(0.1, 0.1, 0.1) translate3d(0, -2000px, 0);
		-webkit-transform-origin: center bottom;
		transform-origin: center bottom;
		-webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
		animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
	}
}

@keyframes zoomOutUp {
	40% {
		opacity: 1;
		-webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0);
		transform: scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0);
		-webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
		animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
	}
	100% {
		opacity: 0;
		-webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(0, -2000px, 0);
		transform: scale3d(0.1, 0.1, 0.1) translate3d(0, -2000px, 0);
		-webkit-transform-origin: center bottom;
		transform-origin: center bottom;
		-webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
		animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
	}
}

.zoomOutUp {
	-webkit-animation-name: zoomOutUp;
	animation-name: zoomOutUp;
}

/**
* SlideInDown Keyframes Animation
*/
@-webkit-keyframes slideInDown {
	0% {
		-webkit-transform: translate3d(0, -100%, 0);
		transform: translate3d(0, -100%, 0);
		visibility: visible;
	}
	100% {
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
}

@keyframes slideInDown {
	0% {
		-webkit-transform: translate3d(0, -100%, 0);
		transform: translate3d(0, -100%, 0);
		visibility: visible;
	}
	100% {
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
}

.slideInDown {
	-webkit-animation-name: slideInDown;
	animation-name: slideInDown;
}

/**
* SlideInLeft Keyframes Animation
*/
@-webkit-keyframes slideInLeft {
	0% {
		-webkit-transform: translate3d(-100%, 0, 0);
		transform: translate3d(-100%, 0, 0);
		visibility: visible;
	}
	100% {
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
}

@keyframes slideInLeft {
	0% {
		-webkit-transform: translate3d(-100%, 0, 0);
		transform: translate3d(-100%, 0, 0);
		visibility: visible;
	}
	100% {
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
}

.slideInLeft {
	-webkit-animation-name: slideInLeft;
	animation-name: slideInLeft;
}

/**
* SlideInRight Keyframes Animation
*/
@-webkit-keyframes slideInRight {
	0% {
		-webkit-transform: translate3d(100%, 0, 0);
		transform: translate3d(100%, 0, 0);
		visibility: visible;
	}
	100% {
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
}

@keyframes slideInRight {
	0% {
		-webkit-transform: translate3d(100%, 0, 0);
		transform: translate3d(100%, 0, 0);
		visibility: visible;
	}
	100% {
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
}

.slideInRight {
	-webkit-animation-name: slideInRight;
	animation-name: slideInRight;
}

/**
* SlideInUp Keyframes Animation
*/
@-webkit-keyframes slideInUp {
	0% {
		-webkit-transform: translate3d(0, 100%, 0);
		transform: translate3d(0, 100%, 0);
		visibility: visible;
	}
	100% {
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
}

@keyframes slideInUp {
	0% {
		-webkit-transform: translate3d(0, 100%, 0);
		transform: translate3d(0, 100%, 0);
		visibility: visible;
	}
	100% {
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
}

.slideInUp {
	-webkit-animation-name: slideInUp;
	animation-name: slideInUp;
}

/**
* SlideOutDown Keyframes Animation
*/
@-webkit-keyframes slideOutDown {
	0% {
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
	100% {
		visibility: hidden;
		-webkit-transform: translate3d(0, 100%, 0);
		transform: translate3d(0, 100%, 0);
	}
}

@keyframes slideOutDown {
	0% {
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
	100% {
		visibility: hidden;
		-webkit-transform: translate3d(0, 100%, 0);
		transform: translate3d(0, 100%, 0);
	}
}

.slideOutDown {
	-webkit-animation-name: slideOutDown;
	animation-name: slideOutDown;
}

/**
* SlideOutLeft Keyframes Animation
*/
@-webkit-keyframes slideOutLeft {
	0% {
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
	100% {
		visibility: hidden;
		-webkit-transform: translate3d(-100%, 0, 0);
		transform: translate3d(-100%, 0, 0);
	}
}

@keyframes slideOutLeft {
	0% {
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
	100% {
		visibility: hidden;
		-webkit-transform: translate3d(-100%, 0, 0);
		transform: translate3d(-100%, 0, 0);
	}
}

.slideOutLeft {
	-webkit-animation-name: slideOutLeft;
	animation-name: slideOutLeft;
}

/**
* SlideOutRight Keyframes Animation
*/
@-webkit-keyframes slideOutRight {
	0% {
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
	100% {
		visibility: hidden;
		-webkit-transform: translate3d(100%, 0, 0);
		transform: translate3d(100%, 0, 0);
	}
}

@keyframes slideOutRight {
	0% {
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
	100% {
		visibility: hidden;
		-webkit-transform: translate3d(100%, 0, 0);
		transform: translate3d(100%, 0, 0);
	}
}

.slideOutRight {
	-webkit-animation-name: slideOutRight;
	animation-name: slideOutRight;
}

/**
* SlideOutUp Keyframes Animation
*/
@-webkit-keyframes slideOutUp {
	0% {
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
	100% {
		visibility: hidden;
		-webkit-transform: translate3d(0, -100%, 0);
		transform: translate3d(0, -100%, 0);
	}
}

@keyframes slideOutUp {
	0% {
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
	}
	100% {
		visibility: hidden;
		-webkit-transform: translate3d(0, -100%, 0);
		transform: translate3d(0, -100%, 0);
	}
}

.slideOutUp {
	-webkit-animation-name: slideOutUp;
	animation-name: slideOutUp;
}

.counter {
	font: 900 45px/45px "Roboto", Helvetica, Arial, sans-serif;
	margin-bottom: 0;
	color: #fff;
}

.counter-bold {
	font-weight: 700;
}

.counter-k:after {
	content: 'k';
}

* + .counter-title {
	margin-top: 0;
}

.countdown-default {
	color: #000;
}

.countdown-default .countdown-section {
	position: relative;
	display: inline-block;
	min-width: 90px;
	padding: 0 10px;
	text-align: center;
}

.countdown-default .countdown-section > * {
	display: block;
}

.countdown-default .countdown-section:after {
	position: absolute;
	top: 35%;
	transform: translateY(-35%);
	border-radius: 20px;
	background: #000;
}

.countdown-default .countdown-section:nth-last-child(n + 3):after {
	content: '';
	right: -2px;
	width: 5px;
	height: 5px;
}

@media (max-width: 767px) {
	.countdown-default .countdown-section:last-child {
		display: none;
	}
}

.countdown-default .countdown-amount {
	font-family: Helvetica, Arial, sans-serif;
	font-size: 30px;
	font-weight: 900;
	line-height: 1;
}

.countdown-default .countdown-period {
	margin-top: 10px;
	font-size: 12px;
	text-transform: uppercase;
	letter-spacing: -.025em;
	color: rgba(0, 0, 0, 0.4);
}

.countdown-default.countdown-inverse .countdown-section:after {
	background: #fff;
}

.countdown-default.countdown-inverse .countdown-period {
	color: rgba(255, 255, 255, 0.4);
}

@media (min-width: 768px) {
	.countdown-default .countdown-section {
		min-width: 150px;
	}
	.countdown-default .countdown-section:not(:last-child):after {
		content: '';
		top: 50%;
		right: -5px;
		transform: translateY(-50%);
		width: 10px;
		height: 10px;
	}
	.countdown-default .countdown-amount {
		font-size: 50px;
	}
	.countdown-default .countdown-period {
		font-size: 14px;
	}
}

@media (min-width: 992px) {
	.countdown-default .countdown-section {
		min-width: 200px;
	}
	.countdown-default .countdown-amount {
		font-size: 72px;
	}
}

.countdown-inverse {
	color: #fff;
}

/* 
 *  Owl Carousel - Animate Plugin
 */
.owl-carousel .animated {
	-webkit-animation-duration: 1000ms;
	animation-duration: 1000ms;
	-webkit-animation-fill-mode: both;
	animation-fill-mode: both;
}

.owl-carousel .owl-animated-in {
	z-index: 0;
}

.owl-carousel .owl-animated-out {
	z-index: 1;
}

.owl-carousel .fadeOut {
	-webkit-animation-name: fadeOut;
	animation-name: fadeOut;
}

@-webkit-keyframes fadeOut {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
	}
}

@keyframes fadeOut {
	0% {
		opacity: 1;
	}
	100% {
		opacity: 0;
	}
}

/* 
 * 	Owl Carousel - Auto Height Plugin
 */
.owl-height {
	-webkit-transition: height 500ms ease-in-out;
	-moz-transition: height 500ms ease-in-out;
	-ms-transition: height 500ms ease-in-out;
	-o-transition: height 500ms ease-in-out;
	transition: height 500ms ease-in-out;
}

/* 
 *  Core Owl Carousel CSS File
 */
.owl-carousel {
	display: none;
	width: 100%;
	-webkit-tap-highlight-color: transparent;
	/* position relative and z-index fix webkit rendering fonts issue */
	position: relative;
	z-index: 1;
}

.owl-carousel .owl-stage {
	position: relative;
	-ms-touch-action: pan-Y;
}

.owl-carousel .owl-stage:after {
	content: ".";
	display: block;
	clear: both;
	visibility: hidden;
	line-height: 0;
	height: 0;
}

.owl-carousel .owl-stage-outer {
	position: relative;
	overflow: hidden;
	/* fix for flashing background */
	-webkit-transform: translate3d(0px, 0px, 0px);
}

.owl-carousel .owl-controls .owl-nav .owl-prev,
.owl-carousel .owl-controls .owl-nav .owl-next,
.owl-carousel .owl-controls .owl-dot {
	cursor: pointer;
	cursor: hand;
	-webkit-user-select: none;
	-khtml-user-select: none;
	-moz-user-select: none;
	-ms-user-select: none;
	user-select: none;
}

.owl-carousel.owl-loaded {
	display: block;
}

.owl-carousel.owl-loading {
	opacity: 0;
	display: block;
}

.owl-carousel.owl-hidden {
	opacity: 0;
}

.owl-carousel .owl-refresh .owl-item {
	display: none;
}

.owl-carousel .owl-item {
	position: relative;
	min-height: 1px;
	float: left;
	-webkit-tap-highlight-color: transparent;
	-webkit-touch-callout: none;
	-webkit-user-select: none;
	-moz-user-select: none;
	-ms-user-select: none;
	user-select: none;
}

.owl-carousel.owl-text-select-on .owl-item {
	-webkit-user-select: none;
	-moz-user-select: none;
	-ms-user-select: none;
	user-select: none;
}

.owl-carousel .owl-grab {
	cursor: move;
	cursor: -webkit-grab;
	cursor: grab;
}

.owl-carousel.owl-rtl {
	direction: rtl;
}

.owl-carousel.owl-rtl .owl-item {
	float: right;
}

/* No Js */
.no-js .owl-carousel {
	display: block;
}

/* 
 * 	Owl Carousel - Lazy Load Plugin
 */
.owl-carousel .owl-item .owl-lazy {
	opacity: 0;
	-webkit-transition: opacity 400ms ease;
	-moz-transition: opacity 400ms ease;
	-ms-transition: opacity 400ms ease;
	-o-transition: opacity 400ms ease;
	transition: opacity 400ms ease;
}

/* 
 * 	Owl Carousel - Video Plugin
 */
.owl-carousel .owl-video-wrapper {
	position: relative;
	height: 100%;
	background: #000;
}

.owl-carousel .owl-video-play-icon {
	position: absolute;
	height: 80px;
	width: 80px;
	left: 50%;
	top: 50%;
	margin-left: -40px;
	margin-top: -40px;
	font: 400 40px/80px 'FontAwesome';
	cursor: pointer;
	z-index: 1;
	-webkit-transition: scale 100ms ease;
	-moz-transition: scale 100ms ease;
	-ms-transition: scale 100ms ease;
	-o-transition: scale 100ms ease;
	transition: scale 100ms ease;
}

.owl-carousel .owl-video-play-icon:before {
	content: '\f144';
}

.owl-carousel .owl-video-play-icon:hover {
	-webkit-transform: scale(1.3);
	transform: scale(1.3);
}

.owl-carousel .owl-video-playing .owl-video-tn,
.owl-carousel .owl-video-playing .owl-video-play-icon {
	display: none;
}

.owl-carousel .owl-video-tn {
	opacity: 0;
	height: 100%;
	background-position: center center;
	background-repeat: no-repeat;
	-webkit-background-size: contain;
	-moz-background-size: contain;
	-o-background-size: contain;
	background-size: contain;
	-webkit-transition: opacity 400ms ease;
	-moz-transition: opacity 400ms ease;
	-ms-transition: opacity 400ms ease;
	-o-transition: opacity 400ms ease;
	transition: opacity 400ms ease;
}

.owl-carousel .owl-video-frame {
	position: relative;
	z-index: 1;
}

.owl-carousel .owl-stage {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: stretch;
	-ms-flex-align: stretch;
	align-items: stretch;
}

.owl-carousel .owl-item {
	float: none;
	display: -webkit-inline-box;
	display: -webkit-inline-flex;
	display: -ms-inline-flexbox;
	display: inline-flex;
	-webkit-flex-grow: 1;
	-ms-flex-positive: 1;
	flex-grow: 1;
	-webkit-flex-shrink: 0;
	-ms-flex-negative: 0;
	flex-shrink: 0;
	-webkit-align-items: stretch;
	-ms-flex-align: stretch;
	align-items: stretch;
}

.owl-carousel .item {
	width: 100%;
}

.owl-carousel-center .owl-item {
	-webkit-justify-content: center;
	-ms-flex-pack: center;
	justify-content: center;
}

.owl-carousel-center .owl-stage {
	-webkit-justify-content: space-around;
	-ms-flex-pack: distribute;
	justify-content: space-around;
}

/*
 * Owl Navigation
 */
.owl-prev,
.owl-next {
	position: absolute;
	top: 50%;
	transform: translateY(-50%);
	color: #000;
	transition: .22s;
}

.owl-prev.disabled, .owl-next.disabled {
    opacity: 0;
}

.owl-prev:hover,
.owl-next:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.owl-prev {
	left: 0;
}

.owl-prev:before {
	content: '\e5c4';
}

.owl-next {
	right: 0;
}

.owl-next:before {
	content: '\e5c8';
}

/*
 * Owl Pagination
 */
.owl-dots {
	text-align: center;
}

.owl-dot {
	display: inline-block;
}

/*
 * Owl Pagination
 */
.owl-numbering-default {
	padding-bottom: 15px;
}

.owl-numbering-default > * {
	display: inline-block;
}

.owl-numbering-default .numbering-current {
	min-width: 16px;
	font: 700 25px "Roboto", Helvetica, Arial, sans-serif;
	color: #000;
	transition: .33s all ease;
}

.owl-numbering-default .numbering-separator {
	position: relative;
	display: inline-block;
	margin: 0 10px;
}

.owl-numbering-default .numbering-separator:after {
	position: absolute;
	top: -23px;
	left: -12px;
	content: '';
	width: 2px;
	height: 51px;
	transform-origin: 50% 75%;
	transform: rotate(30deg);
	background: rgba(0, 0, 0, 0.3);
}

.owl-numbering-default .numbering-count {
	position: relative;
	top: 19px;
	left: -7px;
	font: 400 18px "Roboto", Helvetica, Arial, sans-serif;
	color: rgba(0, 0, 0, 0.3);
}

.owl-carousel-inverse .owl-next,
.owl-carousel-inverse .owl-prev {
	color: #fff;
}

.owl-carousel-inverse .owl-next:hover,
.owl-carousel-inverse .owl-prev:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.owl-carousel-inverse .owl-numbering-default .numbering-current {
	color: #fff;
}

.owl-carousel-inverse .owl-numbering-default .numbering-separator:after {
	background: rgba(255, 255, 255, 0.3);
}

.owl-carousel-inverse .owl-numbering-default .numbering-count {
	color: rgba(255, 255, 255, 0.3);
}

.owl-carousel-dark .owl-next,
.owl-carousel-dark .owl-prev {
	color: #000;
}

.owl-carousel-dark .owl-next:hover,
.owl-carousel-dark .owl-prev:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.owl-nav-position-numbering .owl-next,
.owl-nav-position-numbering .owl-prev {
	top: auto;
	bottom: -53px;
	transform: none;
}

.owl-nav-position-numbering .owl-prev {
	left: auto;
	right: calc(50% + 42px);
}

.owl-nav-position-numbering .owl-next {
	right: auto;
	left: calc(50% + 42px);
}

.owl-nav-position-numbering + .owl-numbering {
	margin-top: 15px;
}

.owl-nav-bottom-left .owl-nav {
	margin-top: 15px;
}

.owl-nav-bottom-left .owl-next,
.owl-nav-bottom-left .owl-prev {
	display: inline-block;
	position: static;
	top: auto;
	transform: none;
}

.owl-nav-bottom-left .owl-prev {
	left: auto;
}

.owl-nav-bottom-left .owl-next {
	right: auto;
	margin-left: 10px;
}

.owl-style-minimal .item {
	width: 100%;
}

.owl-style-minimal .item img {
	width: 100%;
}

.owl-style-minimal .owl-dots {
	margin-top: 10px;
	text-align: center;
}

.owl-style-minimal .owl-dot {
	width: 8px;
	height: 8px;
	border-radius: 10px;
	background: #dedede;
	transition: .33s all ease;
}

.owl-style-minimal .owl-dot.active,
.owl-style-minimal .owl-dot:hover {
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.owl-style-minimal .owl-dot + .owl-dot {
	margin-left: 8px;
}

.owl-style-minimal-inverse .owl-dot {
	background: #74787C;
}

@media (min-width: 992px) {
	.owl-spacing-1 {
		padding-right: 60px;
		padding-left: 60px;
	}
}

@media (min-width: 1200px) {
	.owl-spacing-1 {
		padding: 0;
	}
	.owl-spacing-1 .owl-item {
		padding-right: 41px;
		padding-left: 41px;
	}
	.owl-spacing-1 .owl-prev {
		left: -6%;
	}
	.owl-spacing-1 .owl-next {
		right: -6%;
	}
}

.owl-nav-classic .owl-nav {
	display: none;
}

@media (min-width: 992px) {
	.owl-nav-classic .owl-dots {
		display: none !important;
	}
	.owl-nav-classic .owl-nav {
		display: block;
	}
	.owl-nav-classic .owl-nav .owl-prev,
	.owl-nav-classic .owl-nav .owl-next {
		top: 39%;
		transform: translateY(-45%);
		width: 45px;
		height: 45px;
		line-height: 45px;
		color: #fff;
		background: rgba(255, 255, 255, 0.2);
		text-align: center;
		font: 400 20px/45px 'fl-flat-icons-set-2';
	}
	.owl-nav-classic .owl-nav .owl-prev:hover,
	.owl-nav-classic .owl-nav .owl-next:hover {
		color: #fff;
		background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	}
	.owl-nav-classic .owl-nav .owl-prev {
		padding-right: 3px;
	}
	.owl-nav-classic .owl-nav .owl-prev:before {
		position: relative;
		display: inline-block;
		content: '\e015';
		transform: scale(-1, 1);
	}
	.owl-nav-classic .owl-nav .owl-next {
		padding-left: 3px;
	}
	.owl-nav-classic .owl-nav .owl-next:before {
		content: '\e015';
	}
}

.owl-nav-modern .owl-nav {
	display: none;
}

@media (min-width: 1400px) {
	.owl-nav-modern .owl-dots {
		display: none !important;
	}
	.owl-nav-modern .owl-nav {
		display: block;
	}
	.owl-nav-modern .owl-nav .owl-prev,
	.owl-nav-modern .owl-nav .owl-next {
		top: 50%;
		width: 48px;
		height: 48px;
		background: url("medias/image/<?php echo $website->ref; ?>/chevron-left.svg") no-repeat top left;
		background-size: 48px 48px;
		transition: 180ms ease-in-out;
	}
	.owl-nav-modern .owl-nav .owl-prev:before,
	.owl-nav-modern .owl-nav .owl-next:before {
		content: '';
	}
	.owl-nav-modern .owl-nav .owl-prev:hover,
	.owl-nav-modern .owl-nav .owl-next:hover {
		opacity: 0.5;
	}
	.owl-nav-modern .owl-nav .owl-prev {
		left: -58px;
	}
	.owl-nav-modern .owl-nav .owl-next {
		right: -50px;
	}
	.owl-nav-modern .owl-nav .owl-next {
		-webkit-transform: rotate(180deg);
		transform: rotate(180deg);
	}
}

/*
* @subsection   RD Navbar
*
* @description  Describes style declarations for RD Navbar extension
*
* @author       Evgeniy Gusarov
* @link         https://ua.linkedin.com/pub/evgeniy-gusarov/8a/a40/54a
*/
@-webkit-keyframes rd-navbar-slide-down {
	0% {
		transform: translateY(-100%);
	}
	100% {
		transform: translateY(0);
	}
}

@keyframes rd-navbar-slide-down {
	0% {
		transform: translateY(-100%);
	}
	100% {
		transform: translateY(0);
	}
}

@-webkit-keyframes rd-navbar-slide-up {
	0% {
		transform: translateY(0);
	}
	100% {
		transform: translateY(-100%);
	}
}

@keyframes rd-navbar-slide-up {
	0% {
		transform: translateY(0);
	}
	100% {
		transform: translateY(-100%);
	}
}

/*
* @subsection General Styles
*/
.rd-navbar-wrap, .rd-navbar-static .rd-navbar-megamenu,
.rd-navbar-fullwidth .rd-navbar-megamenu, .rd-navbar-static .rd-navbar-inner, .rd-navbar-fixed .rd-navbar-nav-wrap, .rd-navbar-fixed .rd-navbar-submenu, .rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-group, .rd-navbar-corporate-light .rd-navbar-search .rd-navbar-search-toggle, .rd-navbar-corporate-light .rd-navbar-search .rd-navbar-search-toggle:before, .rd-navbar-corporate-light .rd-navbar-search .rd-navbar-search-toggle:after, .rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-search .rd-search, .rd-navbar-corporate-light.rd-navbar-static .rd-navbar-group, .rd-navbar-corporate-light.rd-navbar-static .rd-search {
	transition: 0.3s all cubic-bezier(0.785, 0.135, 0.15, 0.86);
}

.rd-navbar, .rd-navbar.rd-navbar--is-clone {
	display: none;
}

.rd-navbar-fixed,
.rd-navbar-static,
.rd-navbar-fullwidth,
.rd-navbar-sidebar {
	display: block;
}

.rd-navbar--no-transition, .rd-navbar--no-transition * {
	transition: none !important;
}

.rd-navbar-wrap {
	position: relative;
	z-index: 10;
}

.rd-navbar-wrap,
.rd-navbar,
.rd-navbar-brand,
.rd-navbar-slogan,
.rd-navbar-dropdown,
.rd-navbar-megamenu,
.rd-navbar-collapse-items,
.brand-name,
.rd-navbar-nav,
.rd-navbar-panel,
.rd-navbar-search-form-input,
.rd-navbar-search-form-submit,
.rd-navbar-search-toggle,
.rd-navbar-live-search-results,
.rd-navbar-search-form {
	transition: .33s all ease-out;
}

.rd-navbar-collapse-toggle {
	display: inline-block;
	position: relative;
	width: 48px;
	height: 48px;
	line-height: 48px;
	cursor: pointer;
	color: #00030a;
	display: none;
}

.rd-navbar-collapse-toggle span {
	top: 50%;
	margin-top: -3px;
}

.rd-navbar-collapse-toggle span, .rd-navbar-collapse-toggle span:before, .rd-navbar-collapse-toggle span:after {
	position: absolute;
	width: 6px;
	height: 6px;
	line-height: 6px;
	text-align: center;
	background: #00030a;
	left: 50%;
	margin-left: -3px;
	border-radius: 50%;
	transition: .3s all ease;
}

.rd-navbar-collapse-toggle span:before, .rd-navbar-collapse-toggle span:after {
	content: '';
}

.rd-navbar-collapse-toggle span:before {
	bottom: 100%;
	margin-bottom: 3px;
}

.rd-navbar-collapse-toggle span:after {
	top: 100%;
	margin-top: 3px;
}

.rd-navbar-collapse-toggle.active span {
	transform: scale(0.7);
}

.rd-navbar-collapse-toggle.active span:before {
	transform: translateY(18px);
}

.rd-navbar-collapse-toggle.active span:after {
	transform: translateY(-18px);
}

.rd-navbar--has-sidebar body {
	padding-left: 270px;
}

.rd-navbar--is-stuck {
	border-bottom: 1px solid #e5e7e9;
}

.rd-navbar.rd-navbar-fixed + .rd-navbar.rd-navbar--is-clone,
.rd-navbar.rd-navbar-sidebar + .rd-navbar.rd-navbar--is-clone {
	display: none;
}

/*
* Navbar components
*/
.rd-navbar {
	display: none;
	background: #fff;
	box-shadow: none;
}

.rd-navbar-toggle {
	display: inline-block;
	position: relative;
	width: 48px;
	height: 48px;
	line-height: 48px;
	cursor: pointer;
	color: #000;
	background-color: transparent;
	border: none;
	display: none;
}

.rd-navbar-toggle span {
	position: relative;
	display: block;
	margin: auto;
	transition: .3s all ease;
}

.rd-navbar-toggle span:after, .rd-navbar-toggle span:before {
	content: "";
	position: absolute;
	left: 0;
	top: -8px;
	transition: .3s all ease;
}

.rd-navbar-toggle span:after {
	top: 8px;
}

.rd-navbar-toggle span:after, .rd-navbar-toggle span:before, .rd-navbar-toggle span {
	width: 24px;
	height: 4px;
	background-color: #000;
	backface-visibility: hidden;
	border-radius: 2px;
}

.rd-navbar-toggle span {
	transform: rotate(180deg);
}

.rd-navbar-toggle span:before, .rd-navbar-toggle span:after {
	transform-origin: 1.71429px center;
	transform-origin: 1.71429px center;
}

.rd-navbar-toggle.active span {
	transform: rotate(360deg);
}

.rd-navbar-toggle.active span:before, .rd-navbar-toggle.active span:after {
	top: 0;
	width: 15px;
}

.rd-navbar-toggle.active span:before {
	-webkit-transform: rotate3d(0, 0, 1, -40deg);
	transform: rotate3d(0, 0, 1, -40deg);
}

.rd-navbar-toggle.active span:after {
	-webkit-transform: rotate3d(0, 0, 1, 40deg);
	transform: rotate3d(0, 0, 1, 40deg);
}

.rd-navbar-toggle:focus {
	outline: none;
}

.rd-navbar-brand {
	transition: none !important;
}

.rd-navbar-brand svg {
	fill: #000;
}

.rd-navbar-search .rd-navbar-search-toggle,
.rd-navbar-search .rd-search-submit,
.buttonwithnoborder {
	background: none;
	border: none;
	display: inline-block;
	padding: 0;
	outline: none;
	outline-offset: 0;
	cursor: pointer;
	-webkit-appearance: none;
}

.rd-navbar-search .rd-navbar-search-toggle::-moz-focus-inner,
.rd-navbar-search .rd-search-submit::-moz-focus-inner {
	border: none;
	padding: 0;
}

.rd-navbar-search .form-input::-ms-clear {
	display: none;
}

.rd-navbar-search-toggle {
	display: inline-block;
	width: 36px;
	height: 36px;
	text-align: center;
	font: 400 18px/36px "FontAwesome";
}

.rd-navbar-search-toggle:before {
	content: '\f002';
	position: absolute;
	left: 0;
	top: 0;
}

.rd-navbar-search-toggle:after {
	display: none;
}

.rd-navbar-aside {
	pointer-events: none;
}

.rd-navbar-aside > * {
	pointer-events: auto;
}

.rd-navbar-aside-toggle {
	display: none;
	pointer-events: auto;
}

/*
* @subsection   Hybrid  Styles
*/
.rd-navbar-static .rd-navbar-search-form-input input,
.rd-navbar-sidebar .rd-navbar-search-form-input input,
.rd-navbar-fullwidth .rd-navbar-search-form-input input {
	width: 100%;
	padding: 0 10px;
	font-size: 16px;
}

.rd-navbar-static:after,
.rd-navbar-fullwidth:after {
	content: '';
	background: #fff;
}

.rd-navbar-static .rd-navbar-brand,
.rd-navbar-static .rd-navbar-nav > li > a,
.rd-navbar-static .rd-navbar-search-toggle,
.rd-navbar-fullwidth .rd-navbar-brand,
.rd-navbar-fullwidth .rd-navbar-nav > li > a,
.rd-navbar-fullwidth .rd-navbar-search-toggle {
	position: relative;
	z-index: 2;
}

.rd-navbar-static .rd-navbar-inner,
.rd-navbar-fullwidth .rd-navbar-inner {
	position: relative;
	max-width: 1200px;
	padding-left: 15px;
	padding-right: 15px;
	margin-left: auto;
	margin-right: auto;
}

.rd-navbar-static .rd-navbar-nav > li > a,
.rd-navbar-fullwidth .rd-navbar-nav > li > a {
	position: relative;
	padding: 5px 0;
	font-size: 13px;
	line-height: 1.2;
	color: #00030a;
	background: transparent;
}

.rd-navbar-static .rd-navbar-nav > li > a .label,
.rd-navbar-fullwidth .rd-navbar-nav > li > a .label {
	position: absolute;
	left: 0;
	margin: -18px 0 0 0;
}

@media (min-width: 1200px) {
	.rd-navbar-static .rd-navbar-nav > li > a,
	.rd-navbar-fullwidth .rd-navbar-nav > li > a {
		font-size: 14px;
	}
}

.rd-navbar-static .rd-navbar-nav > li.active > a,
.rd-navbar-fullwidth .rd-navbar-nav > li.active > a {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	background: transparent;
}

.rd-navbar-static .rd-navbar-nav > li.focus > a,
.rd-navbar-static .rd-navbar-nav > li > a:hover,
.rd-navbar-fullwidth .rd-navbar-nav > li.focus > a,
.rd-navbar-fullwidth .rd-navbar-nav > li > a:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	background: transparent;
}

.rd-navbar-static .rd-navbar-nav .rd-navbar-submenu > .rd-navbar-dropdown,
.rd-navbar-static .rd-navbar-nav .rd-navbar-submenu > .rd-navbar-megamenu,
.rd-navbar-fullwidth .rd-navbar-nav .rd-navbar-submenu > .rd-navbar-dropdown,
.rd-navbar-fullwidth .rd-navbar-nav .rd-navbar-submenu > .rd-navbar-megamenu {
	opacity: 0;
	visibility: hidden;
	font-size: 14px;
}

.rd-navbar-static .rd-navbar-nav .rd-navbar-submenu.focus,
.rd-navbar-fullwidth .rd-navbar-nav .rd-navbar-submenu.focus {
	opacity: 1;
	visibility: visible;
}

.rd-navbar-static .rd-navbar-nav > .rd-navbar-submenu > .rd-navbar-dropdown,
.rd-navbar-static .rd-navbar-nav > .rd-navbar-submenu > .rd-navbar-megamenu,
.rd-navbar-fullwidth .rd-navbar-nav > .rd-navbar-submenu > .rd-navbar-dropdown,
.rd-navbar-fullwidth .rd-navbar-nav > .rd-navbar-submenu > .rd-navbar-megamenu {
	transform: translateY(30px);
}

.rd-navbar-static .rd-navbar-nav > .rd-navbar-submenu.opened > .rd-navbar-dropdown,
.rd-navbar-static .rd-navbar-nav > .rd-navbar-submenu.opened > .rd-navbar-megamenu, .rd-navbar-static .rd-navbar-nav > .rd-navbar-submenu.focus > .rd-navbar-dropdown,
.rd-navbar-static .rd-navbar-nav > .rd-navbar-submenu.focus > .rd-navbar-megamenu,
.rd-navbar-fullwidth .rd-navbar-nav > .rd-navbar-submenu.opened > .rd-navbar-dropdown,
.rd-navbar-fullwidth .rd-navbar-nav > .rd-navbar-submenu.opened > .rd-navbar-megamenu,
.rd-navbar-fullwidth .rd-navbar-nav > .rd-navbar-submenu.focus > .rd-navbar-dropdown,
.rd-navbar-fullwidth .rd-navbar-nav > .rd-navbar-submenu.focus > .rd-navbar-megamenu {
	transform: translateY(0);
}

.rd-navbar-static .rd-navbar-nav > .rd-navbar-submenu .rd-navbar-submenu > .rd-navbar-dropdown,
.rd-navbar-fullwidth .rd-navbar-nav > .rd-navbar-submenu .rd-navbar-submenu > .rd-navbar-dropdown {
	transform: translateX(-20px);
}

.rd-navbar-static .rd-navbar-nav > .rd-navbar-submenu .rd-navbar-submenu.focus > .rd-navbar-dropdown, .rd-navbar-static .rd-navbar-nav > .rd-navbar-submenu .rd-navbar-submenu.opened > .rd-navbar-dropdown,
.rd-navbar-fullwidth .rd-navbar-nav > .rd-navbar-submenu .rd-navbar-submenu.focus > .rd-navbar-dropdown,
.rd-navbar-fullwidth .rd-navbar-nav > .rd-navbar-submenu .rd-navbar-submenu.opened > .rd-navbar-dropdown {
	transform: translateX(0);
}

.rd-navbar-static .rd-navbar-nav > .rd-navbar-submenu .rd-navbar-submenu.focus > .rd-navbar-dropdown, .rd-navbar-static .rd-navbar-nav > .rd-navbar-submenu .rd-navbar-submenu.opened > .rd-navbar-dropdown,
.rd-navbar-fullwidth .rd-navbar-nav > .rd-navbar-submenu .rd-navbar-submenu.focus > .rd-navbar-dropdown,
.rd-navbar-fullwidth .rd-navbar-nav > .rd-navbar-submenu .rd-navbar-submenu.opened > .rd-navbar-dropdown {
	display: block;
}

.rd-navbar-static .rd-navbar-nav > li,
.rd-navbar-fullwidth .rd-navbar-nav > li {
	display: inline-block;
}

.rd-navbar-static .rd-navbar-nav li.rd-navbar--has-dropdown,
.rd-navbar-fullwidth .rd-navbar-nav li.rd-navbar--has-dropdown {
	position: relative;
}

.rd-navbar-static .rd-navbar-nav li.focus > .rd-navbar-dropdown,
.rd-navbar-static .rd-navbar-nav li.focus > .rd-navbar-megamenu,
.rd-navbar-static .rd-navbar-nav li.opened > .rd-navbar-dropdown,
.rd-navbar-static .rd-navbar-nav li.opened > .rd-navbar-megamenu,
.rd-navbar-fullwidth .rd-navbar-nav li.focus > .rd-navbar-dropdown,
.rd-navbar-fullwidth .rd-navbar-nav li.focus > .rd-navbar-megamenu,
.rd-navbar-fullwidth .rd-navbar-nav li.opened > .rd-navbar-dropdown,
.rd-navbar-fullwidth .rd-navbar-nav li.opened > .rd-navbar-megamenu {
	opacity: 1;
	visibility: visible;
	transform: translateY(0);
}

.rd-navbar-static .rd-navbar-nav > li > .rd-navbar-dropdown,
.rd-navbar-fullwidth .rd-navbar-nav > li > .rd-navbar-dropdown {
	position: absolute;
	left: 0;
	z-index: 5;
	display: block;
	margin-top: 27px;
	text-align: left;
	background: #fff;
}

.rd-navbar-static .rd-navbar-list li,
.rd-navbar-fullwidth .rd-navbar-list li {
	padding-left: 5px;
	padding-right: 5px;
}

.rd-navbar-static .rd-navbar-dropdown > li > a,
.rd-navbar-static .rd-navbar-list > li > a,
.rd-navbar-fullwidth .rd-navbar-dropdown > li > a,
.rd-navbar-fullwidth .rd-navbar-list > li > a {
	position: relative;
	display: block;
	width: 100%;
	padding-left: 0;
	padding-right: 14px;
	font-size: 14px;
	line-height: 1.3;
}

.rd-navbar-static .rd-navbar-dropdown > li > a, .rd-navbar-static .rd-navbar-dropdown > li > a:before,
.rd-navbar-static .rd-navbar-list > li > a,
.rd-navbar-static .rd-navbar-list > li > a:before,
.rd-navbar-fullwidth .rd-navbar-dropdown > li > a,
.rd-navbar-fullwidth .rd-navbar-dropdown > li > a:before,
.rd-navbar-fullwidth .rd-navbar-list > li > a,
.rd-navbar-fullwidth .rd-navbar-list > li > a:before {
	transition: .33s all ease;
}

.rd-navbar-static .rd-navbar-dropdown > li > a:before,
.rd-navbar-static .rd-navbar-list > li > a:before,
.rd-navbar-fullwidth .rd-navbar-dropdown > li > a:before,
.rd-navbar-fullwidth .rd-navbar-list > li > a:before {
	position: absolute;
	top: 0;
	left: -6px;
	content: '\f105';
	font-family: 'FontAwesome';
	font-size: 16px;
	line-height: inherit;
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	opacity: 0;
	visibility: hidden;
}

.rd-navbar-static .rd-navbar-dropdown > li > a:hover,
.rd-navbar-static .rd-navbar-list > li > a:hover,
.rd-navbar-fullwidth .rd-navbar-dropdown > li > a:hover,
.rd-navbar-fullwidth .rd-navbar-list > li > a:hover {
	padding-left: 14px;
	padding-right: 0;
}

.rd-navbar-static .rd-navbar-dropdown > li > a:hover:before,
.rd-navbar-static .rd-navbar-list > li > a:hover:before,
.rd-navbar-fullwidth .rd-navbar-dropdown > li > a:hover:before,
.rd-navbar-fullwidth .rd-navbar-list > li > a:hover:before {
	left: 0;
	opacity: 1;
	visibility: visible;
}

.rd-navbar-static .rd-navbar-dropdown > li > a, .rd-navbar-static .rd-navbar-dropdown > li > a:focus, .rd-navbar-static .rd-navbar-dropdown > li > a:active,
.rd-navbar-static .rd-navbar-list > li > a,
.rd-navbar-static .rd-navbar-list > li > a:focus,
.rd-navbar-static .rd-navbar-list > li > a:active,
.rd-navbar-fullwidth .rd-navbar-dropdown > li > a,
.rd-navbar-fullwidth .rd-navbar-dropdown > li > a:focus,
.rd-navbar-fullwidth .rd-navbar-dropdown > li > a:active,
.rd-navbar-fullwidth .rd-navbar-list > li > a,
.rd-navbar-fullwidth .rd-navbar-list > li > a:focus,
.rd-navbar-fullwidth .rd-navbar-list > li > a:active {
	color: #9f9f9f;
	background: transparent;
}

.rd-navbar-static .rd-navbar-dropdown > li > a:hover,
.rd-navbar-static .rd-navbar-list > li > a:hover,
.rd-navbar-fullwidth .rd-navbar-dropdown > li > a:hover,
.rd-navbar-fullwidth .rd-navbar-list > li > a:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	background: transparent;
}

.rd-navbar-static .rd-navbar-dropdown > li + li,
.rd-navbar-static .rd-navbar-list > li + li,
.rd-navbar-fullwidth .rd-navbar-dropdown > li + li,
.rd-navbar-fullwidth .rd-navbar-list > li + li {
	margin-top: 14px;
}

@media (min-width: 1200px) {
	.rd-navbar-static .rd-navbar-dropdown > li > a,
	.rd-navbar-static .rd-navbar-list > li > a,
	.rd-navbar-fullwidth .rd-navbar-dropdown > li > a,
	.rd-navbar-fullwidth .rd-navbar-list > li > a {
		font-size: 16px;
	}
}

@media (min-width: 1800px) {
	.rd-navbar-static .rd-navbar-dropdown > li + li,
	.rd-navbar-static .rd-navbar-list > li + li,
	.rd-navbar-fullwidth .rd-navbar-dropdown > li + li,
	.rd-navbar-fullwidth .rd-navbar-list > li + li {
		margin-top: 17px;
	}
}

.rd-navbar-static .rd-navbar-dropdown,
.rd-navbar-static .rd-navbar-megamenu,
.rd-navbar-fullwidth .rd-navbar-dropdown,
.rd-navbar-fullwidth .rd-navbar-megamenu {
	box-shadow: 0 0 13px 0 rgba(0, 0, 0, 0.13);
	border-top: 2px solid <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.rd-navbar-static .rd-navbar-dropdown,
.rd-navbar-fullwidth .rd-navbar-dropdown {
	width: 188px;
	padding: 25px 25px 30px;
	margin-left: -32px;
	background: #fff;
}

@media (min-width: 1200px) {
	.rd-navbar-static .rd-navbar-dropdown,
	.rd-navbar-fullwidth .rd-navbar-dropdown {
		width: 235px;
	}
}

.rd-navbar-static .rd-navbar-dropdown .rd-navbar-dropdown,
.rd-navbar-fullwidth .rd-navbar-dropdown .rd-navbar-dropdown {
	position: absolute;
	left: 100%;
	margin-left: 91px;
	top: -20px;
}

.rd-navbar-static .rd-navbar-dropdown > li > a,
.rd-navbar-fullwidth .rd-navbar-dropdown > li > a {
	display: block;
	width: 100%;
}

.rd-navbar-static .rd-navbar-dropdown > li > a, .rd-navbar-static .rd-navbar-dropdown > li > a:focus, .rd-navbar-static .rd-navbar-dropdown > li > a:active,
.rd-navbar-fullwidth .rd-navbar-dropdown > li > a,
.rd-navbar-fullwidth .rd-navbar-dropdown > li > a:focus,
.rd-navbar-fullwidth .rd-navbar-dropdown > li > a:active {
	color: #9f9f9f;
	background: transparent;
}

.rd-navbar-static .rd-navbar-dropdown > li > a:hover,
.rd-navbar-fullwidth .rd-navbar-dropdown > li > a:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	background: transparent;
}

.rd-navbar-static .rd-navbar-dropdown > li.focus > a,
.rd-navbar-static .rd-navbar-dropdown > li.opened > a,
.rd-navbar-fullwidth .rd-navbar-dropdown > li.focus > a,
.rd-navbar-fullwidth .rd-navbar-dropdown > li.opened > a {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	background: transparent;
}

.rd-navbar-static .rd-navbar-megamenu,
.rd-navbar-fullwidth .rd-navbar-megamenu {
	position: absolute;
	z-index: 4;
	display: table;
	table-layout: fixed;
	width: calc(100% - 30px);
	left: 15px;
	max-width: 1200px;
	margin-top: 27px;
	text-align: left;
	background: #fff;
}

.rd-navbar-static .rd-navbar-megamenu > li,
.rd-navbar-fullwidth .rd-navbar-megamenu > li {
	position: relative;
	display: table-cell;
	padding: 34px 20px 30px 35px;
}

.rd-navbar-static .rd-navbar-megamenu > li + li,
.rd-navbar-fullwidth .rd-navbar-megamenu > li + li {
	border-left: 1px solid #ededed;
}

.rd-navbar-static .rd-navbar-megamenu * + .rd-megamenu-header,
.rd-navbar-fullwidth .rd-navbar-megamenu * + .rd-megamenu-header {
	margin-top: 40px;
}

.rd-navbar-static .rd-navbar-megamenu * + .rd-navbar-list,
.rd-navbar-fullwidth .rd-navbar-megamenu * + .rd-navbar-list {
	margin-top: 20px;
}

@media (min-width: 1200px) {
	.rd-navbar-static .rd-navbar-megamenu,
	.rd-navbar-fullwidth .rd-navbar-megamenu {
		width: 1140px;
	}
	.rd-navbar-static .rd-navbar-megamenu > li,
	.rd-navbar-fullwidth .rd-navbar-megamenu > li {
		padding: 44px 25px 50px 45px;
	}
}

.rd-navbar-static .rd-navbar-submenu-toggle,
.rd-navbar-fullwidth .rd-navbar-submenu-toggle {
	display: none;
	cursor: pointer;
	z-index: 100;
}

.rd-navbar-static .rd-navbar-submenu-toggle:hover,
.rd-navbar-fullwidth .rd-navbar-submenu-toggle:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.rd-navbar-static .rd-navbar-nav > li > .rd-navbar-submenu-toggle,
.rd-navbar-fullwidth .rd-navbar-nav > li > .rd-navbar-submenu-toggle {
	display: none;
	-webkit-align-self: center;
	-ms-flex-item-align: center;
	align-self: center;
	width: 24px;
	text-align: center;
}

.rd-navbar-static .rd-navbar-nav > li > .rd-navbar-submenu-toggle::after,
.rd-navbar-fullwidth .rd-navbar-nav > li > .rd-navbar-submenu-toggle::after {
	content: '\f107';
	position: relative;
	display: inline-block;
	font: 400 16px "FontAwesome";
	text-align: center;
	transition: 0.4s all ease;
	z-index: 2;
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	will-change: transform;
	-webkit-filter: blur(0);
}

.rd-navbar-static .rd-navbar-nav > li li.focus > .rd-navbar-submenu-toggle::after,
.rd-navbar-static .rd-navbar-nav > li li.opened > .rd-navbar-submenu-toggle::after,
.rd-navbar-static .rd-navbar-nav > li li > a:hover + .rd-navbar-submenu-toggle::after,
.rd-navbar-fullwidth .rd-navbar-nav > li li.focus > .rd-navbar-submenu-toggle::after,
.rd-navbar-fullwidth .rd-navbar-nav > li li.opened > .rd-navbar-submenu-toggle::after,
.rd-navbar-fullwidth .rd-navbar-nav > li li > a:hover + .rd-navbar-submenu-toggle::after {
	-webkit-transform: rotate(-90deg);
	transform: rotate(-90deg);
}

.rd-navbar-static .rd-navbar-nav > li.focus > .rd-navbar-submenu-toggle::after,
.rd-navbar-static .rd-navbar-nav > li.opened > .rd-navbar-submenu-toggle::after,
.rd-navbar-static .rd-navbar-nav > li > a:hover + .rd-navbar-submenu-toggle::after,
.rd-navbar-fullwidth .rd-navbar-nav > li.focus > .rd-navbar-submenu-toggle::after,
.rd-navbar-fullwidth .rd-navbar-nav > li.opened > .rd-navbar-submenu-toggle::after,
.rd-navbar-fullwidth .rd-navbar-nav > li > a:hover + .rd-navbar-submenu-toggle::after {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.rd-navbar-static .rd-navbar-dropdown .rd-navbar-submenu-toggle,
.rd-navbar-fullwidth .rd-navbar-dropdown .rd-navbar-submenu-toggle {
	display: none;
	vertical-align: middle;
}

.rd-navbar-static .rd-navbar-dropdown .rd-navbar-submenu-toggle::after,
.rd-navbar-fullwidth .rd-navbar-dropdown .rd-navbar-submenu-toggle::after {
	top: 1px;
}

.rd-navbar-static .rd-navbar-dropdown > li.focus > .rd-navbar-submenu-toggle::after,
.rd-navbar-static .rd-navbar-dropdown > li.opened > .rd-navbar-submenu-toggle::after,
.rd-navbar-static .rd-navbar-dropdown > li > a:hover + .rd-navbar-submenu-toggle::after,
.rd-navbar-fullwidth .rd-navbar-dropdown > li.focus > .rd-navbar-submenu-toggle::after,
.rd-navbar-fullwidth .rd-navbar-dropdown > li.opened > .rd-navbar-submenu-toggle::after,
.rd-navbar-fullwidth .rd-navbar-dropdown > li > a:hover + .rd-navbar-submenu-toggle::after {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.rd-navbar-static.rd-navbar--is-clone,
.rd-navbar-fullwidth.rd-navbar--is-clone {
	display: none;
}

.rd-navbar-static.rd-navbar--is-clone.rd-navbar--is-stuck,
.rd-navbar-fullwidth.rd-navbar--is-clone.rd-navbar--is-stuck {
	display: block;
}

.rd-navbar-static.rd-navbar--is-stuck, .rd-navbar-static.rd-navbar--is-clone,
.rd-navbar-fullwidth.rd-navbar--is-stuck,
.rd-navbar-fullwidth.rd-navbar--is-clone {
	position: fixed;
	left: 0;
	top: 0;
	right: 0;
	z-index: 999;
	background: #fff;
}

.rd-navbar-static.rd-navbar--is-stuck .rd-navbar-megamenu, .rd-navbar-static.rd-navbar--is-clone .rd-navbar-megamenu,
.rd-navbar-fullwidth.rd-navbar--is-stuck .rd-navbar-megamenu,
.rd-navbar-fullwidth.rd-navbar--is-clone .rd-navbar-megamenu {
	margin-top: 18px;
}

.rd-navbar-static .rd-navbar-megamenu,
.rd-navbar-fullwidth .rd-navbar-megamenu {
	position: absolute;
	transform: translateY(30px);
	text-align: left;
	visibility: hidden;
	opacity: 0;
}

.rd-navbar-static .rd-navbar--has-dropdown,
.rd-navbar-fullwidth .rd-navbar--has-dropdown {
	position: relative;
}

.rd-navbar-fixed .rd-navbar-collapse-toggle,
.rd-navbar-sidebar .rd-navbar-collapse-toggle {
	display: inline-block;
	z-index: 9999;
}

.rd-navbar-fixed .rd-navbar-dropdown,
.rd-navbar-sidebar .rd-navbar-dropdown {
	display: block;
}

.rd-navbar-fixed .rd-navbar-collapse-items,
.rd-navbar-sidebar .rd-navbar-collapse-items {
	position: absolute;
	width: 260px;
	padding: 25px 15px;
	box-shadow: none;
	color: #00030a;
	background: #fff;
	font-size: 16px;
	line-height: 34px;
}

.rd-navbar-fixed .rd-navbar-collapse-items li > *,
.rd-navbar-sidebar .rd-navbar-collapse-items li > * {
	vertical-align: middle;
}

.rd-navbar-fixed .rd-navbar-collapse-items li + li,
.rd-navbar-sidebar .rd-navbar-collapse-items li + li {
	margin-top: 10px;
}

.rd-navbar-fixed .rd-navbar-collapse-items .icon,
.rd-navbar-fixed .rd-navbar-collapse-items a,
.rd-navbar-sidebar .rd-navbar-collapse-items .icon,
.rd-navbar-sidebar .rd-navbar-collapse-items a {
	display: inline-block;
	font-size: 16px;
	line-height: 30px;
}

.rd-navbar-fixed .rd-navbar-collapse-items .icon, .rd-navbar-fixed .rd-navbar-collapse-items a[class*="fa"]:before,
.rd-navbar-sidebar .rd-navbar-collapse-items .icon,
.rd-navbar-sidebar .rd-navbar-collapse-items a[class*="fa"]:before {
	display: inline-block;
	width: 30px;
	height: 30px;
	padding-right: 5px;
}

.rd-navbar-fixed .rd-navbar-nav,
.rd-navbar-sidebar {
	width: 270px;
	left: 0;
	top: 0;
	font-size: 16px;
	line-height: 34px;
	color: #00030a;
	background: #fff;
	z-index: 998;
}

/*
* Static Layout
*/
.rd-navbar-static-smooth .rd-navbar {
	position: fixed;
	top: 0;
	left: 0;
	right: 0;
	z-index: 9999;
}

.rd-navbar-static {
	display: block;
}

.rd-navbar-static .rd-navbar-nav > li {
	display: inline-block;
}

.rd-navbar-static .rd-navbar-nav > li + li {
	margin-left: 10px;
}

.rd-navbar-static.rd-navbar-default .rd-navbar-search, .rd-navbar-static.rd-navbar-corporate-dark .rd-navbar-search {
	position: static;
	z-index: 2;
}

.rd-navbar-static.rd-navbar-default .rd-navbar-search .rd-search, .rd-navbar-static.rd-navbar-corporate-dark .rd-navbar-search .rd-search {
	position: absolute;
	top: -1px;
	right: 4px;
	bottom: 0;
	left: 0;
	z-index: 5;
	opacity: 0;
	visibility: hidden;
}

.rd-navbar-static.rd-navbar-default .rd-navbar-search .rd-search-submit, .rd-navbar-static.rd-navbar-corporate-dark .rd-navbar-search .rd-search-submit {
	width: 39px;
	height: 39px;
	line-height: 38px;
}

.rd-navbar-static.rd-navbar-default .rd-navbar-search .rd-search-results-live, .rd-navbar-static.rd-navbar-corporate-dark .rd-navbar-search .rd-search-results-live {
	padding: 0;
	border: 0;
	background: #fff;
}

.rd-navbar-static.rd-navbar-default .rd-navbar-search .rd-search-results-live > *, .rd-navbar-static.rd-navbar-corporate-dark .rd-navbar-search .rd-search-results-live > * {
	display: none;
	padding: 16px;
	border: 1px solid #e5e7e9;
	border-top: 0;
	border-radius: 0 0 3px 3px;
}

.rd-navbar-static.rd-navbar-default .rd-navbar-search .form-label, .rd-navbar-static.rd-navbar-corporate-dark .rd-navbar-search .form-label {
	border: 0;
}

.rd-navbar-static.rd-navbar-default .rd-navbar-search.active .rd-search, .rd-navbar-static.rd-navbar-corporate-dark .rd-navbar-search.active .rd-search {
	opacity: 1;
	visibility: visible;
	transition: .22s;
}

.rd-navbar-static.rd-navbar-default .rd-navbar-search.active .rd-search-results-live > *, .rd-navbar-static.rd-navbar-corporate-dark .rd-navbar-search.active .rd-search-results-live > * {
	display: block;
}

.rd-navbar-static.rd-navbar-default .rd-navbar-search-wrap.active .rd-navbar-nav-inner, .rd-navbar-static.rd-navbar-corporate-dark .rd-navbar-search-wrap.active .rd-navbar-nav-inner {
	position: relative;
}

.rd-navbar-static.rd-navbar-default .rd-navbar-search.active + .rd-navbar-nav, .rd-navbar-static.rd-navbar-corporate-dark .rd-navbar-search.active + .rd-navbar-nav {
	opacity: 0;
	visibility: hidden;
	pointer-events: none;
}

.rd-navbar-static.rd-navbar--is-clone {
	display: block;
	transform: translateY(-105%);
	transition: .33s all ease;
}

.rd-navbar-static.rd-navbar--is-clone.rd-navbar--is-stuck {
	transform: translateY(0);
}

.rd-navbar-static.rd-navbar--is-clone .rd-navbar-inner, .rd-navbar-static.rd-navbar--is-stuck .rd-navbar-inner {
	padding: 13px 30px;
}

.rd-navbar-static.rd-navbar--is-clone .rd-navbar-nav-wrap, .rd-navbar-static.rd-navbar--is-stuck .rd-navbar-nav-wrap {
	margin-top: 0;
}

/*
* Fullwidth Layout
*/
.rd-navbar-fullwidth {
	display: block;
	text-align: center;
}

.rd-navbar-fullwidth .rd-navbar-nav {
	width: 100%;
}

.rd-navbar-fullwidth .rd-navbar-nav > li + li {
	margin-left: 20px;
}

.rd-navbar-fullwidth.rd-navbar--is-stuck .rd-navbar-panel {
	display: none;
}

/*
* Fixed Layout
*/
.rd-navbar-fixed {
	display: block;
}

.rd-navbar-fixed .rd-navbar-brand {
	position: fixed;
	top: 10px;
	left: 64px;
	z-index: 17;
	display: block;
	overflow: hidden;
	text-align: left;
	white-space: nowrap;
	text-overflow: ellipsis;
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: flex-start;
	-ms-flex-pack: start;
	justify-content: flex-start;
}

.rd-navbar-fixed .rd-navbar-brand .brand-slogan {
	display: none;
}

.rd-navbar-fixed .rd-navbar-panel {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	position: fixed;
	left: 0;
	top: 0;
	right: 0;
	padding: 4px;
	height: 56px;
	color: #9f9f9f;
	z-index: 999;
}

.rd-navbar-fixed .rd-navbar-panel:before {
	content: '';
	position: absolute;
	left: 0;
	top: 0;
	bottom: 0;
	right: 0;
	box-shadow: none;
	border-bottom: 1px solid #e5e7e9;
	background: #fff;
}

.rd-navbar-fixed .rd-navbar-toggle {
	display: inline-block;
}

.rd-navbar-fixed .rd-navbar-nav-wrap {
	position: fixed;
	top: -56px;
	left: 0;
	bottom: -56px;
	z-index: 998;
	width: 270px;
	padding: 112px 0 56px;
	color: #fff;
	background: #fff;
	border-right: 1px solid #e5e7e9;
	transform: translateX(-105%);
	pointer-events: none;
	overflow: hidden;
}

.rd-navbar-fixed .rd-navbar-nav-wrap.active {
	transform: translateX(0);
}

.rd-navbar-fixed .rd-navbar-nav-inner {
	position: relative;
	z-index: 100000;
	height: 100%;
	padding: 10px 0 20px;
	pointer-events: auto;
	-webkit-overflow-scrolling: touch;
	overflow-x: hidden;
	overflow-y: auto;
}

.rd-navbar-fixed .rd-navbar-nav-inner::-webkit-scrollbar {
	width: 4px;
}

.rd-navbar-fixed .rd-navbar-nav-inner::-webkit-scrollbar-thumb {
	background: white;
	border: none;
	border-radius: 0;
	opacity: .2;
}

.rd-navbar-fixed .rd-navbar-nav-inner::-webkit-scrollbar-track {
	background: #fff;
	border: none;
	border-radius: 0;
}

.rd-navbar-fixed .rd-navbar-nav {
	display: block;
	font-size: 16px;
	line-height: 26px;
	text-align: left;
}

.rd-navbar-fixed .rd-navbar-nav li > a {
	display: block;
	font-size: 16px;
	padding: 14px 56px 14px 16px;
	color: #464a4d;
}

.rd-navbar-fixed .rd-navbar-nav li:hover > a, .rd-navbar-fixed .rd-navbar-nav li:hover > a:hover, .rd-navbar-fixed .rd-navbar-nav li.focus > a, .rd-navbar-fixed .rd-navbar-nav li.focus > a:hover, .rd-navbar-fixed .rd-navbar-nav li.active > a, .rd-navbar-fixed .rd-navbar-nav li.active > a:hover, .rd-navbar-fixed .rd-navbar-nav li.opened > a, .rd-navbar-fixed .rd-navbar-nav li.opened > a:hover {
	color: #fff;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.rd-navbar-fixed .rd-navbar-nav li:hover > .rd-navbar-submenu-toggle::after, .rd-navbar-fixed .rd-navbar-nav li.focus > .rd-navbar-submenu-toggle::after, .rd-navbar-fixed .rd-navbar-nav li.active > .rd-navbar-submenu-toggle::after, .rd-navbar-fixed .rd-navbar-nav li.opened > .rd-navbar-submenu-toggle::after {
	color: #fff;
}

.rd-navbar-fixed .rd-navbar-nav > li + li {
	margin-top: 4px;
}

.rd-navbar-fixed .label-custom {
	position: relative;
	top: -1px;
	display: inline-block;
	margin: 0 0 0 8px;
	font-size: 60%;
	line-height: 1;
	padding: 6px .5em 5px;
	vertical-align: middle;
}

.iphone .rd-navbar-fixed .label-custom,
.ipad .rd-navbar-fixed .label-custom,
.mac .rd-navbar-fixed .label-custom {
	padding: 6px .5em 4px;
}

.rd-navbar-fixed .rd-navbar-dropdown > li > a,
.rd-navbar-fixed .rd-navbar-list > li > a {
	font-family: "Roboto", Helvetica, Arial, sans-serif;
	font-size: 12px;
	line-height: 1.2;
}

.rd-navbar-fixed .rd-navbar-megamenu .rd-megamenu-header {
	padding: 0 15px;
}

.rd-navbar-fixed .rd-navbar-megamenu > li {
	padding-top: 15px;
}

.rd-navbar-fixed .rd-navbar-megamenu * + .rd-megamenu-header {
	margin-top: 15px;
}

.rd-navbar-fixed .rd-navbar-megamenu * + .rd-navbar-list {
	margin-top: 10px;
}

.rd-navbar-fixed .rd-navbar-dropdown,
.rd-navbar-fixed .rd-navbar-megamenu {
	display: none;
}

.rd-navbar-fixed .rd-navbar-submenu {
	position: relative;
}

.rd-navbar-fixed .rd-navbar-submenu li > a {
	font-size: 14px;
	padding-left: 30px;
}

.rd-navbar-fixed .rd-navbar-submenu .rd-navbar-dropdown li li > a,
.rd-navbar-fixed .rd-navbar-submenu .rd-navbar-megamenu ul li li > a {
	padding-left: 48px;
}

.rd-navbar-fixed .rd-navbar-submenu.opened > .rd-navbar-dropdown,
.rd-navbar-fixed .rd-navbar-submenu.opened > .rd-navbar-megamenu {
	display: block;
}

.rd-navbar-fixed .rd-navbar-search,
.rd-navbar-fixed .rd-navbar-btn-wrap {
	display: block;
	padding: 16px 5px;
}

.rd-navbar-fixed .rd-search .rd-search-results-live {
	display: none;
}

.rd-navbar-fixed .rd-navbar-btn-wrap {
	padding: 16px 10px;
}

.rd-navbar-fixed .rd-navbar-btn-wrap .btn {
	width: 100%;
}

.rd-navbar-fixed .rd-navbar-nav li .rd-navbar-dropdown,
.rd-navbar-fixed .rd-navbar-nav li .rd-navbar-megamenu {
	transition: opacity 0.3s, height 0.4s ease;
	opacity: 0;
	height: 0;
	overflow: hidden;
}

.rd-navbar-fixed .rd-navbar-nav li.opened > .rd-navbar-dropdown,
.rd-navbar-fixed .rd-navbar-nav li.opened > .rd-navbar-megamenu {
	padding: 3px 0;
	opacity: 1;
	height: auto;
}

.rd-navbar-fixed .rd-navbar-nav li.opened > .rd-navbar-submenu-toggle {
	color: #fff;
}

.rd-navbar-fixed .rd-navbar-nav li.opened > .rd-navbar-submenu-toggle::after {
	transform: rotate(180deg);
	margin-top: -24px;
}

.rd-navbar-fixed .rd-navbar-submenu-toggle::after {
	content: '\f107';
	position: absolute;
	top: 24px;
	right: 0;
	margin-top: -18px;
	width: 65px;
	height: 44px;
	font: 400 15px "FontAwesome";
	line-height: 42px;
	text-align: center;
	transition: 0.4s all ease;
	z-index: 2;
	cursor: pointer;
	color: #000;
	will-change: transform;
}

.rd-navbar-fixed .rd-navbar-collapse,
.rd-navbar-fixed .rd-navbar-search-toggle {
	position: fixed;
	top: 4px;
	height: 48px;
	z-index: 1000;
	background-color: transparent;
	border: none;
}

.rd-navbar-fixed .rd-navbar-collapse:focus,
.rd-navbar-fixed .rd-navbar-search-toggle:focus {
	outline: none;
}

.rd-navbar-fixed .rd-navbar-aside {
	top: 0;
	right: 0;
	width: 100%;
}

.rd-navbar-fixed .rd-navbar-aside, .rd-navbar-fixed .rd-navbar-aside .rd-navbar-aside-toggle {
	position: fixed;
	z-index: 1000;
	display: block;
	height: 48px;
}

.rd-navbar-fixed .rd-navbar-aside.active .rd-navbar-aside-content {
	visibility: visible;
	opacity: 1;
}

.rd-navbar-fixed .rd-navbar-aside-toggle {
	top: 4px;
	right: 4px;
	width: 48px;
	display: inline-block;
	position: relative;
	width: 48px;
	height: 48px;
	line-height: 48px;
	cursor: pointer;
	color: #000;
}

.rd-navbar-fixed .rd-navbar-aside-toggle span {
	top: 50%;
	margin-top: -3px;
}

.rd-navbar-fixed .rd-navbar-aside-toggle span, .rd-navbar-fixed .rd-navbar-aside-toggle span:before, .rd-navbar-fixed .rd-navbar-aside-toggle span:after {
	position: absolute;
	width: 6px;
	height: 6px;
	line-height: 6px;
	text-align: center;
	background: #000;
	left: 50%;
	margin-left: -3px;
	border-radius: 50%;
	transition: .3s all ease;
}

.rd-navbar-fixed .rd-navbar-aside-toggle span:before, .rd-navbar-fixed .rd-navbar-aside-toggle span:after {
	content: '';
}

.rd-navbar-fixed .rd-navbar-aside-toggle span:before {
	bottom: 100%;
	margin-bottom: 3px;
}

.rd-navbar-fixed .rd-navbar-aside-toggle span:after {
	top: 100%;
	margin-top: 3px;
}

.rd-navbar-fixed .rd-navbar-aside-toggle.active span {
	transform: scale(0.7);
}

.rd-navbar-fixed .rd-navbar-aside-toggle.active span:before {
	transform: translateY(18px);
}

.rd-navbar-fixed .rd-navbar-aside-toggle.active span:after {
	transform: translateY(-18px);
}

.rd-navbar-fixed .rd-navbar-aside-content {
	position: absolute;
	top: calc(100% + 7px);
	right: 0;
	width: calc(100% + 2px);
	padding: 20px 35px;
	margin: 0 -1px;
	pointer-events: auto;
	opacity: 0;
	visibility: hidden;
	transition: .23s all ease-out;
}

@media (min-width: 768px) {
	.rd-navbar-fixed .rd-navbar-aside-content {
		width: auto;
	}
}

.rd-navbar-fixed.rd-navbar--is-clone {
	display: none;
}

.rd-navbar-fixed .rd-navbar-fixed--visible {
	display: block;
}

.rd-navbar-fixed .rd-navbar-fixed--hidden {
	display: none;
}

html.rd-navbar-fixed-linked .page {
	padding-top: 56px;
}

/*
* Sidebar Layout
*/
html.rd-navbar-sidebar-linked body {
	padding-left: 270px;
}

.rd-navbar-sidebar {
	position: fixed;
	display: block;
}

.rd-navbar-sidebar .rd-navbar-nav li:hover > a, .rd-navbar-sidebar .rd-navbar-nav li:hover > a:hover, .rd-navbar-sidebar .rd-navbar-nav li.focus > a, .rd-navbar-sidebar .rd-navbar-nav li.focus > a:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	background: transparent;
}

.rd-navbar-sidebar .rd-navbar-nav li:hover > .rd-navbar-submenu-toggle, .rd-navbar-sidebar .rd-navbar-nav li.focus > .rd-navbar-submenu-toggle {
	color: #fff;
}

.rd-navbar-sidebar .rd-navbar-nav li:hover > .rd-navbar-submenu-toggle:hover, .rd-navbar-sidebar .rd-navbar-nav li.focus > .rd-navbar-submenu-toggle:hover {
	cursor: pointer;
	color: #fff;
}

.rd-navbar-sidebar .rd-navbar-nav li .rd-navbar-dropdown,
.rd-navbar-sidebar .rd-navbar-nav li .rd-navbar-megamenu {
	transition: opacity 0.3s, height 0.4s ease;
	opacity: 0;
	height: 0;
	overflow: hidden;
}

.rd-navbar-sidebar .rd-navbar-nav li.opened > .rd-navbar-dropdown,
.rd-navbar-sidebar .rd-navbar-nav li.opened > .rd-navbar-megamenu {
	opacity: 1;
	height: auto;
}

.rd-navbar-sidebar .rd-navbar-nav li.opened > a {
	background: transparent;
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.rd-navbar-sidebar .rd-navbar-nav li.opened > .rd-navbar-submenu-toggle {
	color: #fff;
}

.rd-navbar-sidebar .rd-navbar-nav li.opened > .rd-navbar-submenu-toggle::after {
	-webkit-transform: rotate(180deg);
	transform: rotate(180deg);
}

.rd-navbar-sidebar .rd-navbar-submenu-toggle::after {
	content: '\f078';
	position: absolute;
	top: 22px;
	right: 0;
	margin-top: -22px;
	width: 65px;
	height: 44px;
	font: 400 14px "FontAwesome";
	line-height: 42px;
	text-align: center;
	transition: 0.4s all ease;
	z-index: 2;
}

.rd-navbar-sidebar .rd-navbar-brand {
	text-align: center;
}

.rd-navbar-sidebar .rd-navbar-collapse-items {
	top: 0;
	left: 0;
	padding-top: 45px;
	transform: scale(0.7);
	transform-origin: 0% 0%;
	opacity: 0;
	visibility: hidden;
}

.rd-navbar-sidebar .rd-navbar-collapse {
	position: absolute;
	top: 4px;
	left: 4px;
	display: inline-block;
	z-index: 1;
}

.rd-navbar-sidebar .rd-navbar-collapse.active .rd-navbar-collapse-items {
	opacity: 1;
	visibility: visible;
	transform: scale(1);
}

.rd-navbar-default .rd-navbar-nav > li > a {
	font-family: "Roboto", Helvetica, Arial, sans-serif;
	font-weight: 700;
	line-height: 1.2;
	text-transform: uppercase;
	color: #00030a;
}

.rd-navbar-default .rd-navbar-search .form-input,
.rd-navbar-default .rd-navbar-search .form-label {
	font-size: 16px;
	line-height: 1.3;
	color: #9b9b9b;
}

.rd-navbar-default .rd-navbar-search .form-label {
	top: 18px;
	left: 22px;
}

.rd-navbar-default .rd-navbar-search .form-input {
	padding: 7px 45px 10px 22px;
	height: auto;
	min-height: 20px;
	border: 1px solid #e5e7e9;
	border-radius: 3px;
}

.rd-navbar-default .rd-navbar-search .rd-navbar-search-toggle,
.rd-navbar-default .rd-navbar-search .rd-search-submit {
	font-size: 25px;
}

.rd-navbar-default .rd-navbar-search .rd-navbar-search-toggle, .rd-navbar-default .rd-navbar-search .rd-navbar-search-toggle:active, .rd-navbar-default .rd-navbar-search .rd-navbar-search-toggle:focus,
.rd-navbar-default .rd-navbar-search .rd-search-submit,
.rd-navbar-default .rd-navbar-search .rd-search-submit:active,
.rd-navbar-default .rd-navbar-search .rd-search-submit:focus {
	color: #00030a;
}

.rd-navbar-default .rd-navbar-search .rd-navbar-search-toggle:hover,
.rd-navbar-default .rd-navbar-search .rd-search-submit:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.rd-navbar-default .rd-navbar-search .rd-navbar-search-toggle, .rd-navbar-default .rd-navbar-search .rd-navbar-search-toggle:before,
.rd-navbar-default .rd-navbar-search .rd-search-submit,
.rd-navbar-default .rd-navbar-search .rd-search-submit:before {
	font-family: 'Material Icons';
}

.rd-navbar-default .rd-navbar-search .rd-navbar-search-toggle {
	position: relative;
}

.rd-navbar-default .rd-navbar-search .rd-navbar-search-toggle:after {
	content: '\e5cd';
}

.rd-navbar-default.rd-navbar-fixed .rd-navbar-shop {
	position: fixed;
	top: 15px;
	right: 15px;
	z-index: 1001;
}

.rd-navbar-default.rd-navbar-fixed .rd-navbar-search .rd-navbar-search-toggle {
	display: none;
}

.rd-navbar-default.rd-navbar-static .rd-navbar-inner,
.rd-navbar-default.rd-navbar-static .rd-navbar-group {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
}

.rd-navbar-default.rd-navbar-static .rd-navbar-inner {
	-webkit-justify-content: space-between;
	-ms-flex-pack: justify;
	justify-content: space-between;
	padding: 44px 15px 42px;
	font-size: 0;
	line-height: 0;
}

.rd-navbar-default.rd-navbar-static .rd-navbar-panel {
	min-width: 100px;
}

.rd-navbar-default.rd-navbar-static .rd-navbar-group {
	-webkit-justify-content: flex-end;
	-ms-flex-pack: end;
	justify-content: flex-end;
}

.rd-navbar-default.rd-navbar-static .rd-navbar-nav-inner {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row-reverse;
	-ms-flex-direction: row-reverse;
	flex-direction: row-reverse;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: flex-start;
	-ms-flex-pack: start;
	justify-content: flex-start;
	margin-right: 12px;
}

.rd-navbar-default.rd-navbar-static .rd-navbar-nav {
	z-index: 0;
	margin-right: 40px;
	transition: .25s;
}

.rd-navbar-default.rd-navbar-static .rd-navbar-nav > li + li {
	margin-left: 32px;
}

@media (min-width: 1200px) {
	.rd-navbar-default.rd-navbar-static .rd-navbar-nav {
		margin-right: 77px;
	}
	.rd-navbar-default.rd-navbar-static .rd-navbar-nav > li + li {
		margin-left: 48px;
	}
}

.rd-navbar-default.rd-navbar-static .rd-navbar-toggle .rd-navbar-nav > li .rd-navbar-toggle {
	display: none;
}

.rd-navbar-default.rd-navbar-static .rd-navbar-nav > li > .rd-navbar-dropdown {
	margin-top: 54px;
}

.rd-navbar-default.rd-navbar-static.rd-navbar--is-clone .rd-navbar-inner, .rd-navbar-default.rd-navbar-static.rd-navbar--is-stuck .rd-navbar-inner {
	padding: 18px 15px;
}

.rd-navbar-default.rd-navbar-static.rd-navbar--is-clone .rd-navbar-nav > li > .rd-navbar-dropdown, .rd-navbar-default.rd-navbar-static.rd-navbar--is-stuck .rd-navbar-nav > li > .rd-navbar-dropdown {
	margin-top: 49px;
}

.rd-navbar-corporate-dark .rd-navbar-nav > li > a {
	font-weight: 700;
	font-size: 14px;
	letter-spacing: .05em;
	text-transform: uppercase;
}

.rd-navbar-corporate-dark .rd-navbar-search .form-input,
.rd-navbar-corporate-dark .rd-navbar-search .form-label {
	font-size: 16px;
	line-height: 1.3;
	color: #9b9b9b;
}

.rd-navbar-corporate-dark .rd-navbar-search .form-label {
	top: 18px;
	left: 22px;
}

.rd-navbar-corporate-dark .rd-navbar-search .form-input {
	padding: 7px 45px 7px 22px;
	height: auto;
	min-height: 20px;
	border: 1px solid #e5e7e9;
	border-radius: 3px;
}

.rd-navbar-corporate-dark .rd-navbar-search .rd-navbar-search-toggle,
.rd-navbar-corporate-dark .rd-navbar-search .rd-search-submit {
	text-align: center;
	color: #000;
}

.rd-navbar-corporate-dark .rd-navbar-search .rd-navbar-search-toggle:before,
.rd-navbar-corporate-dark .rd-navbar-search .rd-search-submit:before {
	position: static;
	display: inline-block;
	font-family: 'fl-bigmug-line';
	font-size: 20px;
}

.rd-navbar-corporate-dark .rd-navbar-search .rd-navbar-search-toggle:hover,
.rd-navbar-corporate-dark .rd-navbar-search .rd-search-submit:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.rd-navbar-corporate-dark .rd-navbar-search .rd-navbar-search-toggle:after {
	display: none;
}

.rd-navbar-corporate-dark .rd-navbar-aside {
	width: 100%;
	font-size: 14px;
	line-height: 1.71429;
}

.rd-navbar-corporate-dark.rd-navbar-fixed .rd-navbar-aside-content {
	border-bottom: 1px solid #000;
	border-left: 1px solid #000;
	background: #111;
}

.rd-navbar-corporate-dark.rd-navbar-fixed .rd-navbar-aside .list-units > li + li {
	margin-top: 10px;
}

.rd-navbar-corporate-dark.rd-navbar-fixed .rd-navbar-aside * + .rd-navbar-aside-group {
	margin-top: 14px;
}

@media (min-width: 576px) {
	.rd-navbar-corporate-dark.rd-navbar-fixed .rd-navbar-aside-content {
		width: auto;
	}
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-group {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-inner {
	padding: 0;
	font-size: 0;
	line-height: 0;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-panel {
	min-width: 100px;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-aside {
	position: relative;
	z-index: 2;
	background: #3a3c3e;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-aside:after {
	content: '';
	position: absolute;
	top: 0;
	bottom: 0;
	left: 50%;
	transform: translateX(-50%);
	background: inherit;
	width: 102vw;
	z-index: -1;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-aside .rd-navbar-aside-content,
.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-aside .rd-navbar-aside-group {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-aside .rd-navbar-aside-content {
	padding: 12px 15px;
	margin-bottom: -5px;
	transform: translateY(-5px);
	-webkit-justify-content: space-between;
	-ms-flex-pack: justify;
	justify-content: space-between;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-aside .rd-navbar-aside-group {
	-webkit-flex-shrink: 0;
	-ms-flex-negative: 0;
	flex-shrink: 0;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-aside .rd-navbar-aside-group:first-child {
	margin-top: 7px;
	-webkit-flex-grow: 8;
	-ms-flex-positive: 8;
	flex-grow: 8;
	-webkit-justify-content: flex-start;
	-ms-flex-pack: start;
	justify-content: flex-start;
	margin-right: 20px;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-aside .rd-navbar-aside-group:last-child {
	margin-top: 5px;
	-webkit-justify-content: flex-end;
	-ms-flex-pack: end;
	justify-content: flex-end;
	-webkit-flex-grow: 1;
	-ms-flex-positive: 1;
	flex-grow: 1;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-aside .list-units li {
	display: inline-block;
	margin-top: 0;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-aside .list-units li:not(:last-child) {
	margin-right: 25px;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-group {
	padding: 35px 15px;
	-webkit-justify-content: space-between;
	-ms-flex-pack: justify;
	justify-content: space-between;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-nav-inner {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row-reverse;
	-ms-flex-direction: row-reverse;
	flex-direction: row-reverse;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: flex-start;
	-ms-flex-pack: start;
	justify-content: flex-start;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-nav {
	margin-right: 23px;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-nav > li {
	padding-left: 5px;
	padding-right: 5px;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-nav > li > a {
	font-size: 13px;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-nav > li.rd-navbar-submenu {
	margin-right: -18px;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-nav > li > .rd-navbar-submenu-toggle {
	display: inline-block;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-nav > li + li {
	margin-left: 32px;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-nav .rd-navbar-dropdown > li {
	padding-left: 5px;
	padding-right: 5px;
}

@media (min-width: 1200px) {
	.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-nav > li > a {
		font-size: 14px;
	}
	.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-nav > li + li {
		margin-left: 29px;
	}
	.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-aside .list-units li:not(:last-child) {
		margin-right: 50px;
	}
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-search {
	position: static;
	z-index: 2;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-search .rd-search {
	position: absolute;
	top: -2px;
	right: -2px;
	bottom: 0;
	left: 0;
	z-index: 5;
	opacity: 0;
	visibility: hidden;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-search .rd-search-submit {
	width: 39px;
	height: 39px;
	line-height: 38px;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-search-wrap.active .rd-navbar-nav-wrap {
	position: relative;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-search.active + .rd-navbar-nav {
	opacity: 0;
	visibility: hidden;
	pointer-events: none;
}

.rd-navbar-corporate-dark.rd-navbar-static .rd-navbar-toggle .rd-navbar-nav > li .rd-navbar-toggle {
	display: none;
}

.rd-navbar-corporate-dark.rd-navbar-static.rd-navbar--is-clone .rd-navbar-aside, .rd-navbar-corporate-dark.rd-navbar-static.rd-navbar--is-stuck .rd-navbar-aside {
	display: none;
}

.rd-navbar-corporate-dark.rd-navbar-static.rd-navbar--is-clone .rd-navbar-group, .rd-navbar-corporate-dark.rd-navbar-static.rd-navbar--is-stuck .rd-navbar-group {
	padding-top: 18px;
	padding-bottom: 18px;
}

.rd-navbar-corporate-dark.rd-navbar-static.rd-navbar--is-clone .rd-navbar-nav > li > .rd-navbar-dropdown, .rd-navbar-corporate-dark.rd-navbar-static.rd-navbar--is-stuck .rd-navbar-nav > li > .rd-navbar-dropdown {
	margin-top: 18px;
}

.rd-navbar-corporate-light .rd-navbar-nav > li > a {
	font: 400 16px "Roboto", Helvetica, Arial, sans-serif;
	letter-spacing: .025em;
}

.rd-navbar-corporate-light .rd-navbar-search .form-input,
.rd-navbar-corporate-light .rd-navbar-search .form-label {
	font-size: 16px;
	line-height: 1.3;
	color: #9b9b9b;
}

.rd-navbar-corporate-light .rd-navbar-search .form-label {
	top: 18px;
	left: 22px;
}

.rd-navbar-corporate-light .rd-navbar-search .form-input {
	padding: 7px 22px 10px;
	height: auto;
	min-height: 20px;
	border: 1px solid #e5e7e9;
	border-radius: 3px;
}

.rd-navbar-corporate-light .rd-navbar-search .rd-navbar-search-toggle,
.rd-navbar-corporate-light .rd-navbar-search .rd-search-submit {
	text-align: center;
}

.rd-navbar-corporate-light .rd-navbar-search .rd-navbar-search-toggle:before,
.rd-navbar-corporate-light .rd-navbar-search .rd-search-submit:before {
	font-family: 'fl-bigmug-line';
	position: static;
	display: inline-block;
}

.rd-navbar-corporate-light .rd-navbar-search .rd-navbar-search-toggle:before, .rd-navbar-corporate-light .rd-navbar-search .rd-navbar-search-toggle:after {
	font-size: 20px;
}

.rd-navbar-corporate-light .rd-navbar-search .rd-navbar-search-toggle:before {
	font-family: 'fl-bigmug-line';
	color: #000;
}

.rd-navbar-corporate-light .rd-navbar-search .rd-navbar-search-toggle:after {
	font-family: 'Material Icons';
}

.rd-navbar-corporate-light .rd-navbar-search .rd-navbar-search-toggle:hover:before {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.rd-navbar-corporate-light .rd-navbar-search .rd-navbar-search-toggle, .rd-navbar-corporate-light .rd-navbar-search .rd-navbar-search-toggle:before, .rd-navbar-corporate-light .rd-navbar-search .rd-navbar-search-toggle:after {
	width: 36px;
	height: 36px;
	text-align: center;
}

.rd-navbar-corporate-light .rd-navbar-search .rd-navbar-search-toggle:before, .rd-navbar-corporate-light .rd-navbar-search .rd-navbar-search-toggle:after {
	display: block;
	position: absolute;
	left: 0;
	top: 0;
}

.rd-navbar-corporate-light .rd-navbar-search .rd-navbar-search-toggle:before {
	content: "";
	transform: scale(1) rotate(0deg);
}

.rd-navbar-corporate-light .rd-navbar-search .rd-navbar-search-toggle:after {
	content: "";
	opacity: 0;
	transform: scale(0) rotate(-90deg);
}

.rd-navbar-corporate-light .rd-navbar-search .rd-navbar-search-toggle.active:before {
	opacity: 0;
	transform: scale(0) rotate(90deg);
}

.rd-navbar-corporate-light .rd-navbar-search .rd-navbar-search-toggle.active:after {
	opacity: 1;
	transform: scale(1) rotate(0deg);
}

.rd-navbar-corporate-light .rd-navbar-aside {
	width: 100%;
	font-size: 14px;
	line-height: 1.71429;
}

.rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-search {
	padding: 0;
}

.rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-search .rd-search {
	opacity: 0;
	visibility: hidden;
	position: fixed;
	width: 100%;
	padding: 8px 10px;
	transform: translateY(-80%);
	background: #fff;
	border: 1px solid #e5e7e9;
	border-top: 0;
}

.rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-search.active .rd-search {
	opacity: 1;
	visibility: visible;
	transform: translateY(0);
}

.rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-search .form-input {
	padding: 7px 46px 10px 22px;
}

.rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-search .rd-navbar-search-toggle,
.rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-search .rd-search-submit {
	font-size: 20px;
}

.rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-search .rd-navbar-search-toggle, .rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-search .rd-navbar-search-toggle:active, .rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-search .rd-navbar-search-toggle:focus,
.rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-search .rd-search-submit,
.rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-search .rd-search-submit:active,
.rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-search .rd-search-submit:focus {
	color: #000;
}

.rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-search .rd-navbar-search-toggle:hover,
.rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-search .rd-search-submit:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-search .rd-navbar-search-toggle {
	position: fixed;
	right: 56px;
	top: 10px;
	z-index: 1000;
}

.rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-search .rd-search-submit {
	right: 10px;
}

.rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-aside-content {
	border: 1px solid #e5e7e9;
	background: #fff;
}

.rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-aside .list-units > li + li {
	margin-top: 10px;
}

.rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-aside * + .rd-navbar-aside-group {
	margin-top: 14px;
}

@media (min-width: 576px) {
	.rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-aside-content {
		width: auto;
	}
}

.rd-navbar-corporate-light.rd-navbar-fixed .rd-navbar-btn-wrap {
	padding: 16px 5px;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-group {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-inner {
	padding: 0;
	font-size: 0;
	line-height: 0;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-panel {
	min-width: 100px;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-aside {
	position: relative;
	z-index: 100;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-aside-wrap,
.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-aside .rd-navbar-aside-content,
.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-aside .rd-navbar-aside-group {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-aside-wrap {
	position: relative;
	z-index: 1001;
	padding: 6px 20px 6px 10px;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-aside-wrap:after {
	content: '';
	position: absolute;
	top: 0;
	bottom: 0;
	left: 50%;
	transform: translateX(-50%);
	border-bottom: 1px solid #e5e7e9;
	width: 101vw;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-aside-wrap > * + * {
	margin-left: 10px;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-aside .rd-navbar-aside-content {
	margin-bottom: -5px;
	transform: translateY(-5px);
	-webkit-justify-content: space-between;
	-ms-flex-pack: justify;
	justify-content: space-between;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-aside .rd-navbar-aside-group {
	-webkit-flex-shrink: 0;
	-ms-flex-negative: 0;
	flex-shrink: 0;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-aside .rd-navbar-aside-group:first-child {
	margin-top: 7px;
	-webkit-flex-grow: 8;
	-ms-flex-positive: 8;
	flex-grow: 8;
	-webkit-justify-content: flex-start;
	-ms-flex-pack: start;
	justify-content: flex-start;
	margin-right: 20px;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-aside .rd-navbar-aside-group:last-child {
	margin-top: 5px;
	-webkit-justify-content: flex-end;
	-ms-flex-pack: end;
	justify-content: flex-end;
	-webkit-flex-grow: 1;
	-ms-flex-positive: 1;
	flex-grow: 1;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-aside .list-units li {
	display: inline-block;
	margin-top: 0;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-aside .list-units li:not(:last-child) {
	margin-right: 30px;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-group {
	padding: 35px 15px;
	-webkit-justify-content: space-between;
	-ms-flex-pack: justify;
	justify-content: space-between;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-nav-inner {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row-reverse;
	-ms-flex-direction: row-reverse;
	flex-direction: row-reverse;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: flex-start;
	-ms-flex-pack: start;
	justify-content: flex-start;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-nav {
	margin-right: 40px;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-nav > li > a {
	font-size: 15px;
	padding: 7px 0;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-nav > li.rd-navbar-submenu {
	margin-right: -24px;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-nav > li > .rd-navbar-submenu-toggle {
	position: relative;
	top: 2px;
	display: inline-block;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-nav > li + li {
	margin-left: 37px;
}

@media (min-width: 1200px) {
	.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-nav > li > a {
		font-size: 16px;
	}
	.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-nav > li + li {
		margin-left: 48px;
	}
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-search {
	position: relative;
	z-index: 1500;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-search .form-label {
	-webkit-flex-grow: 1;
	-ms-flex-positive: 1;
	flex-grow: 1;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-search .form-input,
.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-search .form-label {
	color: #fff;
	font-size: 30px;
	font-weight: 700;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-search .form-label {
	top: 24px;
	left: 0;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-search .form-input {
	padding: 10px 50px 9px 0;
	background-color: transparent;
	border: 0;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-search .btn {
	-webkit-flex-shrink: 0;
	-ms-flex-negative: 0;
	flex-shrink: 0;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search {
	position: fixed;
	top: 0;
	right: 0;
	bottom: 0;
	left: 0;
	z-index: -1000;
	opacity: 0;
	visibility: hidden;
	background: rgba(0, 0, 0, 0.96);
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-inner {
	width: 540px;
	margin-top: 75px;
	margin-left: auto;
	margin-right: auto;
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	border-bottom: 1px solid #fff;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-submit {
	position: relative;
	left: 0;
	top: 0;
	width: 39px;
	height: 39px;
	font-size: 25px;
	line-height: 39px;
	transform: none;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-submit, .rd-navbar-corporate-light.rd-navbar-static .rd-search-submit:active, .rd-navbar-corporate-light.rd-navbar-static .rd-search-submit:focus {
	color: #fff;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-submit:hover {
	color: #ababab;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live {
	position: relative;
	display: block;
	top: auto;
	right: auto;
	bottom: auto;
	left: auto;
	margin-top: 60px;
	margin-left: auto;
	margin-right: auto;
	width: 800px;
	font-size: 20px;
	background-color: transparent;
	opacity: 1;
	visibility: visible;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live > * {
	display: block;
	padding: 0;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .active .search_list li {
	top: 0;
	opacity: 1;
	visibility: visible;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search-quick-result {
	display: none;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list {
	margin: 0;
	background-color: transparent;
	text-align: left;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li {
	position: relative;
	top: 30px;
	display: inline-block;
	width: 48%;
	padding: 0 15px;
	text-align: left;
	transition: .5s all ease-in-out;
	opacity: 0;
	visibility: hidden;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list .search_all {
	top: 0;
	margin-top: 40px;
	display: inline-block;
	width: 100%;
	text-align: right;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li:nth-child(0) {
	transition-delay: 0s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li:nth-child(1) {
	transition-delay: 0.15s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li:nth-child(2) {
	transition-delay: 0.3s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li:nth-child(3) {
	transition-delay: 0.45s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li:nth-child(4) {
	transition-delay: 0.6s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li:nth-child(5) {
	transition-delay: 0.75s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li:nth-child(6) {
	transition-delay: 0.9s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li:nth-child(7) {
	transition-delay: 1.05s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li:nth-child(8) {
	transition-delay: 1.2s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li:nth-child(9) {
	transition-delay: 1.35s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li:nth-child(10) {
	transition-delay: 1.5s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li.search_all:nth-child(0) {
	transition-delay: 0s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li.search_all:nth-child(1) {
	transition-delay: 0.2s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li.search_all:nth-child(2) {
	transition-delay: 0.4s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li.search_all:nth-child(3) {
	transition-delay: 0.6s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li.search_all:nth-child(4) {
	transition-delay: 0.8s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li.search_all:nth-child(5) {
	transition-delay: 1s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li.search_all:nth-child(6) {
	transition-delay: 1.2s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li.search_all:nth-child(7) {
	transition-delay: 1.4s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li.search_all:nth-child(8) {
	transition-delay: 1.6s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li.search_all:nth-child(9) {
	transition-delay: 1.8s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_list li.search_all:nth-child(10) {
	transition-delay: 2s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .result-item:only-child {
	top: 0;
	width: 100%;
	text-align: center;
	transition-delay: 0s;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .result-item:nth-child(n + 3) {
	margin-top: 50px;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_title {
	font: 700 30px/26px Helvetica, Arial, sans-serif;
	font-style: italic;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_title a, .rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_title a:active, .rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_title a:focus {
	color: #fff;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_title a:hover {
	color: #ababab;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_title + p {
	margin-top: 16px;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_error {
	line-height: 1.35;
	text-align: center;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_submit {
	display: inline-block;
	padding: 10px 35px;
	border: 2px solid;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_submit, .rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_submit:active, .rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_submit.active, .rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_submit:active:focus, .rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_submit.active:focus, .rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_submit:focus:active, .rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_submit:focus {
	color: #fff;
	background-color: transparent;
	border-color: #fff;
}

.open > .rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_submit.dropdown-toggle, .rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_submit:hover {
	color: #414141;
	background-color: #fff;
	border-color: #fff;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_submit.disabled, .rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_submit[disabled],
fieldset[disabled] .rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_submit {
	pointer-events: none;
	opacity: .5;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-search-results-live .search_submit .badge {
	color: transparent;
	background-color: #fff;
}

@media (min-width: 1600px) and (min-height: 767px) {
	.rd-navbar-corporate-light.rd-navbar-static .rd-search .rd-search-inner {
		margin-top: 10%;
	}
}

@media (max-height: 767px) {
	.rd-navbar-corporate-light.rd-navbar-static .rd-search .rd-search-results-live .result-item:nth-child(5),
	.rd-navbar-corporate-light.rd-navbar-static .rd-search .rd-search-results-live .result-item:nth-child(6) {
		display: none;
	}
	.rd-navbar-corporate-light.rd-navbar-static .rd-search .rd-search-results-live .search_list > li.search_all {
		transition-delay: 0.8s;
	}
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-search.active .rd-search {
	display: block;
	z-index: 10000;
	margin: 0;
	opacity: 1;
	visibility: visible;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-search.active .rd-navbar-search-toggle {
	z-index: 10002;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-search.active .rd-navbar-search-toggle:after {
	color: #fff;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-search.active .rd-navbar-search-toggle:hover:after {
	color: #ababab;
}

.rd-navbar-corporate-light.rd-navbar-static .rd-navbar-toggle .rd-navbar-nav > li .rd-navbar-toggle {
	display: none;
}

.rd-navbar-corporate-light.rd-navbar-static.rd-navbar--is-clone .rd-navbar-aside-wrap, .rd-navbar-corporate-light.rd-navbar-static.rd-navbar--is-stuck .rd-navbar-aside-wrap {
	position: absolute;
	top: -60px;
}

.rd-navbar-corporate-light.rd-navbar-static.rd-navbar--is-clone .rd-navbar-group, .rd-navbar-corporate-light.rd-navbar-static.rd-navbar--is-stuck .rd-navbar-group {
	padding-top: 17px;
	padding-bottom: 17px;
}

.rd-navbar-corporate-light.rd-navbar-static.rd-navbar--is-clone .rd-navbar-nav > li > .rd-navbar-dropdown, .rd-navbar-corporate-light.rd-navbar-static.rd-navbar--is-stuck .rd-navbar-nav > li > .rd-navbar-dropdown {
	margin-top: 50px;
}

/*
* @subsection   Page boxed layout style redeclaration
*
* @description  Redefines navbar style inside boxed layout
*
* @see          ../modules/_page-layouts.scss
*/
html.boxed.rd-navbar--has-sidebar body {
	padding-left: 300px;
	padding-right: 30px;
}

html.boxed .rd-navbar--is-clone {
	max-width: 1920px;
	margin-left: auto;
	margin-right: auto;
}

/*
* @subsection   RD Parallax
*
* @description  Describes style declarations for RD Parallax extension
*
* @author       Evgeniy Gusarov
* @link         https://ua.linkedin.com/pub/evgeniy-gusarov/8a/a40/54a
* @version      3.5.1
*/
.rd-parallax-inner {
	position: relative;
	overflow: hidden;
	-webkit-transform: translate3d(0px, 0px, 0px);
	transform: translate3d(0px, 0px, 0px);
	z-index: 1;
}

.rd-parallax-layer[data-type="media"] {
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	height: 100%;
	pointer-events: none;
}

.rd-parallax-layer[data-type="media"] iframe {
	width: 100%;
	height: 100%;
}

.rd-parallax-layer[data-url] {
	-webkit-background-size: cover;
	background-size: cover;
	background-position: center center;
}

.rd-parallax[class*="rd-parallax-overlay"] {
	background-color: #000;
	color: #fff;
}

.rd-parallax[class*="rd-parallax-overlay"] .rd-parallax-layer[data-type="media"] {
	opacity: 0.2;
}

.rd-parallax[class*="rd-parallax-overlay"] .rd-parallax-layer[data-type="media"] + * {
	position: relative;
}

.rd-parallax.rd-parallax-overlay-2 .rd-parallax-layer[data-type="media"] {
	opacity: 0.8;
}

/*
* @subsection   RD Google Map
*
* @description  Describes style declarations for RD Google Map extension
*
* @author       Evgeniy Gusarov
* @link         https://ua.linkedin.com/pub/evgeniy-gusarov/8a/a40/54a
* @version      1.0.0
*/
.google-map-markers {
	display: none;
}

.google-map-container {
	width: 100%;
}

.google-map {
	height: 250px;
	color: #333;
}

.google-map img {
	max-width: none !important;
}

@media (min-width: 576px) {
	.google-map {
		height: 250px;
	}
}

@media (min-width: 768px) {
	.google-map {
		height: 400px;
	}
}

@media (min-width: 1200px) {
	.google-map {
		height: 450px;
	}
}

@media (min-width: 1800px) {
	.google-map {
		height: 532px;
	}
}

.rd-search {
	position: relative;
}

.rd-search .form-wrap {
	display: block;
	margin: 0;
	font-size: 0;
}

.rd-search label * {
	margin-top: 0;
}

.rd-search .rd-search-submit {
	top: 16px;
	right: -4px;
	background-color: transparent;
	border: none;
	transform: translateY(-50%);
}

.rd-search .text-mobile {
	display: block;
}

.rd-search .text-default {
	display: none;
}

@media (min-width: 768px) {
	.rd-search .text-mobile {
		display: none;
	}
	.rd-search .text-default {
		display: block;
	}
}

.rd-search-submit {
	background: none;
	border: none;
	display: inline-block;
	padding: 0;
	outline: none;
	outline-offset: 0;
	cursor: pointer;
	-webkit-appearance: none;
	display: inline-block;
	position: relative;
	width: 48px;
	height: 48px;
	line-height: 48px;
	cursor: pointer;
	color: #00030a;
	text-align: center;
	font-size: 22px;
	position: absolute;
	right: 0;
	transition: color .33s;
}

.rd-search-submit::-moz-focus-inner {
	border: none;
	padding: 0;
}

.rd-search-submit:before {
	font-weight: 400;
	font-family: "FontAwesome";
}

.rd-search-submit.active {
	transform: scale(0.7);
}

.rd-search-submit:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.rd-search-minimal {
	position: relative;
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: row;
	-ms-flex-direction: row;
	flex-direction: row;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: stretch;
	-ms-flex-align: stretch;
	align-items: stretch;
	-webkit-justify-content: center;
	-ms-flex-pack: center;
	justify-content: center;
	padding-left: 40px;
	border-bottom: 1px solid #dedede;
}

.rd-search-minimal:before {
	content: '\e8b6';
	position: absolute;
	top: 50%;
	transform: translateY(-50%);
	left: 10px;
	font: 400 21px 'Material Icons';
	color: #000;
}

.rd-search-minimal .form-wrap {
	-webkit-flex-grow: 1;
	-ms-flex-positive: 1;
	flex-grow: 1;
}

.rd-search-minimal .form-label,
.rd-search-minimal .form-input {
	font: 400 16px/24px "Roboto", Helvetica, Arial, sans-serif;
	color: rgba(0, 0, 0, 0.2);
	letter-spacing: -.025em;
}

.rd-search-minimal .form-label {
	top: 29px;
}

.rd-search-minimal .form-input {
	padding: 17px 20px;
}

.rd-search-minimal button[type='submit'] {
	padding: 0 20px;
	-webkit-flex-shrink: 0;
	-ms-flex-negative: 0;
	flex-shrink: 0;
}

@media (min-width: 768px) {
	.rd-search-minimal .form-label,
	.rd-search-minimal .form-input {
		font-size: 19px;
	}
}

.rd-search-classic {
	overflow: hidden;
	border: 1px solid #dedede;
	border-radius: 0;
}

.rd-search-classic .form-input {
	min-height: 50px;
	padding: 13px 50px 15px 19px;
	border: 0;
}

.rd-search-classic .rd-search-submit {
	position: absolute;
	right: 0;
	top: 0;
	bottom: 0;
	width: 40px;
	line-height: 0;
	height: auto;
	transform: none;
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: center;
	-ms-flex-pack: center;
	justify-content: center;
	text-align: left;
}

.rd-search-classic .rd-search-submit:before {
	font: 400 25px 'Material Icons';
}

.search_error {
	max-width: 100%;
	overflow: hidden;
	text-overflow: ellipsis;
}

.rd-search-results-live {
	position: absolute;
	left: 0;
	right: 0;
	top: 100%;
	z-index: 998;
	margin: -3px 0 0;
	font-size: 14px;
	line-height: 34px;
	text-align: left;
	color: #9f9f9f;
	opacity: 0;
	visibility: hidden;
}

.rd-search-results-live > * {
	padding: 16px;
	border: 0px solid #dedede;
	border-top: 0;
}

.rd-search-results-live .search-quick-result {
	font: 700 14px/24px "Roboto", Helvetica, Arial, sans-serif;
	color: #000;
	letter-spacing: .06em;
	text-transform: uppercase;
}

.rd-search-results-live .search_list {
	margin-top: 10px;
	font-size: 16px;
	line-height: 30px;
}

.rd-search-results-live .search_list li + li {
	margin-top: 20px;
}

.rd-search-results-live .search_list .search_error {
	padding-bottom: 10px;
	font-size: 14px;
	line-height: 1.1;
}

.rd-search-results-live .search_link, .rd-search-results-live .search_link:active, .rd-search-results-live .search_link:focus {
	color: #464a4d;
}

.rd-search-results-live .search_link:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.rd-search-results-live p {
	margin-top: 0;
	font-size: 14px;
	line-height: 1.6;
}

.rd-search-results-live .search_title {
	margin-bottom: 0;
	font-family: "Roboto", Helvetica, Arial, sans-serif;
	font-size: 14px;
	font-weight: 700;
	color: #000;
}

.rd-search-results-live .search_submit {
	display: block;
	padding: 6px 20px;
	font-size: 14px;
	font-weight: 700;
	text-align: center;
	color: #fff;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	border-radius: 5px;
	border: 0;
	text-transform: uppercase;
	transition: .3s ease-out;
}

.rd-search-results-live .search_submit:hover {
	color: #fff;
	background: #3a3c3e;
}

.rd-search-results-live .match {
	display: none;
}

@media (min-width: 1200px) {
	.rd-search-results-live .search_link p {
		display: block;
	}
}

.rd-navbar-fixed-linked .rd-search-results-live {
	display: none;
}

.rd-search-results-live.active.cleared {
	opacity: 0;
	visibility: hidden;
	transition-delay: .08s;
}

.active .rd-search-results-live {
	display: block;
	opacity: 1;
	visibility: visible;
}

.rd-search-results .search_list {
	text-align: left;
	padding-left: 0;
	font-size: 14px;
	list-style-type: none;
	counter-reset: result;
}

.rd-search-results .result-item {
	position: relative;
	padding-left: 40px;
	color: #9f9f9f;
}

.rd-search-results .result-item:before {
	position: absolute;
	top: -1px;
	left: 0;
	content: counter(result, decimal-leading-zero) ".";
	counter-increment: result;
	font: 500 19px "Roboto", Helvetica, Arial, sans-serif;
	line-height: 1;
	color: #cdcdcd;
}

.rd-search-results .result-item:only-child:before {
	display: none;
}

.rd-search-results .search {
	color: #fff;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.rd-search-results .search_error .search {
	color: #9f9f9f;
	background-color: transparent;
}

.rd-search-results .match em {
	font: 700 12px/16px "Roboto", Helvetica, Arial, sans-serif;
	font-style: normal;
	text-transform: uppercase;
	color: #000;
}

.rd-search-results * + p {
	margin-top: 10px;
}

.rd-search-results * + .match {
	margin-top: 5px;
}

.rd-search-results * + .result-item {
	margin-top: 35px;
}

@media (min-width: 576px) {
	.rd-search-results .result-item {
		padding-left: 60px;
	}
	.rd-search-results .result-item:before {
		left: 15px;
		font-size: 19px;
	}
}

@media (min-width: 768px) {
	.rd-search-results .result-item:before {
		top: 0;
	}
}

@media (min-width: 992px) {
	.rd-search-results .result-item {
		padding-left: 85px;
	}
	.rd-search-results .result-item:before {
		top: 0;
		left: 40px;
	}
}

@media (min-width: 1200px) {
	.rd-search-results .result-item {
		padding-left: 100px;
	}
	.rd-search-results .result-item:before {
		left: 44px;
	}
}

.twitter-item-minimal .tweet-user {
	font-size: 16px;
	font-weight: 700;
}

.twitter-item-minimal .tweet-user a, .twitter-item-minimal .tweet-user a:active, .twitter-item-minimal .tweet-user a:focus {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.twitter-item-minimal .tweet-user a:hover {
	color: #000;
}

.twitter-item-minimal .tweet-user a:before {
	content: '-';
}

.twitter-item-minimal .tweet-text a, .twitter-item-minimal .tweet-text a:active, .twitter-item-minimal .tweet-text a:focus {
	color: #000;
}

.twitter-item-minimal .tweet-text a:hover {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.twitter-item-minimal * + .tweet-text {
	margin-top: 0;
}

.twitter-item-minimal * + .tweet-user {
	margin-top: 10px;
}

.twitter-item-minimal + .twitter-item-minimal {
	margin-top: 25px;
}

.twitter-widget {
	overflow: hidden;
	background: #fff;
	border-radius: 6px;
	box-shadow: -1px 0px 10px 0px rgba(65, 65, 65, 0.12);
}

.twitter-widget > a {
	display: block;
	color: #9f9f9f;
}

.twitter-widget .tweet-text a, .twitter-widget .tweet-text a:active, .twitter-widget .tweet-text a:focus {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.twitter-widget .tweet-text a:hover {
	color: #000;
}

.twitter-widget .twitter-widget-time {
	color: #9f9f9f;
}

.twitter-widget .twitter-widget-meta > * {
	line-height: 1.1;
}

.twitter-widget .twitter-widget-meta > * + * {
	margin-top: 5px;
}

.twitter-widget .twitter-widget-media {
	position: relative;
	z-index: 1;
	overflow: hidden;
}

.twitter-widget .twitter-widget-media > img {
	position: absolute;
	top: 0;
	right: 0;
	left: 0;
	min-height: 101%;
}

.twitter-widget .twitter-widget-media:empty {
	display: none;
}

.twitter-widget .twitter-widget-media:not(:empty) {
	padding-bottom: 42.5170068%;
}

.twitter-widget .tweet-avatar {
	display: block;
	width: 48px;
	height: 48px;
	background: #dedede;
}

.twitter-widget .twitter-widget-header {
	padding: 30px 30px 0 30px;
}

.twitter-widget .twitter-widget-inset {
	padding: 25px 30px 15px;
}

.twitter-widget .twitter-widget-footer {
	padding: 15px 30px;
}

* + .twitter-widget {
	margin-top: 30px;
}

/**
 * @subsection   Swiper 3.1.7
 * @description  Most modern mobile touch slider and framework with
 *               hardware accelerated transitions
 * @author       Vladimir Kharlampidi
 * @see          http://www.idangero.us/swiper/
 * @licesne      MIT License
 */
.swiper-container {
	margin: 0 auto;
	position: relative;
	overflow: hidden;
	/* Fix of Webkit flickering */
	z-index: 1;
	height: auto;
}

.swiper-container .swiper-wrapper {
	height: auto;
	min-height: 36.25vw;
}

@media (min-width: 1800px) {
	.swiper-container .swiper-wrapper {
		height: auto;
		min-height: 680px;
	}
}

.swiper-container-no-flexbox .swiper-slide {
	float: left;
}

.swiper-container-vertical > .swiper-wrapper {
	-webkit-box-orient: vertical;
	-moz-box-orient: vertical;
	-ms-flex-direction: column;
	-webkit-flex-direction: column;
	flex-direction: column;
}

.swiper-wrapper {
	position: relative;
	width: 100%;
	z-index: 1;
	display: -webkit-box;
	display: -moz-box;
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-transition-property: -webkit-transform;
	-moz-transition-property: -moz-transform;
	-o-transition-property: -o-transform;
	-ms-transition-property: -ms-transform;
	transition-property: transform;
	-webkit-box-sizing: content-box;
	-moz-box-sizing: content-box;
	box-sizing: content-box;
	-webkit-align-self: stretch;
	-ms-flex-item-align: stretch;
	align-self: stretch;
	-webkit-align-items: stretch;
	-ms-flex-align: stretch;
	align-items: stretch;
}

.swiper-container-android .swiper-slide,
.swiper-wrapper {
	-webkit-transform: translate3d(0px, 0, 0);
	-moz-transform: translate3d(0px, 0, 0);
	-o-transform: translate(0px, 0px);
	-ms-transform: translate3d(0px, 0, 0);
	transform: translate3d(0px, 0, 0);
}

.swiper-container-multirow > .swiper-wrapper {
	-webkit-box-lines: multiple;
	-moz-box-lines: multiple;
	-ms-flex-wrap: wrap;
	-webkit-flex-wrap: wrap;
	flex-wrap: wrap;
}

.swiper-container-free-mode > .swiper-wrapper {
	-webkit-transition-timing-function: ease-out;
	-moz-transition-timing-function: ease-out;
	-ms-transition-timing-function: ease-out;
	-o-transition-timing-function: ease-out;
	transition-timing-function: ease-out;
	margin: 0 auto;
}

.swiper-slide {
	position: relative;
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-flex-shrink: 0;
	-ms-flex: 0 0 auto;
	flex-shrink: 0;
	width: 100%;
	min-height: inherit;
}

/* a11y */
.swiper-container .swiper-notification {
	position: absolute;
	left: 0;
	top: 0;
	pointer-events: none;
	opacity: 0;
	z-index: -1000;
}

/* IE10 Windows Phone 8 Fixes */
.swiper-wp8-horizontal {
	-ms-touch-action: pan-y;
	touch-action: pan-y;
}

.swiper-wp8-vertical {
	-ms-touch-action: pan-x;
	touch-action: pan-x;
}

.swiper-nav {
	position: absolute;
	top: 50%;
	right: 0;
	left: 0;
	z-index: 10;
	pointer-events: none;
	transform: translateY(-50%);
}

/* Arrows */
.swiper-button-prev,
.swiper-button-next {
	z-index: 10;
	width: 48px;
	height: 48px;
	background: url("medias/image/<?php echo $website->ref; ?>/chevron-right.svg") no-repeat top left;
	background-size: 48px 48px;
	color: #fff;
	transition: 180ms ease-in-out;
	text-align: center;
	cursor: pointer;
	pointer-events: auto;
}

.swiper-button-prev:hover,
.swiper-button-next:hover {
	opacity: .7;
}

.swiper-button-prev.swiper-button-disabled,
.swiper-button-next.swiper-button-disabled {
	opacity: 0;
	cursor: auto;
	pointer-events: none;
}

.swiper-button-next {
	transform: rotate(180deg);
}

/* Pagination Styles */
.swiper-pagination-wrap {
	position: absolute;
	bottom: 20px;
	left: 50%;
	width: 100%;
	transform: translate3d(-50%, 0, 0);
	z-index: 10;
}

@media (min-width: 992px) {
	.swiper-pagination-wrap {
		bottom: 35px;
	}
}

@media (min-width: 1200px) {
	.swiper-pagination-wrap {
		bottom: 55px;
	}
}

.swiper-pagination {
	display: block;
	width: 100%;
	text-align: center;
	transition: 300ms;
	-webkit-transform: translate3d(0, 0, 0);
	transform: translate3d(0, 0, 0);
	z-index: 10;
}

@media (min-width: 768px) {
	.swiper-pagination {
		text-align: left;
	}
}

.swiper-pagination.swiper-pagination-hidden {
	opacity: 0;
}

.swiper-pagination-bullet {
	display: inline-block;
	width: 6px;
	height: 6px;
	border-radius: 20px;
	background: #cdcdcd;
	pointer-events: none;
	transition: all .2s ease-out;
}

.swiper-pagination-bullet + * {
	margin-left: 10px;
}

@media (min-width: 768px) {
	.swiper-pagination-bullet {
		width: 12px;
		height: 12px;
		pointer-events: auto;
	}
	.swiper-pagination-bullet + * {
		margin-left: 20px;
	}
}

.swiper-pagination-clickable .swiper-pagination-bullet {
	cursor: pointer;
}

.swiper-pagination-white .swiper-pagination-bullet {
	background: #fff;
}

.swiper-pagination-bullet:hover,
.swiper-pagination-bullet-active {
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.swiper-pagination-white .swiper-pagination-bullet-active {
	background: #fff;
}

.swiper-pagination-black .swiper-pagination-bullet-active {
	background: #000;
}

.swiper-container-vertical > .swiper-pagination {
	right: 10px;
	top: 50%;
	-webkit-transform: translate3d(0px, -50%, 0);
	-moz-transform: translate3d(0px, -50%, 0);
	-o-transform: translate(0px, -50%);
	-ms-transform: translate3d(0px, -50%, 0);
	transform: translate3d(0px, -50%, 0);
}

.swiper-container-vertical > .swiper-pagination .swiper-pagination-bullet {
	margin: 5px 0;
	display: block;
}

.swiper-container-horizontal > .swiper-pagination {
	bottom: 20px;
	left: 0;
	width: 100%;
}

.swiper-container-horizontal > .swiper-pagination .swiper-pagination-bullet {
	margin: 0 5px;
}

/* 3D Container */
.swiper-container-3d {
	-webkit-perspective: 1200px;
	-moz-perspective: 1200px;
	-o-perspective: 1200px;
	perspective: 1200px;
}

.swiper-container-3d .swiper-wrapper,
.swiper-container-3d .swiper-slide,
.swiper-container-3d .swiper-slide-shadow-left,
.swiper-container-3d .swiper-slide-shadow-right,
.swiper-container-3d .swiper-slide-shadow-top,
.swiper-container-3d .swiper-slide-shadow-bottom,
.swiper-container-3d .swiper-cube-shadow {
	-webkit-transform-style: preserve-3d;
	-moz-transform-style: preserve-3d;
	-ms-transform-style: preserve-3d;
	transform-style: preserve-3d;
}

.swiper-container-3d .swiper-slide-shadow-left,
.swiper-container-3d .swiper-slide-shadow-right,
.swiper-container-3d .swiper-slide-shadow-top,
.swiper-container-3d .swiper-slide-shadow-bottom {
	position: absolute;
	left: 0;
	top: 0;
	width: 100%;
	height: 100%;
	pointer-events: none;
	z-index: 10;
}

.swiper-container-3d .swiper-slide-shadow-left {
	background-image: linear-gradient(to left, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0));
}

.swiper-container-3d .swiper-slide-shadow-top {
	background-image: linear-gradient(to top, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0));
}

.swiper-container-3d .swiper-slide-shadow-bottom {
	background-image: linear-gradient(to bottom, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0));
}

/* Coverflow */
.swiper-container-coverflow .swiper-wrapper {
	/* Windows 8 IE 10 fix */
	-ms-perspective: 1200px;
}

/* Fade */
.swiper-container-fade.swiper-container-free-mode .swiper-slide {
	-webkit-transition-timing-function: ease-out;
	transition-timing-function: ease-out;
}

.swiper-container-fade .swiper-slide {
	pointer-events: none;
}

.swiper-container-fade .swiper-slide .swiper-slide {
	pointer-events: none;
}

.swiper-container-fade .swiper-slide-active,
.swiper-container-fade .swiper-slide-active .swiper-slide-active {
	pointer-events: auto;
}

/* Cube */
.swiper-container-cube {
	overflow: visible;
}

.swiper-container-cube .swiper-slide {
	pointer-events: none;
	visibility: hidden;
	-webkit-transform-origin: 0 0;
	-moz-transform-origin: 0 0;
	-ms-transform-origin: 0 0;
	transform-origin: 0 0;
	-webkit-backface-visibility: hidden;
	-moz-backface-visibility: hidden;
	-ms-backface-visibility: hidden;
	backface-visibility: hidden;
	width: 100%;
	height: 100%;
	z-index: 1;
}

.swiper-container-cube.swiper-container-rtl .swiper-slide {
	-webkit-transform-origin: 100% 0;
	-moz-transform-origin: 100% 0;
	-ms-transform-origin: 100% 0;
	transform-origin: 100% 0;
}

.swiper-container-cube .swiper-slide-active,
.swiper-container-cube .swiper-slide-next,
.swiper-container-cube .swiper-slide-prev,
.swiper-container-cube .swiper-slide-next + .swiper-slide {
	pointer-events: auto;
	visibility: visible;
}

.swiper-container-cube .swiper-slide-shadow-top,
.swiper-container-cube .swiper-slide-shadow-bottom,
.swiper-container-cube .swiper-slide-shadow-left,
.swiper-container-cube .swiper-slide-shadow-right {
	z-index: 0;
	-webkit-backface-visibility: hidden;
	-moz-backface-visibility: hidden;
	-ms-backface-visibility: hidden;
	backface-visibility: hidden;
}

.swiper-container-cube .swiper-cube-shadow {
	position: absolute;
	left: 0;
	bottom: 0px;
	width: 100%;
	height: 100%;
	background: #000;
	opacity: 0.6;
	-webkit-filter: blur(50px);
	filter: blur(50px);
	z-index: 0;
}

/* Scrollbar */
.swiper-scrollbar {
	position: relative;
	-ms-touch-action: none;
}

.swiper-container-horizontal > .swiper-scrollbar {
	position: absolute;
	top: 0;
	left: 0;
	z-index: 50;
	height: 5px;
	width: 100%;
}

.swiper-container-vertical > .swiper-scrollbar {
	position: absolute;
	right: 3px;
	top: 1%;
	z-index: 50;
	width: 5px;
	height: 98%;
}

.swiper-scrollbar-drag {
	height: 100%;
	width: 100%;
	position: relative;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
	left: 0;
	top: 0;
}

.swiper-scrollbar-cursor-drag {
	cursor: move;
}

/* Preloader */
.swiper-lazy-preloader {
	width: 42px;
	height: 42px;
	position: absolute;
	left: 50%;
	top: 50%;
	margin-left: -21px;
	margin-top: -21px;
	z-index: 10;
	-webkit-transform-origin: 50%;
	-moz-transform-origin: 50%;
	transform-origin: 50%;
	-webkit-animation: swiper-preloader-spin 1s steps(12, end) infinite;
	-moz-animation: swiper-preloader-spin 1s steps(12, end) infinite;
	animation: swiper-preloader-spin 1s steps(12, end) infinite;
}

.swiper-lazy-preloader:after {
	display: block;
	content: "";
	width: 100%;
	height: 100%;
	background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg%20viewBox%3D'0%200%20120%20120'%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20xmlns%3Axlink%3D'http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink'%3E%3Cdefs%3E%3Cline%20id%3D'l'%20x1%3D'60'%20x2%3D'60'%20y1%3D'7'%20y2%3D'27'%20stroke%3D'%236c6c6c'%20stroke-width%3D'11'%20stroke-linecap%3D'round'%2F%3E%3C%2Fdefs%3E%3Cg%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(30%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(60%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(90%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(120%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(150%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.37'%20transform%3D'rotate(180%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.46'%20transform%3D'rotate(210%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.56'%20transform%3D'rotate(240%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.66'%20transform%3D'rotate(270%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.75'%20transform%3D'rotate(300%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.85'%20transform%3D'rotate(330%2060%2C60)'%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E");
	background-position: 50%;
	-webkit-background-size: 100%;
	background-size: 100%;
	background-repeat: no-repeat;
}

.swiper-lazy-preloader-white:after {
	background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg%20viewBox%3D'0%200%20120%20120'%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20xmlns%3Axlink%3D'http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink'%3E%3Cdefs%3E%3Cline%20id%3D'l'%20x1%3D'60'%20x2%3D'60'%20y1%3D'7'%20y2%3D'27'%20stroke%3D'%23fff'%20stroke-width%3D'11'%20stroke-linecap%3D'round'%2F%3E%3C%2Fdefs%3E%3Cg%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(30%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(60%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(90%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(120%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(150%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.37'%20transform%3D'rotate(180%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.46'%20transform%3D'rotate(210%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.56'%20transform%3D'rotate(240%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.66'%20transform%3D'rotate(270%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.75'%20transform%3D'rotate(300%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.85'%20transform%3D'rotate(330%2060%2C60)'%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E");
}

@-webkit-keyframes swiper-preloader-spin {
	100% {
		-webkit-transform: rotate(360deg);
	}
}

@keyframes swiper-preloader-spin {
	100% {
		transform: rotate(360deg);
	}
}

.swiper-slide > .vide__body,
.swiper-slide > .parallax_cnt {
	height: 100%;
}

.swiper-slide {
	position: relative;
	text-align: center;
	white-space: nowrap;
	background-position: center center;
	overflow: hidden;
}

.swiper-slide:not(.vide):not(.rd-parallax):before,
.swiper-slide .parallax_cnt:before, .swiper-slide .vide__body:before {
	content: '';
	display: inline-block;
	height: 50%;
}

.swiper-slide-caption {
	display: inline-block;
	width: 100%;
	max-height: 100%;
	margin-left: -.25em;
	vertical-align: middle;
	white-space: normal;
	z-index: 1;
}

.swiper-variant-1, .swiper-variant-1 .swiper-wrapper {
	height: auto;
	min-height: calc(100vh - 56px);
}

.swiper-variant-1 .swiper-slide-caption {
	padding: 40px 0 40px;
}

.swiper-variant-1 .swiper-button-prev,
.swiper-variant-1 .swiper-button-next {
	display: none;
}

.swiper-variant-1 .slider-text {
	display: none;
}

.swiper-variant-1 .jumbotron-custom + * {
	margin-top: 5px;
}

.swiper-variant-1 * + .button-block {
	margin-top: 27px;
}

@media (min-width: 768px) {
	.swiper-variant-1, .swiper-variant-1 .swiper-wrapper {
		height: auto;
		min-height: 36.25vw;
	}
	.swiper-variant-1 .swiper-slide-caption {
		padding: 60px 0 115px;
	}
	.swiper-variant-1 .slider-header {
		font-size: 50px;
	}
	.swiper-variant-1 .slider-text {
		display: block;
	}
}

@media (min-width: 992px) {
	.swiper-variant-1 .swiper-slide-caption {
		padding: 100px 0 155px;
	}
	.swiper-variant-1 .swiper-button-prev,
	.swiper-variant-1 .swiper-button-next {
		position: absolute;
		top: 50%;
		transform: translateY(-59%);
		z-index: 10;
		display: block;
		transition: .3s all ease;
	}
	.swiper-variant-1 .swiper-button-prev {
		left: 5.1%;
		transform: scale(-1, 1);
	}
	.swiper-variant-1 .swiper-button-next {
		right: 5.1%;
	}
}

@media (min-width: 1200px) {
	.swiper-variant-1 .slider-header {
		font-size: 59px;
	}
	.swiper-variant-1 .swiper-button-prev {
		left: 20px;
	}
	.swiper-variant-1 .swiper-button-next {
		right: 20px;
	}
}

@media (min-width: 1599px) {
	.swiper-variant-1 .swiper-button-prev {
		left: calc(50vw - 1170px / 2 - 170px + (1170px / 12) * 0);
	}
	.swiper-variant-1 .swiper-button-next {
		right: calc(50vw - 1170px / 2 - 170px + (1170px / 12) * 0);
	}
}

@media (min-width: 1800px) {
	.swiper-variant-1, .swiper-variant-1 .swiper-wrapper {
		height: auto;
		min-height: 680px;
	}
}

/*
* @subsection   ToTop
* @license      MIT license - http://opensource.org/licenses/MIT
* @version      1.0.0
*/
.ui-to-top {
	width: 40px;
	height: 40px;
	font-size: 18px;
	line-height: 38px;
	border-radius: 50%;
	position: fixed;
	right: 15px;
	bottom: 15px;
	overflow: hidden;
	text-align: center;
	text-decoration: none;
	z-index: 20;
	transition: .3s all ease;
	box-shadow: 0 0 1px 0px rgba(55, 195, 134, 0.3);
	transform: translateY(100px);
}

.ui-to-top, .ui-to-top:active, .ui-to-top:focus {
	color: #fff;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.ui-to-top:hover {
	color: #fff;
	background: <?php echo empty($website->maincolorbis) ? '#6ca' : '#'.$website->maincolorbis; ?>;
	box-shadow: 0 0 1px 0px rgba(0, 0, 0, 0.4);
}

.ui-to-top:focus {
	outline: 0;
}

.ui-to-top.active {
	transform: translateY(0);
}

.mobile .ui-to-top,
.tablet .ui-to-top {
	display: none !important;
}

@media (min-width: 576px) {
	.ui-to-top {
		right: 40px;
		bottom: 40px;
	}
}

/*
* @subsection   Progress Bar
*/
.progress-bar-wrap {
	max-width: 100%;
	width: 210px;
}

@media (min-width: 576px) and (max-width: 767px) {
	.progress-bar-wrap {
		max-width: 120px;
	}
}

@media (min-width: 768px) {
	.progress-bar-wrap {
		max-width: 150px;
	}
}

.progress-bar {
	position: relative;
	width: 100%;
	margin: 0;
	font-family: "Roboto", Helvetica, Arial, sans-serif;
}

.progress-bar .progress-bar__body {
	position: absolute;
	right: 50%;
	width: 100%;
	top: 50%;
	padding: 0;
	margin: 0;
	white-space: nowrap;
	font-size: 34px;
	font-weight: 400;
	line-height: 26px;
	color: #00030a;
	text-align: right;
}

.progress-bar .progress-bar__body:after {
	content: '%';
}

.progress-bar .progress-bar__stroke,
.progress-bar .progress-bar__trail {
	stroke-linejoin: round;
}

.progress-bar-horizontal {
	position: relative;
	font-family: "Roboto", Helvetica, Arial, sans-serif;
	text-align: right;
}

.progress-bar-horizontal > svg {
	margin-top: 3px;
	border-radius: 3px;
}

.progress-bar-horizontal .progress-bar__body {
	position: absolute;
	top: -27px;
	margin-top: 0;
	padding-right: 0;
}

.progress-bar-horizontal .progress-bar__body:after {
	content: '%';
}

.progress-bar-radial {
	position: relative;
	padding-bottom: 100%;
}

.progress-bar-radial > svg {
	position: absolute;
	width: 100%;
	height: 100%;
	left: 0;
	top: 0;
	border-radius: 5px;
	overflow: hidden;
}

.progress-bar-radial .progress-bar__stroke,
.progress-bar-radial .progress-bar__trail {
	stroke-location: outside;
}

.progress-bar-radial .progress-bar__body {
	transform: translate(50%, -50%);
}

.progress-bar-default .progress-bar__stroke {
	stroke: #9f9f9f;
}

.progress-bar-default .progress-bar__trail {
	stroke: rgba(159, 159, 159, 0.05);
}

.progress-bar-primary .progress-bar__stroke {
	stroke: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.progress-bar-primary .progress-bar__trail {
	stroke: #F8F9FB;
}

.progress-bar-bermuda-gray .progress-bar__stroke {
	stroke: #6f8fad;
}

.progress-bar-bermuda-gray .progress-bar__trail {
	stroke: #F8F9FB;
}

.progress-bar-contessa .progress-bar__stroke {
	stroke: #e76752;
}

.progress-bar-contessa .progress-bar__trail {
	stroke: #F8F9FB;
}

.progress-bar-red-orange-1 .progress-bar__stroke {
	stroke: #f8333c;
}

.progress-bar-red-orange-1 .progress-bar__trail {
	stroke: #ededed;
}

.progress-bar-dodger-blue .progress-bar__stroke {
	stroke: #45a4ff;
}

.progress-bar-dodger-blue .progress-bar__trail {
	stroke: #ededed;
}

.progress-bar-gorse .progress-bar__stroke {
	stroke: #fde74c;
}

.progress-bar-gorse .progress-bar__trail {
	stroke: #ededed;
}

.progress-bar-old-gold .progress-bar__stroke {
	stroke: #ecd746;
}

.progress-bar-old-gold .progress-bar__trail {
	stroke: #F8F9FB;
}

.progress-bar-secondary-2 .progress-bar__stroke {
	stroke: #dedede;
}

.progress-bar-secondary-2 .progress-bar__trail {
	stroke: gray;
}

.progress-bar-secondary-1 .progress-bar__stroke {
	stroke: #dedede;
}

.progress-bar-secondary-1 .progress-bar__trail {
	stroke: rgba(159, 159, 159, 0.05);
}

.progress-bar-secondary-3 .progress-bar__stroke {
	stroke: #c49558;
}

.progress-bar-secondary-3 .progress-bar__trail {
	stroke: rgba(159, 159, 159, 0.05);
}

.progress-bar-secondary-4 .progress-bar__stroke {
	stroke: #fe4a21;
}

.progress-bar-secondary-4 .progress-bar__trail {
	stroke: rgba(159, 159, 159, 0.05);
}


.countdown-wrap {
	max-width: 720px;
	max-height: 134px;
}

.countdown-wrap .time_circles > div {
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-flex-direction: column-reverse;
	-ms-flex-direction: column-reverse;
	flex-direction: column-reverse;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-justify-content: center;
	-ms-flex-pack: center;
	justify-content: center;
	font-size: 0;
	line-height: 0;
}

.countdown-wrap div > h4 {
	position: relative;
	margin-top: -2px;
	font: 500 12px "Roboto", Helvetica, Arial, sans-serif !important;
	color: rgba(0, 0, 0, 0.2);
	letter-spacing: -.025em;
	bottom: auto !important;
	text-transform: uppercase;
}

@media (min-width: 576px) {
	.countdown-wrap div > h4 {
		font-size: 14px !important;
	}
}

.countdown-wrap span {
	font: 900 18px "Roboto", Helvetica, Arial, sans-serif !important;
	font-style: normal;
	color: #000;
}

@media (min-width: 576px) {
	.countdown-wrap span {
		font-size: 40px !important;
	}
}

@media (min-width: 768px) {
	.countdown-wrap span {
		font-size: 45px !important;
		line-height: 1;
	}
}

.slick-slider {
	position: relative;
	display: block;
	-moz-box-sizing: border-box;
	box-sizing: border-box;
	-webkit-touch-callout: none;
	-webkit-user-select: none;
	-khtml-user-select: none;
	-moz-user-select: none;
	-ms-user-select: none;
	user-select: none;
	-ms-touch-action: pan-y;
	touch-action: pan-y;
	-webkit-tap-highlight-color: transparent;
}

.slick-list {
	position: relative;
	overflow: hidden;
	display: block;
	margin: 0;
	padding: 0;
}

.slick-list:focus {
	outline: none;
}

.slick-list.dragging {
	cursor: pointer;
	cursor: hand;
}

.slick-slider .slick-track,
.slick-slider .slick-list {
	-webkit-transform: translate3d(0, 0, 0);
	-moz-transform: translate3d(0, 0, 0);
	-ms-transform: translate3d(0, 0, 0);
	-o-transform: translate3d(0, 0, 0);
	transform: translate3d(0, 0, 0);
}

.slick-track {
	position: relative;
	left: 0;
	top: 0;
	display: block;
}

.slick-track:before, .slick-track:after {
	content: "";
	display: table;
}

.slick-track:after {
	clear: both;
}

.slick-loading .slick-track {
	visibility: hidden;
}

.slick-slide {
	float: left;
	min-height: 1px;
	display: none;
}

[dir="rtl"] .slick-slide {
	float: right;
}

.slick-slide img {
	display: block;
}

.slick-slide.slick-loading img {
	display: none;
}

.slick-slide.dragging img {
	pointer-events: none;
}

.slick-initialized .slick-slide {
	display: block;
}

.slick-loading .slick-slide {
	visibility: hidden;
}

.slick-vertical .slick-slide {
	display: block;
	height: auto;
	border: 1px solid transparent;
}

.slick-arrow.slick-hidden {
	display: none;
}

.slick-loading .slick-list {
	background: #fff url("medias/image/<?php echo $website->ref; ?>/ajax-loading.gif") center center no-repeat;
}

/* Icons */
/* Arrows */
.slick-prev,
.slick-next {
	position: absolute;
	display: block;
	height: 20px;
	width: 20px;
	line-height: 0;
	font-size: 0;
	cursor: pointer;
	background: rgba(0, 0, 0, 0.6);
	color: transparent;
	top: 50%;
	-webkit-transform: translate(0, -50%);
	-ms-transform: translate(0, -50%);
	transform: translate(0, -50%);
	padding: 0;
	border: none;
	outline: none;
	z-index: 999;
}

.slick-prev:hover, .slick-prev:focus,
.slick-next:hover,
.slick-next:focus {
	outline: none;
	background: transparent;
	color: transparent;
}

.slick-prev:hover:before, .slick-prev:focus:before,
.slick-next:hover:before,
.slick-next:focus:before {
	opacity: 1;
}

.slick-prev.slick-disabled:before,
.slick-next.slick-disabled:before {
	opacity: 0.25;
}

.slick-prev:before, .slick-next:before {
	font-family: "Roboto", Helvetica, Arial, sans-serif;
	font-size: 20px;
	line-height: 1;
	color: white;
	opacity: 0.75;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
}

.slick-prev {
	left: 0;
}

[dir="rtl"] .slick-prev {
	left: auto;
	right: 0;
}

.slick-prev:before {
	content: "←";
}

[dir="rtl"] .slick-prev:before {
	content: "→";
}

.slick-next {
	right: 0;
}

[dir="rtl"] .slick-next {
	left: 0;
	right: auto;
}

.slick-next:before {
	content: "→";
}

[dir="rtl"] .slick-next:before {
	content: "←";
}

/* Dots */
.slick-slider {
	margin-top: 30px;
}

.slick-slider *:focus {
	outline: 0;
}

.slick-dots {
	display: block;
	margin-top: 20px;
	list-style: none;
	width: 100%;
	padding: 0;
	text-align: center;
	font-size: 0;
	line-height: 0;
	word-spacing: 0;
}

.slick-dots li {
	position: relative;
	display: inline-block;
	height: 20px;
	width: 20px;
	margin: 0 5px;
	padding: 0;
	cursor: pointer;
}

.slick-dots li button {
	background: none;
	border: none;
	display: inline-block;
	padding: 0;
	outline: none;
	outline-offset: 0;
	cursor: pointer;
	-webkit-appearance: none;
	width: 8px;
	height: 8px;
	border-radius: 100px;
	background: #ababab;
}

.slick-dots li button::-moz-focus-inner {
	border: none;
	padding: 0;
}

.slick-dots li.slick-active button,
.slick-dots li:hover button {
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.slick-dots-variant-1 .slick-dots li button {
	height: 12px;
	width: 12px;
	background: rgba(58, 60, 62, 0.5);
	transition: .33s all ease;
	position: relative;
}

.slick-dots-variant-1 .slick-dots li button:after {
	content: '';
	position: absolute;
	top: 50%;
	left: 50%;
	width: 19px;
	height: 19px;
	border: 4px solid #fff;
	opacity: 0;
	border-radius: 50%;
	-webkit-transform: translate(-50%, -50%) scale(0);
	transform: translate(-50%, -50%) scale(0);
	transition: 180ms ease-in-out;
}

.slick-dots-variant-1 .slick-dots li.slick-active button,
.slick-dots-variant-1 .slick-dots li:hover button {
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.slick-dots-variant-1 .slick-dots li.slick-active button:after,
.slick-dots-variant-1 .slick-dots li:hover button:after {
	opacity: 1;
	-webkit-transform: translate(-50%, -50%) scale(1);
	transform: translate(-50%, -50%) scale(1);
}

.slick-carousel-complex-variant-1 {
	position: relative;
	padding-bottom: 60px;
}

.slick-carousel-complex-variant-1:after {
	content: '';
	position: absolute;
	top: 80px;
	left: 50%;
	bottom: 0;
	transform: translateX(-50%);
	width: 101vw;
	background: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;
}

.slick-carousel-complex-variant-1 > * {
	position: relative;
	z-index: 2;
}

.slick-carousel-complex-variant-1 .slick-slider {
	margin-bottom: 0;
}

.slick-carousel-complex-variant-1 .slick-dots {
	margin-top: 30px;
}

@media (min-width: 768px) {
	.slick-carousel-complex-variant-1 {
		padding-bottom: 90px;
	}
}

.slick-slider-images .item {
	padding: 0 15px;
	text-align: right;
}

.slick-slider-images .item img {
	display: inline-block;
	transform: scale(0.75);
	transform-origin: 100% 50%;
	will-change: transform;
	cursor: pointer;
	transition: .5s all ease;
}

.slick-slider-images .item.slick-center {
	text-align: center;
}

.slick-slider-images .item.slick-center img {
	transform-origin: 50% 50%;
	transform: scale(1);
}

.slick-slider-images .item.slick-center + * {
	text-align: left;
}

.slick-slider-images .item.slick-center + * img {
	transform-origin: 0 50%;
}

.slick-carousel-round-image .item img {
	border-radius: 50%;
}

.carousel-testimonials-home .slick-slide {
	text-align: center;
}


#sectiontestimonies.maincolorbackground {
    background-image: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>;;
}


@media (min-width: 576px) {
	.carousel-testimonials-home .slick-slide {
		text-align: left;
	}
}

.carousel-testimonials-home .slick-dots li button {
	background: rgba(246, 247, 250, 0.5);
}

.carousel-testimonials-home .item {
	padding-left: 10px;
	padding-right: 10px;
}

@media (min-width: 1200px) {
	.carousel-testimonials-home .item {
		padding-left: 0;
		padding-right: 0;
	}
}

@media (min-width: 576px) {
	.carousel-testimonials-home .slick-dots {
		display: none !important;
	}
}

.carousel-testimonials-home .slick-images .item {
	padding-left: 0;
	padding-right: 0;
}

.carousel-testimonials-home .slick-images .item .imp-wrap {
	text-align: center;
	position: relative;
	padding: 10px;
}

.carousel-testimonials-home .slick-images .item .imp-wrap:after {
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%) scale(0);
	content: '';
	display: inline-block;
	margin-left: 0px;
	border: 1px solid #fccb56;
	width: 116px;
	height: 116px;
	border-radius: 50%;
	transition: 200ms ease-in-out;
	opacity: 0;
	pointer-events: none;
}

.carousel-testimonials-home .slick-images .item .imp-wrap img {
	display: inline-block;
	border-radius: 50%;
	cursor: pointer;
}

.carousel-testimonials-home .slick-images .item:hover .imp-wrap:after,
.carousel-testimonials-home .slick-images .item.slick-current .imp-wrap:after {
	transform: translate(-50%, -50%) scale(1);
	opacity: 1;
}

.carousel-testimonials-home .quote-desc {
	-webkit-justify-content: center;
	-ms-flex-pack: center;
	justify-content: center;
}





/*
 * bodywebsite
 */



#bodywebsite .websitemaincolor {
	color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>
}
#bodywebsite .maincolor {
    color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>
}
#bodywebsite .maincolorbis {
    color: <?php echo empty($website->maincolorbis) ? '#6ca' : '#'.$website->maincolorbis; ?>;
}
#bodywebsite .maincolorbackground {
    background-color: <?php echo empty($website->maincolor) ? 'rgb(50, 120, 180)' : '#'.$website->maincolor; ?>
}
#bodywebsite .maincolorbisbackground {
    background-color: <?php echo empty($website->maincolorbis) ? '#6ca' : '#'.$website->maincolorbis; ?>;
    border-color: <?php echo empty($website->maincolorbis) ? '#6ca' : '#'.$website->maincolorbis; ?>;
}
#bodywebsite .maincolorbisbackground:hover {
    box-shadow: 1px 1px 8px #aaa;
}
#bodywebsite textarea:focus, .bodywebsite button:focus {
	border: unset !important;
}
#bodywebsite .marginrightonly {
	margin-right: 10px !important;
}
#bodywebsite .inline-block {
    display: inline-block;    
}
#bodywebsite .valignmiddle {
    vertical-align: middle;
}
#bodywebsite .center {
    text-align: center;
}
#bodywebsite input.form-input:focus, select.form-input:focus {
    border-bottom: none;
}
#bodywebsite button.buttonwithnoborder.toggle-original.active {
    display: none;
}
#bodywebsite .rd-navbar-nav-wrap.active .toggle-original span.icon.icon-xs.icon-dusty-gray.fa.fa-search {
    display: none;
}
#bodywebsite ul.rd-navbar-list {
    padding-top: 20px;
}
#bodywebsite .photouser:hover, #bodywebsite .photouser:active {
    border: 2px solid #eee;
}
#bodywebsite .imp-wrap {
    display: inline-block;
}
#bodywebsite .imp-wrap img {
    border-radius: 50px;
}
#bodywebsite .text-green {
    color: #6ca;
}

#bodywebsite .plan-tile .plan-title {
    padding: 20px 0 0;
    font-size: 20px;
    font-weight: bold;
    text-align: center;
}

#bodywebsite .plan-tile .plan-tag {
    color: #687484;
    text-align: center;
    font-size: 16px;
    padding: 0 5px 10px;
    font-weight: 300;
    min-height: 70px;
}

#bodywebsite .plan-tile .plan-pricer .plan-price-title {
    display: block;
    text-align: center;
    color: #8492A6;
    font-style: italic;
    position: absolute;
    top: 30px;
    transform: translateX(-50%);
    -webkit-transform: translateX(-50%);
    left: 50%;
    font-size: 16px;
    width: 100%;
    font-weight: 300;
}

#bodywebsite .plan-tile .plan-feat {
    display: block;
    font-size: 14px;
    color: #3C4858;
    text-align: center;
    padding: 22px 10px;
    min-height: 90px;
}

#bodywebsite .plan-tile .plan-pricer .plan-price {
    border-bottom: 1px solid #d5dadf;
    border-top: 1px solid #d5dadf;
    padding: 20px 0 20px;
    display: block;
}

#bodywebsite .plan-tile .plan-pricer .plan-price>span {
    color: #3C4858;
    font-size: 32px;
}
#bodywebsite .plan-tile .plan-pricer .plan-price>span>sup {
    font-size: 13px;
    top: -0.9em;
}

#bodywebsite .plan-tile .plan-pricer {
    padding: 5px 0;
    text-align: center;
    max-width: 90%;
    position: relative;
    margin: auto;
}

#bodywebsite .pricing-plan-slider .plan-tile .plan-btn {
    position: absolute;
    bottom: 0px;
    left: 0;
    width: 100%;
}

#bodywebsite .plan-tile .plan-btn {
    text-align: center;
    padding: 0 15px 15px 15px;
}

#bodywebsite .plan-features {
    padding-top: 20px;
    padding-bottom: 20px;
}

#bodywebsite .formcontact div {
    margin: 2px;
}

#bodywebsite section#sectionfooterdolibarr {
    padding-left: 3px;
    padding-right: 3px;
}

#bodywebsite button.buttonwithnoborder.toggle-original {
    font: 400 18px/36px "FontAwesome";  /* If removed, the search icon is not visible */
}

#bodywebsite .rd-navbar-fixed .buttonsearchwhenstatic {
    display: none;
}



/*
 * Bootstrap v4.0.0-beta (https://getbootstrap.com)
 * Copyright 2011-2017 The Bootstrap Authors
 * Copyright 2011-2017 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 */

@media print {
	*,
	*::before,
	*::after {
		text-shadow: none !important;
		box-shadow: none !important;
	}
	a,
	a:visited {
		text-decoration: underline;
	}
	abbr[title]::after {
		content: " (" attr(title) ")";
	}
	pre {
		white-space: pre-wrap !important;
	}
	pre,
	blockquote {
		border: 1px solid #999;
		page-break-inside: avoid;
	}
	thead {
		display: table-header-group;
	}
	tr,
	img {
		page-break-inside: avoid;
	}
	p,
	h2,
	h3 {
		orphans: 3;
		widows: 3;
	}
	h2,
	h3 {
		page-break-after: avoid;
	}
	.navbar {
		display: none;
	}
	.badge {
		border: 1px solid #000;
	}
	.table {
		border-collapse: collapse !important;
	}
	.table td,
	.table th {
		background-color: #fff !important;
	}
	.table-bordered th,
	.table-bordered td {
		border: 1px solid #ddd !important;
	}
}

/* @CHANGE Add #bodywebsite */
#bodywebsite *,
#bodywebsite *::before,
#bodywebsite *::after {
	box-sizing: border-box;
}

#bodywebsite html {
	font-family: sans-serif;
	line-height: 1.15;
	-webkit-text-size-adjust: 100%;
	-ms-text-size-adjust: 100%;
	-ms-overflow-style: scrollbar;
	-webkit-tap-highlight-color: rgba(0, 0, 0, 0);
}

@-ms-viewport {
	width: device-width;
}

article, aside, dialog, figcaption, figure, footer, header, hgroup, main, nav, section {
	display: block;
}

#bodywebsite {
	margin: 0;
	font-family: "Roboto", Helvetica, Arial, sans-serif;
	font-size: 14px;
	font-weight: 400;
	line-height: 1.71429;
	text-align: left;
	background-color: #fff;
}

[tabindex="-1"]:focus {
	outline: none !important;
}

hr {
	box-sizing: content-box;
	height: 0;
	overflow: visible;
}

h1, h2, h3, h4, h5, h6 {
	margin-top: 0;
	margin-bottom: 0.5rem;
}

p {
	margin-top: 0;
	margin-bottom: 1rem;
}

abbr[title],
abbr[data-original-title] {
	text-decoration: underline;
	text-decoration: underline dotted;
	cursor: help;
	border-bottom: 0;
}

address {
	margin-bottom: 1rem;
	font-style: normal;
	line-height: inherit;
}

#bodywebsite ol,
#bodywebsite ul,
#bodywebsite dl {
	margin-top: 0;
}

ol ol,
ul ul,
ol ul,
ul ol {
	margin-bottom: 0;
}

dt {
	font-weight: inherit;
}

dd {
	margin-bottom: .5rem;
	margin-left: 0;
}

blockquote {
	margin: 0 0 1rem;
}

dfn {
	font-style: italic;
}

b,
strong {
	font-weight: bolder;
}

small {
	font-size: 80%;
}

sub,
sup {
	position: relative;
	font-size: 75%;
	line-height: 0;
	vertical-align: baseline;
}

sub {
	bottom: -.25em;
}

sup {
	top: -.5em;
}

#bodywebsite a {
	text-decoration: none;
	-webkit-text-decoration-skip: objects;
}

#bodywebsite a:hover {
	text-decoration: none;
}

#bodywebsite a:not([href]):not([tabindex]) {
	color: inherit;
	text-decoration: none;
}

#bodywebsite a:not([href]):not([tabindex]):focus, a:not([href]):not([tabindex]):hover {
	color: inherit;
	text-decoration: none;
}

#bodywebsite a:not([href]):not([tabindex]):focus {
	outline: 0;
}

pre,
code,
kbd,
samp {
	font-family: monospace, monospace;
	font-size: 1em;
}

pre {
	margin-top: 0;
	margin-bottom: 1rem;
	overflow: auto;
	-ms-overflow-style: scrollbar;
}

figure {
	margin: 0 0 1rem;
}

img {
	vertical-align: middle;
	border-style: none;
}

svg:not(:root) {
	overflow: hidden;
}

a,
area,
button,
[role="button"],
input:not([type="range"]),
label,
select,
summary,
textarea {
	touch-action: manipulation;
}

table {
	border-collapse: collapse;
}

caption {
	padding-top: 17px 25px 18px;
	padding-bottom: 17px 25px 18px;
	color: #dedede;
	text-align: left;
	caption-side: bottom;
}

th {
	text-align: inherit;
}

label {
	display: inline-block;
	margin-bottom: .5rem;
}

button {
	border-radius: 0;
}

button:focus {
	outline: 1px dotted;
	outline: 5px auto -webkit-focus-ring-color;
}

input,
button,
select,
optgroup,
textarea {
	margin: 0;
	font-family: inherit;
	font-size: inherit;
	line-height: inherit;
}

button,
input {
	overflow: visible;
}

button,
select {
	text-transform: none;
}

button,
html [type="button"],
[type="reset"],
[type="submit"] {
	-webkit-appearance: button;
}

button::-moz-focus-inner,
[type="button"]::-moz-focus-inner,
[type="reset"]::-moz-focus-inner,
[type="submit"]::-moz-focus-inner {
	padding: 0;
	border-style: none;
}

input[type="radio"],
input[type="checkbox"] {
	box-sizing: border-box;
	padding: 0;
}

input[type="date"],
input[type="time"],
input[type="datetime-local"],
input[type="month"] {
	-webkit-appearance: listbox;
}

textarea {
	overflow: auto;
	resize: vertical;
}

fieldset {
	min-width: 0;
	padding: 0;
	margin: 0;
	border: 0;
}

legend {
	display: block;
	width: 100%;
	max-width: 100%;
	padding: 0;
	margin-bottom: .5rem;
	font-size: 1.5rem;
	line-height: inherit;
	color: inherit;
	white-space: normal;
}

progress {
	vertical-align: baseline;
}

[type="number"]::-webkit-inner-spin-button,
[type="number"]::-webkit-outer-spin-button {
	height: auto;
}

[type="search"] {
	outline-offset: -2px;
	-webkit-appearance: none;
}

[type="search"]::-webkit-search-cancel-button,
[type="search"]::-webkit-search-decoration {
	-webkit-appearance: none;
}

::-webkit-file-upload-button {
	font: inherit;
	-webkit-appearance: button;
}

output {
	display: inline-block;
}

summary {
	display: list-item;
}

template {
	display: none;
}

[hidden] {
	display: none !important;
}

h1, h2, h3, h4, h5, h6,
.h1, .h2, .h3, .h4, .h5, .h6 {
	margin-bottom: 0.5rem;
	font-family: "Roboto", Helvetica, Arial, sans-serif;
	font-weight: 700;
	line-height: 1.1;
	color: #000;
}

h1, .h1 {
	font-size: 104px;
}

h2, .h2 {
	font-size: 59px;
}

h3, .h3 {
	font-size: 45px;
}

h4, .h4 {
	font-size: 24px;
}

h5, .h5 {
	font-size: 33px;
}

h6, .h6 {
	font-size: 18px;
}

.lead {
	font-size: 24px;
	font-weight: 300;
}

.display-1 {
	font-size: 6rem;
	font-weight: 300;
	line-height: 1.2;
}

.display-2 {
	font-size: 5.5rem;
	font-weight: 300;
	line-height: 1.2;
}

.display-3 {
	font-size: 4.5rem;
	font-weight: 300;
	line-height: 1.2;
}

.display-4 {
	font-size: 3.5rem;
	font-weight: 300;
	line-height: 1.2;
}

hr {
	margin-top: 1rem;
	margin-bottom: 1rem;
	border: 0;
	border-top: 1px solid #2a2b2b;
}

small,
.small {
	font-size: 80%;
	font-weight: 400;
}

mark,
.mark {
	padding: 5px 10px;
	background-color: #37c386;
}

.list-unstyled {
	padding-left: 0;
	list-style: none;
}

.list-inline {
	padding-left: 0;
	list-style: none;
}

.list-inline-item {
	display: inline-block;
}

.list-inline-item:not(:last-child) {
	margin-right: 5px;
}

.initialism {
	font-size: 90%;
	text-transform: uppercase;
}

.blockquote {
	margin-bottom: 1rem;
	font-size: 17.5px;
}

.blockquote-footer {
	display: block;
	font-size: 80%;
	color: #dedede;
}

.blockquote-footer::before {
	content: "\2014 \00A0";
}

.img-fluid {
	max-width: 100%;
	height: auto;
}

code,
kbd,
pre,
samp {
	font-family: Menlo, Monaco, Consolas, "Courier New", monospace;
}

code {
	padding: 10px 5px;
	font-size: 90%;
	color: #00030a;
	background-color: #edeff4;
	border-radius: 0;
}

a > code {
	padding: 0;
	color: inherit;
	background-color: inherit;
}

kbd {
	padding: 10px 5px;
	font-size: 90%;
	color: #fff;
	background-color: #212529;
	border-radius: 3px;
	box-shadow: inset 0 -0.1rem 0 rgba(0, 0, 0, 0.25);
}

kbd kbd {
	padding: 0;
	font-size: 100%;
	font-weight: 700;
	box-shadow: none;
}

pre {
	display: block;
	margin-top: 0;
	margin-bottom: 1rem;
	font-size: 90%;
	color: #212529;
}

pre code {
	padding: 0;
	font-size: inherit;
	color: inherit;
	background-color: transparent;
	border-radius: 0;
}

.pre-scrollable {
	max-height: 340px;
	overflow-y: scroll;
}

.container {
	width: 100%;
	padding-right: 15px;
	padding-left: 15px;
	margin-right: auto;
	margin-left: auto;
}

@media (min-width: 576px) {
	.container {
		max-width: 540px;
	}
}

@media (min-width: 768px) {
	.container {
		max-width: 720px;
	}
}

@media (min-width: 992px) {
	.container {
		max-width: 960px;
	}
}

@media (min-width: 1200px) {
	.container {
		max-width: 1170px;
	}
}

.container-fluid {
	width: 100%;
	padding-right: 15px;
	padding-left: 15px;
	margin-right: auto;
	margin-left: auto;
}

.row {
	display: flex;
	flex-wrap: wrap;
	margin-right: -15px;
	margin-left: -15px;
}

.no-gutters {
	margin-right: 0;
	margin-left: 0;
}

.no-gutters > .col,
.no-gutters > [class*="col-"] {
	padding-right: 0;
	padding-left: 0;
}

.col-1, .col-2, .col-3, .col-4, .col-5, .col-6, .col-7, .col-8, .col-9, .col-10, .col-11, .col-12, .col,
.col-auto, .col-sm-1, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm,
.col-sm-auto, .col-md-1, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-md-10, .col-md-11, .col-md-12, .col-md,
.col-md-auto, .col-lg-1, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg,
.col-lg-auto, .col-xl-1, .col-xl-2, .col-xl-3, .col-xl-4, .col-xl-5, .col-xl-6, .col-xl-7, .col-xl-8, .col-xl-9, .col-xl-10, .col-xl-11, .col-xl-12, .col-xl,
.col-xl-auto, .col-xxl-1, .col-xxl-2, .col-xxl-3, .col-xxl-4, .col-xxl-5, .col-xxl-6, .col-xxl-7, .col-xxl-8, .col-xxl-9, .col-xxl-10, .col-xxl-11, .col-xxl-12, .col-xxl,
.col-xxl-auto {
	position: relative;
	width: 100%;
	min-height: 1px;
	padding-right: 15px;
	padding-left: 15px;
}

.col {
	flex-basis: 0;
	flex-grow: 1;
	max-width: 100%;
}

.col-auto {
	flex: 0 0 auto;
	width: auto;
	max-width: none;
}

.col-1 {
	flex: 0 0 8.33333%;
	max-width: 8.33333%;
}

.col-2 {
	flex: 0 0 16.66667%;
	max-width: 16.66667%;
}

.col-3 {
	flex: 0 0 25%;
	max-width: 25%;
}

.col-4 {
	flex: 0 0 33.33333%;
	max-width: 33.33333%;
}

.col-5 {
	flex: 0 0 41.66667%;
	max-width: 41.66667%;
}

.col-6 {
	flex: 0 0 50%;
	max-width: 50%;
}

.col-7 {
	flex: 0 0 58.33333%;
	max-width: 58.33333%;
}

.col-8 {
	flex: 0 0 66.66667%;
	max-width: 66.66667%;
}

.col-9 {
	flex: 0 0 75%;
	max-width: 75%;
}

.col-10 {
	flex: 0 0 83.33333%;
	max-width: 83.33333%;
}

.col-11 {
	flex: 0 0 91.66667%;
	max-width: 91.66667%;
}

.col-12 {
	flex: 0 0 100%;
	max-width: 100%;
}

.order-first {
	order: -1;
}

.order-1 {
	order: 1;
}

.order-2 {
	order: 2;
}

.order-3 {
	order: 3;
}

.order-4 {
	order: 4;
}

.order-5 {
	order: 5;
}

.order-6 {
	order: 6;
}

.order-7 {
	order: 7;
}

.order-8 {
	order: 8;
}

.order-9 {
	order: 9;
}

.order-10 {
	order: 10;
}

.order-11 {
	order: 11;
}

.order-12 {
	order: 12;
}

.offset-1 {
	margin-left: 8.33333%;
}

.offset-2 {
	margin-left: 16.66667%;
}

.offset-3 {
	margin-left: 25%;
}

.offset-4 {
	margin-left: 33.33333%;
}

.offset-5 {
	margin-left: 41.66667%;
}

.offset-6 {
	margin-left: 50%;
}

.offset-7 {
	margin-left: 58.33333%;
}

.offset-8 {
	margin-left: 66.66667%;
}

.offset-9 {
	margin-left: 75%;
}

.offset-10 {
	margin-left: 83.33333%;
}

.offset-11 {
	margin-left: 91.66667%;
}

@media (min-width: 576px) {
	.col-sm {
		flex-basis: 0;
		flex-grow: 1;
		max-width: 100%;
	}
	.col-sm-auto {
		flex: 0 0 auto;
		width: auto;
		max-width: none;
	}
	.col-sm-1 {
		flex: 0 0 8.33333%;
		max-width: 8.33333%;
	}
	.col-sm-2 {
		flex: 0 0 16.66667%;
		max-width: 16.66667%;
	}
	.col-sm-3 {
		flex: 0 0 25%;
		max-width: 25%;
	}
	.col-sm-4 {
		flex: 0 0 33.33333%;
		max-width: 33.33333%;
	}
	.col-sm-5 {
		flex: 0 0 41.66667%;
		max-width: 41.66667%;
	}
	.col-sm-6 {
		flex: 0 0 50%;
		max-width: 50%;
	}
	.col-sm-7 {
		flex: 0 0 58.33333%;
		max-width: 58.33333%;
	}
	.col-sm-8 {
		flex: 0 0 66.66667%;
		max-width: 66.66667%;
	}
	.col-sm-9 {
		flex: 0 0 75%;
		max-width: 75%;
	}
	.col-sm-10 {
		flex: 0 0 83.33333%;
		max-width: 83.33333%;
	}
	.col-sm-11 {
		flex: 0 0 91.66667%;
		max-width: 91.66667%;
	}
	.col-sm-12 {
		flex: 0 0 100%;
		max-width: 100%;
	}
	.order-sm-first {
		order: -1;
	}
	.order-sm-1 {
		order: 1;
	}
	.order-sm-2 {
		order: 2;
	}
	.order-sm-3 {
		order: 3;
	}
	.order-sm-4 {
		order: 4;
	}
	.order-sm-5 {
		order: 5;
	}
	.order-sm-6 {
		order: 6;
	}
	.order-sm-7 {
		order: 7;
	}
	.order-sm-8 {
		order: 8;
	}
	.order-sm-9 {
		order: 9;
	}
	.order-sm-10 {
		order: 10;
	}
	.order-sm-11 {
		order: 11;
	}
	.order-sm-12 {
		order: 12;
	}
	.offset-sm-0 {
		margin-left: 0;
	}
	.offset-sm-1 {
		margin-left: 8.33333%;
	}
	.offset-sm-2 {
		margin-left: 16.66667%;
	}
	.offset-sm-3 {
		margin-left: 25%;
	}
	.offset-sm-4 {
		margin-left: 33.33333%;
	}
	.offset-sm-5 {
		margin-left: 41.66667%;
	}
	.offset-sm-6 {
		margin-left: 50%;
	}
	.offset-sm-7 {
		margin-left: 58.33333%;
	}
	.offset-sm-8 {
		margin-left: 66.66667%;
	}
	.offset-sm-9 {
		margin-left: 75%;
	}
	.offset-sm-10 {
		margin-left: 83.33333%;
	}
	.offset-sm-11 {
		margin-left: 91.66667%;
	}
}

@media (min-width: 768px) {
	.col-md {
		flex-basis: 0;
		flex-grow: 1;
		max-width: 100%;
	}
	.col-md-auto {
		flex: 0 0 auto;
		width: auto;
		max-width: none;
	}
	.col-md-1 {
		flex: 0 0 8.33333%;
		max-width: 8.33333%;
	}
	.col-md-2 {
		flex: 0 0 16.66667%;
		max-width: 16.66667%;
	}
	.col-md-3 {
		flex: 0 0 25%;
		max-width: 25%;
	}
	.col-md-4 {
		flex: 0 0 33.33333%;
		max-width: 33.33333%;
	}
	.col-md-5 {
		flex: 0 0 41.66667%;
		max-width: 41.66667%;
	}
	.col-md-6 {
		flex: 0 0 50%;
		max-width: 50%;
	}
	.col-md-7 {
		flex: 0 0 58.33333%;
		max-width: 58.33333%;
	}
	.col-md-8 {
		flex: 0 0 66.66667%;
		max-width: 66.66667%;
	}
	.col-md-9 {
		flex: 0 0 75%;
		max-width: 75%;
	}
	.col-md-10 {
		flex: 0 0 83.33333%;
		max-width: 83.33333%;
	}
	.col-md-11 {
		flex: 0 0 91.66667%;
		max-width: 91.66667%;
	}
	.col-md-12 {
		flex: 0 0 100%;
		max-width: 100%;
	}
	.order-md-first {
		order: -1;
	}
	.order-md-1 {
		order: 1;
	}
	.order-md-2 {
		order: 2;
	}
	.order-md-3 {
		order: 3;
	}
	.order-md-4 {
		order: 4;
	}
	.order-md-5 {
		order: 5;
	}
	.order-md-6 {
		order: 6;
	}
	.order-md-7 {
		order: 7;
	}
	.order-md-8 {
		order: 8;
	}
	.order-md-9 {
		order: 9;
	}
	.order-md-10 {
		order: 10;
	}
	.order-md-11 {
		order: 11;
	}
	.order-md-12 {
		order: 12;
	}
	.offset-md-0 {
		margin-left: 0;
	}
	.offset-md-1 {
		margin-left: 8.33333%;
	}
	.offset-md-2 {
		margin-left: 16.66667%;
	}
	.offset-md-3 {
		margin-left: 25%;
	}
	.offset-md-4 {
		margin-left: 33.33333%;
	}
	.offset-md-5 {
		margin-left: 41.66667%;
	}
	.offset-md-6 {
		margin-left: 50%;
	}
	.offset-md-7 {
		margin-left: 58.33333%;
	}
	.offset-md-8 {
		margin-left: 66.66667%;
	}
	.offset-md-9 {
		margin-left: 75%;
	}
	.offset-md-10 {
		margin-left: 83.33333%;
	}
	.offset-md-11 {
		margin-left: 91.66667%;
	}
}

@media (min-width: 992px) {
	.col-lg {
		flex-basis: 0;
		flex-grow: 1;
		max-width: 100%;
	}
	.col-lg-auto {
		flex: 0 0 auto;
		width: auto;
		max-width: none;
	}
	.col-lg-1 {
		flex: 0 0 8.33333%;
		max-width: 8.33333%;
	}
	.col-lg-2 {
		flex: 0 0 16.66667%;
		max-width: 16.66667%;
	}
	.col-lg-3 {
		flex: 0 0 25%;
		max-width: 25%;
	}
	.col-lg-4 {
		flex: 0 0 33.33333%;
		max-width: 33.33333%;
	}
	.col-lg-5 {
		flex: 0 0 41.66667%;
		max-width: 41.66667%;
	}
	.col-lg-6 {
		flex: 0 0 50%;
		max-width: 50%;
	}
	.col-lg-7 {
		flex: 0 0 58.33333%;
		max-width: 58.33333%;
	}
	.col-lg-8 {
		flex: 0 0 66.66667%;
		max-width: 66.66667%;
	}
	.col-lg-9 {
		flex: 0 0 75%;
		max-width: 75%;
	}
	.col-lg-10 {
		flex: 0 0 83.33333%;
		max-width: 83.33333%;
	}
	.col-lg-11 {
		flex: 0 0 91.66667%;
		max-width: 91.66667%;
	}
	.col-lg-12 {
		flex: 0 0 100%;
		max-width: 100%;
	}
	.order-lg-first {
		order: -1;
	}
	.order-lg-1 {
		order: 1;
	}
	.order-lg-2 {
		order: 2;
	}
	.order-lg-3 {
		order: 3;
	}
	.order-lg-4 {
		order: 4;
	}
	.order-lg-5 {
		order: 5;
	}
	.order-lg-6 {
		order: 6;
	}
	.order-lg-7 {
		order: 7;
	}
	.order-lg-8 {
		order: 8;
	}
	.order-lg-9 {
		order: 9;
	}
	.order-lg-10 {
		order: 10;
	}
	.order-lg-11 {
		order: 11;
	}
	.order-lg-12 {
		order: 12;
	}
	.offset-lg-0 {
		margin-left: 0;
	}
	.offset-lg-1 {
		margin-left: 8.33333%;
	}
	.offset-lg-2 {
		margin-left: 16.66667%;
	}
	.offset-lg-3 {
		margin-left: 25%;
	}
	.offset-lg-4 {
		margin-left: 33.33333%;
	}
	.offset-lg-5 {
		margin-left: 41.66667%;
	}
	.offset-lg-6 {
		margin-left: 50%;
	}
	.offset-lg-7 {
		margin-left: 58.33333%;
	}
	.offset-lg-8 {
		margin-left: 66.66667%;
	}
	.offset-lg-9 {
		margin-left: 75%;
	}
	.offset-lg-10 {
		margin-left: 83.33333%;
	}
	.offset-lg-11 {
		margin-left: 91.66667%;
	}
}

@media (min-width: 1200px) {
	.col-xl {
		flex-basis: 0;
		flex-grow: 1;
		max-width: 100%;
	}
	.col-xl-auto {
		flex: 0 0 auto;
		width: auto;
		max-width: none;
	}
	.col-xl-1 {
		flex: 0 0 8.33333%;
		max-width: 8.33333%;
	}
	.col-xl-2 {
		flex: 0 0 16.66667%;
		max-width: 16.66667%;
	}
	.col-xl-3 {
		flex: 0 0 25%;
		max-width: 25%;
	}
	.col-xl-4 {
		flex: 0 0 33.33333%;
		max-width: 33.33333%;
	}
	.col-xl-5 {
		flex: 0 0 41.66667%;
		max-width: 41.66667%;
	}
	.col-xl-6 {
		flex: 0 0 50%;
		max-width: 50%;
	}
	.col-xl-7 {
		flex: 0 0 58.33333%;
		max-width: 58.33333%;
	}
	.col-xl-8 {
		flex: 0 0 66.66667%;
		max-width: 66.66667%;
	}
	.col-xl-9 {
		flex: 0 0 75%;
		max-width: 75%;
	}
	.col-xl-10 {
		flex: 0 0 83.33333%;
		max-width: 83.33333%;
	}
	.col-xl-11 {
		flex: 0 0 91.66667%;
		max-width: 91.66667%;
	}
	.col-xl-12 {
		flex: 0 0 100%;
		max-width: 100%;
	}
	.order-xl-first {
		order: -1;
	}
	.order-xl-1 {
		order: 1;
	}
	.order-xl-2 {
		order: 2;
	}
	.order-xl-3 {
		order: 3;
	}
	.order-xl-4 {
		order: 4;
	}
	.order-xl-5 {
		order: 5;
	}
	.order-xl-6 {
		order: 6;
	}
	.order-xl-7 {
		order: 7;
	}
	.order-xl-8 {
		order: 8;
	}
	.order-xl-9 {
		order: 9;
	}
	.order-xl-10 {
		order: 10;
	}
	.order-xl-11 {
		order: 11;
	}
	.order-xl-12 {
		order: 12;
	}
	.offset-xl-0 {
		margin-left: 0;
	}
	.offset-xl-1 {
		margin-left: 8.33333%;
	}
	.offset-xl-2 {
		margin-left: 16.66667%;
	}
	.offset-xl-3 {
		margin-left: 25%;
	}
	.offset-xl-4 {
		margin-left: 33.33333%;
	}
	.offset-xl-5 {
		margin-left: 41.66667%;
	}
	.offset-xl-6 {
		margin-left: 50%;
	}
	.offset-xl-7 {
		margin-left: 58.33333%;
	}
	.offset-xl-8 {
		margin-left: 66.66667%;
	}
	.offset-xl-9 {
		margin-left: 75%;
	}
	.offset-xl-10 {
		margin-left: 83.33333%;
	}
	.offset-xl-11 {
		margin-left: 91.66667%;
	}
}

@media (min-width: 1800px) {
	.col-xxl {
		flex-basis: 0;
		flex-grow: 1;
		max-width: 100%;
	}
	.col-xxl-auto {
		flex: 0 0 auto;
		width: auto;
		max-width: none;
	}
	.col-xxl-1 {
		flex: 0 0 8.33333%;
		max-width: 8.33333%;
	}
	.col-xxl-2 {
		flex: 0 0 16.66667%;
		max-width: 16.66667%;
	}
	.col-xxl-3 {
		flex: 0 0 25%;
		max-width: 25%;
	}
	.col-xxl-4 {
		flex: 0 0 33.33333%;
		max-width: 33.33333%;
	}
	.col-xxl-5 {
		flex: 0 0 41.66667%;
		max-width: 41.66667%;
	}
	.col-xxl-6 {
		flex: 0 0 50%;
		max-width: 50%;
	}
	.col-xxl-7 {
		flex: 0 0 58.33333%;
		max-width: 58.33333%;
	}
	.col-xxl-8 {
		flex: 0 0 66.66667%;
		max-width: 66.66667%;
	}
	.col-xxl-9 {
		flex: 0 0 75%;
		max-width: 75%;
	}
	.col-xxl-10 {
		flex: 0 0 83.33333%;
		max-width: 83.33333%;
	}
	.col-xxl-11 {
		flex: 0 0 91.66667%;
		max-width: 91.66667%;
	}
	.col-xxl-12 {
		flex: 0 0 100%;
		max-width: 100%;
	}
	.order-xxl-first {
		order: -1;
	}
	.order-xxl-1 {
		order: 1;
	}
	.order-xxl-2 {
		order: 2;
	}
	.order-xxl-3 {
		order: 3;
	}
	.order-xxl-4 {
		order: 4;
	}
	.order-xxl-5 {
		order: 5;
	}
	.order-xxl-6 {
		order: 6;
	}
	.order-xxl-7 {
		order: 7;
	}
	.order-xxl-8 {
		order: 8;
	}
	.order-xxl-9 {
		order: 9;
	}
	.order-xxl-10 {
		order: 10;
	}
	.order-xxl-11 {
		order: 11;
	}
	.order-xxl-12 {
		order: 12;
	}
	.offset-xxl-0 {
		margin-left: 0;
	}
	.offset-xxl-1 {
		margin-left: 8.33333%;
	}
	.offset-xxl-2 {
		margin-left: 16.66667%;
	}
	.offset-xxl-3 {
		margin-left: 25%;
	}
	.offset-xxl-4 {
		margin-left: 33.33333%;
	}
	.offset-xxl-5 {
		margin-left: 41.66667%;
	}
	.offset-xxl-6 {
		margin-left: 50%;
	}
	.offset-xxl-7 {
		margin-left: 58.33333%;
	}
	.offset-xxl-8 {
		margin-left: 66.66667%;
	}
	.offset-xxl-9 {
		margin-left: 75%;
	}
	.offset-xxl-10 {
		margin-left: 83.33333%;
	}
	.offset-xxl-11 {
		margin-left: 91.66667%;
	}
}

.table {
	width: 100%;
	max-width: 100%;
	margin-bottom: 1rem;
	background-color: transparent;
}

.table th,
.table td {
	padding: 17px 25px 18px;
	vertical-align: top;
	border-top: 1px solid #d9d9d9;
}

.table thead th {
	vertical-align: bottom;
	border-bottom: 2px solid #d9d9d9;
}

.table tbody + tbody {
	border-top: 2px solid #d9d9d9;
}

.table .table {
	background-color: #fff;
}

.table-sm th,
.table-sm td {
	padding: 0.3rem;
}

.table-bordered {
	border: 1px solid #d9d9d9;
}

.table-bordered th,
.table-bordered td {
	border: 1px solid #d9d9d9;
}

.table-bordered thead th,
.table-bordered thead td {
	border-bottom-width: 2px;
}

.table-striped tbody tr:nth-of-type(odd) {
	background-color: rgba(0, 0, 0, 0.05);
}

.table-hover tbody tr:hover {
	background-color: rgba(0, 0, 0, 0.075);
}

.table-primary,
.table-primary > th,
.table-primary > td {
	background-color: #b8daff;
}

.table-hover .table-primary:hover {
	background-color: #9fcdff;
}

.table-hover .table-primary:hover > td,
.table-hover .table-primary:hover > th {
	background-color: #9fcdff;
}

.table-secondary,
.table-secondary > th,
.table-secondary > td {
	background-color: #dddfe2;
}

.table-hover .table-secondary:hover {
	background-color: #cfd2d6;
}

.table-hover .table-secondary:hover > td,
.table-hover .table-secondary:hover > th {
	background-color: #cfd2d6;
}

.table-success,
.table-success > th,
.table-success > td {
	background-color: #c3e6cb;
}

.table-hover .table-success:hover {
	background-color: #b1dfbb;
}

.table-hover .table-success:hover > td,
.table-hover .table-success:hover > th {
	background-color: #b1dfbb;
}

.table-info,
.table-info > th,
.table-info > td {
	background-color: #bee5eb;
}

.table-hover .table-info:hover {
	background-color: #abdde5;
}

.table-hover .table-info:hover > td,
.table-hover .table-info:hover > th {
	background-color: #abdde5;
}

.table-warning,
.table-warning > th,
.table-warning > td {
	background-color: #ffeeba;
}

.table-hover .table-warning:hover {
	background-color: #ffe8a1;
}

.table-hover .table-warning:hover > td,
.table-hover .table-warning:hover > th {
	background-color: #ffe8a1;
}

.table-danger,
.table-danger > th,
.table-danger > td {
	background-color: #f5c6cb;
}

.table-hover .table-danger:hover {
	background-color: #f1b0b7;
}

.table-hover .table-danger:hover > td,
.table-hover .table-danger:hover > th {
	background-color: #f1b0b7;
}

.table-light,
.table-light > th,
.table-light > td {
	background-color: #fdfdfe;
}

.table-hover .table-light:hover {
	background-color: #ececf6;
}

.table-hover .table-light:hover > td,
.table-hover .table-light:hover > th {
	background-color: #ececf6;
}

.table-dark,
.table-dark > th,
.table-dark > td {
	background-color: #c6c8ca;
}

.table-hover .table-dark:hover {
	background-color: #b9bbbe;
}

.table-hover .table-dark:hover > td,
.table-hover .table-dark:hover > th {
	background-color: #b9bbbe;
}

.table-active,
.table-active > th,
.table-active > td {
	background-color: rgba(0, 0, 0, 0.075);
}

.table-hover .table-active:hover {
	background-color: rgba(0, 0, 0, 0.075);
}

.table-hover .table-active:hover > td,
.table-hover .table-active:hover > th {
	background-color: rgba(0, 0, 0, 0.075);
}

.table .thead-dark th {
	color: #fff;
	background-color: #212529;
	border-color: #32383e;
}

.table .thead-light th {
	color: #495057;
	background-color: #e9ecef;
	border-color: #d9d9d9;
}

.table-dark {
	color: #fff;
	background-color: #212529;
}

.table-dark th,
.table-dark td,
.table-dark thead th {
	border-color: #32383e;
}

.table-dark.table-bordered {
	border: 0;
}

.table-dark.table-striped tbody tr:nth-of-type(odd) {
	background-color: rgba(255, 255, 255, 0.05);
}

.table-dark.table-hover tbody tr:hover {
	background-color: rgba(255, 255, 255, 0.075);
}

@media (max-width: 575px) {
	.table-responsive-sm {
		display: block;
		width: 100%;
		overflow-x: auto;
		-webkit-overflow-scrolling: touch;
		-ms-overflow-style: -ms-autohiding-scrollbar;
	}
	.table-responsive-sm.table-bordered {
		border: 0;
	}
}

@media (max-width: 767px) {
	.table-responsive-md {
		display: block;
		width: 100%;
		overflow-x: auto;
		-webkit-overflow-scrolling: touch;
		-ms-overflow-style: -ms-autohiding-scrollbar;
	}
	.table-responsive-md.table-bordered {
		border: 0;
	}
}

@media (max-width: 991px) {
	.table-responsive-lg {
		display: block;
		width: 100%;
		overflow-x: auto;
		-webkit-overflow-scrolling: touch;
		-ms-overflow-style: -ms-autohiding-scrollbar;
	}
	.table-responsive-lg.table-bordered {
		border: 0;
	}
}

@media (max-width: 1199px) {
	.table-responsive-xl {
		display: block;
		width: 100%;
		overflow-x: auto;
		-webkit-overflow-scrolling: touch;
		-ms-overflow-style: -ms-autohiding-scrollbar;
	}
	.table-responsive-xl.table-bordered {
		border: 0;
	}
}

@media (max-width: 1799px) {
	.table-responsive-xxl {
		display: block;
		width: 100%;
		overflow-x: auto;
		-webkit-overflow-scrolling: touch;
		-ms-overflow-style: -ms-autohiding-scrollbar;
	}
	.table-responsive-xxl.table-bordered {
		border: 0;
	}
}

.table-responsive {
	display: block;
	width: 100%;
	overflow-x: auto;
	-webkit-overflow-scrolling: touch;
	-ms-overflow-style: -ms-autohiding-scrollbar;
}

.table-responsive.table-bordered {
	border: 0;
}

.form-input {
	display: block;
	width: 100%;
	padding: 11px 35px;
	font-size: 14px;
	line-height: 1.25;
	background-image: none;
	background-clip: padding-box;
	border: 1px solid #ced4da;
	border-radius: 0.25rem;
	box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
	transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
}

.form-input::-ms-expand {
	background-color: transparent;
	border: 0;
}

.form-input:focus {
	color: #495057;
	background-color: #fff;
	border-color: #80bdff;
	outline: none;
	box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}

.form-input::placeholder {
	color: #868e96;
	opacity: 1;
}

.form-input:disabled, .form-input[readonly] {
	background-color: #e9ecef;
	opacity: 1;
}

select.form-input:not([size]):not([multiple]) {
	height: calc(2.25rem + 2px);
}

.form-input-file,
.form-input-range {
	display: block;
}

.col-form-label {
	padding-top: calc(11px + 1px);
	padding-bottom: calc(11px + 1px);
	margin-bottom: 0;
	line-height: 1.25;
}

.col-form-label-lg {
	padding-top: calc(12px + 1px);
	padding-bottom: calc(12px + 1px);
	font-size: 18px;
	line-height: 1.5;
}

.col-form-label-sm {
	padding-top: calc(5px + 1px);
	padding-bottom: calc(5px + 1px);
	font-size: 12px;
	line-height: 1.5;
}

.col-form-legend {
	padding-top: 11px;
	padding-bottom: 11px;
	margin-bottom: 0;
	font-size: 14px;
}

.form-input-plaintext {
	padding-top: 11px;
	padding-bottom: 11px;
	margin-bottom: 0;
	line-height: 1.25;
	background-color: transparent;
	border: solid transparent;
	border-width: 1px 0;
}

.form-input-plaintext.form-input-sm, .input-group-sm > .form-input-plaintext.form-input,
.input-group-sm > .form-input-plaintext.input-group-addon,
.input-group-sm > .input-group-btn > .form-input-plaintext.btn, .form-input-plaintext.form-input-lg, .input-group-lg > .form-input-plaintext.form-input,
.input-group-lg > .form-input-plaintext.input-group-addon,
.input-group-lg > .input-group-btn > .form-input-plaintext.btn {
	padding-right: 0;
	padding-left: 0;
}

.form-input-sm, .input-group-sm > .form-input,
.input-group-sm > .input-group-addon,
.input-group-sm > .input-group-btn > .btn {
	padding: 5px 25px;
	font-size: 12px;
	line-height: 1.5;
	border-radius: 0.2rem;
}

select.form-input-sm:not([size]):not([multiple]), .input-group-sm > select.form-input:not([size]):not([multiple]),
.input-group-sm > select.input-group-addon:not([size]):not([multiple]),
.input-group-sm > .input-group-btn > select.btn:not([size]):not([multiple]) {
	height: calc(1.8125rem + 2px);
}

.form-input-lg, .input-group-lg > .form-input,
.input-group-lg > .input-group-addon,
.input-group-lg > .input-group-btn > .btn {
	padding: 12px 50px;
	font-size: 18px;
	line-height: 1.5;
	border-radius: 0.3rem;
}

select.form-input-lg:not([size]):not([multiple]), .input-group-lg > select.form-input:not([size]):not([multiple]),
.input-group-lg > select.input-group-addon:not([size]):not([multiple]),
.input-group-lg > .input-group-btn > select.btn:not([size]):not([multiple]) {
	height: calc(2.875rem + 2px);
}

.form-label {
	margin-bottom: 1rem;
}

.form-text {
	display: block;
	margin-top: 0.25rem;
}

.form-row {
	display: flex;
	flex-wrap: wrap;
	margin-right: -5px;
	margin-left: -5px;
}

.form-row > .col,
.form-row > [class*="col-"] {
	padding-right: 5px;
	padding-left: 5px;
}

.form-check {
	position: relative;
	display: block;
	margin-bottom: 0.5rem;
}

.form-check.disabled .form-check-label {
	color: #dedede;
}

.form-check-label {
	padding-left: 1.25rem;
	margin-bottom: 0;
}

.form-check-input {
	position: absolute;
	margin-top: 0.25rem;
	margin-left: -1.25rem;
}

.form-check-inline {
	display: inline-block;
	margin-right: 0.75rem;
}

.form-check-inline .form-check-label {
	vertical-align: middle;
}

.valid-feedback {
	display: none;
	margin-top: .25rem;
	font-size: .875rem;
	color: #98bf44;
}

.valid-tooltip {
	position: absolute;
	top: 100%;
	z-index: 5;
	display: none;
	width: 250px;
	padding: .5rem;
	margin-top: .1rem;
	font-size: .875rem;
	line-height: 1;
	color: #fff;
	/* background-color: rgba(152, 191, 68, 0.8); */
	border-radius: .2rem;
}

.was-validated .form-input:valid, .form-input.is-valid, .was-validated
.custom-select:valid,
.custom-select.is-valid {
	border-color: #98bf44;
}

.was-validated .form-input:valid:focus, .form-input.is-valid:focus, .was-validated
.custom-select:valid:focus,
.custom-select.is-valid:focus {
	box-shadow: 0 0 0 0.2rem rgba(152, 191, 68, 0.25);
}

.was-validated .form-input:valid ~ .valid-feedback,
.was-validated .form-input:valid ~ .valid-tooltip, .form-input.is-valid ~ .valid-feedback,
.form-input.is-valid ~ .valid-tooltip, .was-validated
.custom-select:valid ~ .valid-feedback,
.was-validated
.custom-select:valid ~ .valid-tooltip,
.custom-select.is-valid ~ .valid-feedback,
.custom-select.is-valid ~ .valid-tooltip {
	display: block;
}

.was-validated .form-check-input:valid + .form-check-label, .form-check-input.is-valid + .form-check-label {
	color: #98bf44;
}

.was-validated .custom-control-input:valid ~ .custom-control-indicator, .custom-control-input.is-valid ~ .custom-control-indicator {
	background-color: rgba(152, 191, 68, 0.25);
}

.was-validated .custom-control-input:valid ~ .custom-control-description, .custom-control-input.is-valid ~ .custom-control-description {
	color: #98bf44;
}

.was-validated .custom-file-input:valid ~ .custom-file-control, .custom-file-input.is-valid ~ .custom-file-control {
	border-color: #98bf44;
}

.was-validated .custom-file-input:valid ~ .custom-file-control::before, .custom-file-input.is-valid ~ .custom-file-control::before {
	border-color: inherit;
}

.was-validated .custom-file-input:valid:focus, .custom-file-input.is-valid:focus {
	box-shadow: 0 0 0 0.2rem rgba(152, 191, 68, 0.25);
}

.invalid-feedback {
	display: none;
	margin-top: .25rem;
	font-size: .875rem;
	color: #f5543f;
}

.invalid-tooltip {
	position: absolute;
	top: 100%;
	z-index: 5;
	display: none;
	width: 250px;
	padding: .5rem;
	margin-top: .1rem;
	font-size: .875rem;
	line-height: 1;
	color: #fff;
	background-color: rgba(245, 84, 63, 0.8);
	border-radius: .2rem;
}

.was-validated .form-input:invalid, .form-input.is-invalid, .was-validated
.custom-select:invalid,
.custom-select.is-invalid {
	border-color: #f5543f;
}

.was-validated .form-input:invalid:focus, .form-input.is-invalid:focus, .was-validated
.custom-select:invalid:focus,
.custom-select.is-invalid:focus {
	box-shadow: 0 0 0 0.2rem rgba(245, 84, 63, 0.25);
}

.was-validated .form-input:invalid ~ .invalid-feedback,
.was-validated .form-input:invalid ~ .invalid-tooltip, .form-input.is-invalid ~ .invalid-feedback,
.form-input.is-invalid ~ .invalid-tooltip, .was-validated
.custom-select:invalid ~ .invalid-feedback,
.was-validated
.custom-select:invalid ~ .invalid-tooltip,
.custom-select.is-invalid ~ .invalid-feedback,
.custom-select.is-invalid ~ .invalid-tooltip {
	display: block;
}

.was-validated .form-check-input:invalid + .form-check-label, .form-check-input.is-invalid + .form-check-label {
	color: #f5543f;
}

.was-validated .custom-control-input:invalid ~ .custom-control-indicator, .custom-control-input.is-invalid ~ .custom-control-indicator {
	background-color: rgba(245, 84, 63, 0.25);
}

.was-validated .custom-control-input:invalid ~ .custom-control-description, .custom-control-input.is-invalid ~ .custom-control-description {
	color: #f5543f;
}

.was-validated .custom-file-input:invalid ~ .custom-file-control, .custom-file-input.is-invalid ~ .custom-file-control {
	border-color: #f5543f;
}

.was-validated .custom-file-input:invalid ~ .custom-file-control::before, .custom-file-input.is-invalid ~ .custom-file-control::before {
	border-color: inherit;
}

.was-validated .custom-file-input:invalid:focus, .custom-file-input.is-invalid:focus {
	box-shadow: 0 0 0 0.2rem rgba(245, 84, 63, 0.25);
}

.form-inline {
	display: flex;
	flex-flow: row wrap;
	align-items: center;
}

.form-inline .form-check {
	width: 100%;
}

@media (min-width: 576px) {
	.form-inline label {
		display: flex;
		align-items: center;
		justify-content: center;
		margin-bottom: 0;
	}
	.form-inline .form-label {
		display: flex;
		flex: 0 0 auto;
		flex-flow: row wrap;
		align-items: center;
		margin-bottom: 0;
	}
	.form-inline .form-input {
		display: inline-block;
		width: auto;
		vertical-align: middle;
	}
	.form-inline .form-input-plaintext {
		display: inline-block;
	}
	.form-inline .input-group {
		width: auto;
	}
	.form-inline .form-check {
		display: flex;
		align-items: center;
		justify-content: center;
		width: auto;
		margin-top: 0;
		margin-bottom: 0;
	}
	.form-inline .form-check-label {
		padding-left: 0;
	}
	.form-inline .form-check-input {
		position: relative;
		margin-top: 0;
		margin-right: 0.25rem;
		margin-left: 0;
	}
	.form-inline .custom-control {
		display: flex;
		align-items: center;
		justify-content: center;
		padding-left: 0;
	}
	.form-inline .custom-control-indicator {
		position: static;
		display: inline-block;
		margin-right: 0.25rem;
		vertical-align: text-bottom;
	}
	.form-inline .has-feedback .form-input-feedback {
		top: 0;
	}
}

.btn {
	display: inline-block;
	font-weight: 700;
	text-align: center;
	white-space: nowrap;
	vertical-align: middle;
	user-select: none;
	border: 1px solid transparent;
	padding: 11px 35px;
	font-size: 14px;
	line-height: 1.25;
	border-radius: 5px;
	transition: all 0.15s ease-in-out;
}

.btn:focus, .btn:hover {
	text-decoration: none;
}

.btn:focus, .btn.focus {
	outline: 0;
	box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}

.btn.disabled, .btn:disabled {
	opacity: .65;
	box-shadow: none;
}

.btn:not([disabled]):not(.disabled):active, .btn:not([disabled]):not(.disabled).active {
	background-image: none;
	box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25), 0;
}

a.btn.disabled,
fieldset[disabled] a.btn {
	pointer-events: none;
}

.btn-primary {
	color: #fff;
	background-color: #007bff;
	border-color: #007bff;
	box-shadow: 0;
}

.btn-primary:focus, .btn-primary.focus {
	box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.5);
}

.btn-primary.maincolorbisbackground:focus, .btn-primary.maincolorbisbackground.focus {
	box-shadow: 0 0 0 0.2rem rgba(0, 255, 123, 0.5);
}

.btn-primary.maincolorbisbackground:hover {
	box-shadow: 1px 1px 8px #aaa;
}

.btn-primary.disabled, .btn-primary:disabled {
	background-color: #007bff;
	border-color: #007bff;
}

.btn-primary:not([disabled]):not(.disabled):active, .btn-primary:not([disabled]):not(.disabled).active,
.show > .btn-primary.dropdown-toggle {
	color: #fff;
	background-color: #0062cc;
	border-color: #005cbf;
	box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.5);
}

.btn-secondary {
	color: #fff;
	background-color: #868e96;
	border-color: #868e96;
	box-shadow: 0;
}

.btn-secondary:hover {
	color: #fff;
	background-color: #727b84;
	border-color: #6c757d;
}

.btn-secondary:focus, .btn-secondary.focus {
	box-shadow: 0 0 0 0.2rem rgba(134, 142, 150, 0.5);
}

.btn-secondary.disabled, .btn-secondary:disabled {
	background-color: #868e96;
	border-color: #868e96;
}

.btn-secondary:not([disabled]):not(.disabled):active, .btn-secondary:not([disabled]):not(.disabled).active,
.show > .btn-secondary.dropdown-toggle {
	color: #fff;
	background-color: #6c757d;
	border-color: #666e76;
	box-shadow: 0 0 0 0.2rem rgba(134, 142, 150, 0.5);
}

.btn-success {
	color: #fff;
	background-color: #28a745;
	border-color: #28a745;
	box-shadow: 0;
}

.btn-success:hover {
	color: #fff;
	background-color: #218838;
	border-color: #1e7e34;
}

.btn-success:focus, .btn-success.focus {
	box-shadow: 0 0 0 0.2rem rgba(40, 167, 69, 0.5);
}

.btn-success.disabled, .btn-success:disabled {
	background-color: #28a745;
	border-color: #28a745;
}

.btn-success:not([disabled]):not(.disabled):active, .btn-success:not([disabled]):not(.disabled).active,
.show > .btn-success.dropdown-toggle {
	color: #fff;
	background-color: #1e7e34;
	border-color: #1c7430;
	box-shadow: 0 0 0 0.2rem rgba(40, 167, 69, 0.5);
}

.btn-info {
	color: #fff;
	background-color: #17a2b8;
	border-color: #17a2b8;
	box-shadow: 0;
}

.btn-info:hover {
	color: #fff;
	background-color: #138496;
	border-color: #117a8b;
}

.btn-info:focus, .btn-info.focus {
	box-shadow: 0 0 0 0.2rem rgba(23, 162, 184, 0.5);
}

.btn-info.disabled, .btn-info:disabled {
	background-color: #17a2b8;
	border-color: #17a2b8;
}

.btn-info:not([disabled]):not(.disabled):active, .btn-info:not([disabled]):not(.disabled).active,
.show > .btn-info.dropdown-toggle {
	color: #fff;
	background-color: #117a8b;
	border-color: #10707f;
	box-shadow: 0 0 0 0.2rem rgba(23, 162, 184, 0.5);
}

.btn-warning {
	color: #111;
	background-color: #ffc107;
	border-color: #ffc107;
	box-shadow: 0;
}

.btn-warning:hover {
	color: #111;
	background-color: #e0a800;
	border-color: #d39e00;
}

.btn-warning:focus, .btn-warning.focus {
	box-shadow: 0 0 0 0.2rem rgba(255, 193, 7, 0.5);
}

.btn-warning.disabled, .btn-warning:disabled {
	background-color: #ffc107;
	border-color: #ffc107;
}

.btn-warning:not([disabled]):not(.disabled):active, .btn-warning:not([disabled]):not(.disabled).active,
.show > .btn-warning.dropdown-toggle {
	color: #111;
	background-color: #d39e00;
	border-color: #c69500;
	box-shadow: 0 0 0 0.2rem rgba(255, 193, 7, 0.5);
}

.btn-danger {
	color: #fff;
	background-color: #dc3545;
	border-color: #dc3545;
	box-shadow: 0;
}

.btn-danger:hover {
	color: #fff;
	background-color: #c82333;
	border-color: #bd2130;
}

.btn-danger:focus, .btn-danger.focus {
	box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.5);
}

.btn-danger.disabled, .btn-danger:disabled {
	background-color: #dc3545;
	border-color: #dc3545;
}

.btn-danger:not([disabled]):not(.disabled):active, .btn-danger:not([disabled]):not(.disabled).active,
.show > .btn-danger.dropdown-toggle {
	color: #fff;
	background-color: #bd2130;
	border-color: #b21f2d;
	box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.5);
}

.btn-light {
	color: #111;
	background-color: #f8f9fa;
	border-color: #f8f9fa;
	box-shadow: 0;
}

.btn-light:hover {
	color: #111;
	background-color: #e2e6ea;
	border-color: #dae0e5;
}

.btn-light:focus, .btn-light.focus {
	box-shadow: 0 0 0 0.2rem rgba(248, 249, 250, 0.5);
}

.btn-light.disabled, .btn-light:disabled {
	background-color: #f8f9fa;
	border-color: #f8f9fa;
}

.btn-light:not([disabled]):not(.disabled):active, .btn-light:not([disabled]):not(.disabled).active,
.show > .btn-light.dropdown-toggle {
	color: #111;
	background-color: #dae0e5;
	border-color: #d3d9df;
	box-shadow: 0 0 0 0.2rem rgba(248, 249, 250, 0.5);
}

.btn-dark {
	color: #fff;
	background-color: #343a40;
	border-color: #343a40;
	box-shadow: 0;
}

.btn-dark:hover {
	color: #fff;
	background-color: #23272b;
	border-color: #1d2124;
}

.btn-dark:focus, .btn-dark.focus {
	box-shadow: 0 0 0 0.2rem rgba(52, 58, 64, 0.5);
}

.btn-dark.disabled, .btn-dark:disabled {
	background-color: #343a40;
	border-color: #343a40;
}

.btn-dark:not([disabled]):not(.disabled):active, .btn-dark:not([disabled]):not(.disabled).active,
.show > .btn-dark.dropdown-toggle {
	color: #fff;
	background-color: #1d2124;
	border-color: #171a1d;
	box-shadow: 0 0 0 0.2rem rgba(52, 58, 64, 0.5);
}

.btn-outline-primary {
	color: #007bff;
	background-color: transparent;
	background-image: none;
	border-color: #007bff;
}

.btn-outline-primary:hover {
	color: #fff;
	background-color: #007bff;
	border-color: #007bff;
}

.btn-outline-primary:focus, .btn-outline-primary.focus {
	box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.5);
}

.btn-outline-primary.disabled, .btn-outline-primary:disabled {
	color: #007bff;
	background-color: transparent;
}

.btn-outline-primary:not([disabled]):not(.disabled):active, .btn-outline-primary:not([disabled]):not(.disabled).active,
.show > .btn-outline-primary.dropdown-toggle {
	color: #fff;
	background-color: #007bff;
	border-color: #007bff;
	box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.5);
}

.btn-outline-secondary {
	color: #868e96;
	background-color: transparent;
	background-image: none;
	border-color: #868e96;
}

.btn-outline-secondary:hover {
	color: #fff;
	background-color: #868e96;
	border-color: #868e96;
}

.btn-outline-secondary:focus, .btn-outline-secondary.focus {
	box-shadow: 0 0 0 0.2rem rgba(134, 142, 150, 0.5);
}

.btn-outline-secondary.disabled, .btn-outline-secondary:disabled {
	color: #868e96;
	background-color: transparent;
}

.btn-outline-secondary:not([disabled]):not(.disabled):active, .btn-outline-secondary:not([disabled]):not(.disabled).active,
.show > .btn-outline-secondary.dropdown-toggle {
	color: #fff;
	background-color: #868e96;
	border-color: #868e96;
	box-shadow: 0 0 0 0.2rem rgba(134, 142, 150, 0.5);
}

.btn-outline-success {
	color: #28a745;
	background-color: transparent;
	background-image: none;
	border-color: #28a745;
}

.btn-outline-success:hover {
	color: #fff;
	background-color: #28a745;
	border-color: #28a745;
}

.btn-outline-success:focus, .btn-outline-success.focus {
	box-shadow: 0 0 0 0.2rem rgba(40, 167, 69, 0.5);
}

.btn-outline-success.disabled, .btn-outline-success:disabled {
	color: #28a745;
	background-color: transparent;
}

.btn-outline-success:not([disabled]):not(.disabled):active, .btn-outline-success:not([disabled]):not(.disabled).active,
.show > .btn-outline-success.dropdown-toggle {
	color: #fff;
	background-color: #28a745;
	border-color: #28a745;
	box-shadow: 0 0 0 0.2rem rgba(40, 167, 69, 0.5);
}

.btn-outline-info {
	color: #17a2b8;
	background-color: transparent;
	background-image: none;
	border-color: #17a2b8;
}

.btn-outline-info:hover {
	color: #fff;
	background-color: #17a2b8;
	border-color: #17a2b8;
}

.btn-outline-info:focus, .btn-outline-info.focus {
	box-shadow: 0 0 0 0.2rem rgba(23, 162, 184, 0.5);
}

.btn-outline-info.disabled, .btn-outline-info:disabled {
	color: #17a2b8;
	background-color: transparent;
}

.btn-outline-info:not([disabled]):not(.disabled):active, .btn-outline-info:not([disabled]):not(.disabled).active,
.show > .btn-outline-info.dropdown-toggle {
	color: #fff;
	background-color: #17a2b8;
	border-color: #17a2b8;
	box-shadow: 0 0 0 0.2rem rgba(23, 162, 184, 0.5);
}

.btn-outline-warning {
	color: #ffc107;
	background-color: transparent;
	background-image: none;
	border-color: #ffc107;
}

.btn-outline-warning:hover {
	color: #fff;
	background-color: #ffc107;
	border-color: #ffc107;
}

.btn-outline-warning:focus, .btn-outline-warning.focus {
	box-shadow: 0 0 0 0.2rem rgba(255, 193, 7, 0.5);
}

.btn-outline-warning.disabled, .btn-outline-warning:disabled {
	color: #ffc107;
	background-color: transparent;
}

.btn-outline-warning:not([disabled]):not(.disabled):active, .btn-outline-warning:not([disabled]):not(.disabled).active,
.show > .btn-outline-warning.dropdown-toggle {
	color: #fff;
	background-color: #ffc107;
	border-color: #ffc107;
	box-shadow: 0 0 0 0.2rem rgba(255, 193, 7, 0.5);
}

.btn-outline-danger {
	color: #dc3545;
	background-color: transparent;
	background-image: none;
	border-color: #dc3545;
}

.btn-outline-danger:hover {
	color: #fff;
	background-color: #dc3545;
	border-color: #dc3545;
}

.btn-outline-danger:focus, .btn-outline-danger.focus {
	box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.5);
}

.btn-outline-danger.disabled, .btn-outline-danger:disabled {
	color: #dc3545;
	background-color: transparent;
}

.btn-outline-danger:not([disabled]):not(.disabled):active, .btn-outline-danger:not([disabled]):not(.disabled).active,
.show > .btn-outline-danger.dropdown-toggle {
	color: #fff;
	background-color: #dc3545;
	border-color: #dc3545;
	box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.5);
}

.btn-outline-light {
	color: #f8f9fa;
	background-color: transparent;
	background-image: none;
	border-color: #f8f9fa;
}

.btn-outline-light:hover {
	color: #00030a;
	background-color: #f8f9fa;
	border-color: #f8f9fa;
}

.btn-outline-light:focus, .btn-outline-light.focus {
	box-shadow: 0 0 0 0.2rem rgba(248, 249, 250, 0.5);
}

.btn-outline-light.disabled, .btn-outline-light:disabled {
	color: #f8f9fa;
	background-color: transparent;
}

.btn-outline-light:not([disabled]):not(.disabled):active, .btn-outline-light:not([disabled]):not(.disabled).active,
.show > .btn-outline-light.dropdown-toggle {
	color: #00030a;
	background-color: #f8f9fa;
	border-color: #f8f9fa;
	box-shadow: 0 0 0 0.2rem rgba(248, 249, 250, 0.5);
}

.btn-outline-dark {
	color: #343a40;
	background-color: transparent;
	background-image: none;
	border-color: #343a40;
}

.btn-outline-dark:hover {
	color: #fff;
	background-color: #343a40;
	border-color: #343a40;
}

.btn-outline-dark:focus, .btn-outline-dark.focus {
	box-shadow: 0 0 0 0.2rem rgba(52, 58, 64, 0.5);
}

.btn-outline-dark.disabled, .btn-outline-dark:disabled {
	color: #343a40;
	background-color: transparent;
}

.btn-outline-dark:not([disabled]):not(.disabled):active, .btn-outline-dark:not([disabled]):not(.disabled).active,
.show > .btn-outline-dark.dropdown-toggle {
	color: #fff;
	background-color: #343a40;
	border-color: #343a40;
	box-shadow: 0 0 0 0.2rem rgba(52, 58, 64, 0.5);
}

.btn-link {
	font-weight: 400;
	color: #37c386;
	background-color: transparent;
}

.btn-link:hover {
	color: #26875d;
	text-decoration: none;
	background-color: transparent;
	border-color: transparent;
}

.btn-link:focus, .btn-link.focus {
	border-color: transparent;
	box-shadow: none;
}

.btn-link:disabled, .btn-link.disabled {
	color: #dedede;
}

.btn-lg, .btn-group-lg > .btn {
	padding: 12px 50px;
	font-size: 18px;
	line-height: 1.5;
	border-radius: 6px;
}

.btn-sm, .btn-group-sm > .btn {
	padding: 5px 25px;
	font-size: 12px;
	line-height: 1.5;
	border-radius: 3px;
}

.btn-block {
	display: block;
	width: 100%;
}

.btn-block + .btn-block {
	margin-top: 0.5rem;
}

input[type="submit"].btn-block,
input[type="reset"].btn-block,
input[type="button"].btn-block {
	width: 100%;
}

.fade {
	opacity: 0;
	transition: opacity 0.15s linear;
}

.fade.show {
	opacity: 1;
}

.collapse {
	display: none;
}

.collapse.show {
	display: block;
}

tr.collapse.show {
	display: table-row;
}

tbody.collapse.show {
	display: table-row-group;
}

.collapsing {
	position: relative;
	height: 0;
	overflow: hidden;
	transition: height 0.35s ease;
}

.dropup,
.dropdown {
	position: relative;
}

.dropdown-toggle::after {
	display: inline-block;
	width: 0;
	height: 0;
	margin-left: 0.255em;
	vertical-align: 0.255em;
	content: "";
	border-top: 0.3em solid;
	border-right: 0.3em solid transparent;
	border-bottom: 0;
	border-left: 0.3em solid transparent;
}

.dropdown-toggle:empty::after {
	margin-left: 0;
}

.dropdown-menu {
	position: absolute;
	top: 100%;
	left: 0;
	z-index: 1000;
	display: none;
	float: left;
	min-width: 10rem;
	padding: 0.5rem 0;
	margin: 0.125rem 0 0;
	font-size: 14px;
	text-align: left;
	list-style: none;
	background-color: #fff;
	background-clip: padding-box;
	border: 1px solid rgba(0, 0, 0, 0.15);
	border-radius: 0;
	box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.175);
}

.dropup .dropdown-menu {
	margin-top: 0;
	margin-bottom: 0.125rem;
}

.dropup .dropdown-toggle::after {
	display: inline-block;
	width: 0;
	height: 0;
	margin-left: 0.255em;
	vertical-align: 0.255em;
	content: "";
	border-top: 0;
	border-right: 0.3em solid transparent;
	border-bottom: 0.3em solid;
	border-left: 0.3em solid transparent;
}

.dropup .dropdown-toggle:empty::after {
	margin-left: 0;
}

.dropdown-divider {
	height: 0;
	margin: 0.5rem 0;
	overflow: hidden;
	border-top: 1px solid #e5e5e5;
}

.dropdown-item {
	display: block;
	width: 100%;
	padding: 0.25rem 1.5rem;
	clear: both;
	font-weight: 400;
	color: #2a2b2b;
	text-align: inherit;
	white-space: nowrap;
	background: none;
	border: 0;
}

.dropdown-item:focus, .dropdown-item:hover {
	color: #1d1e1e;
	text-decoration: none;
	background-color: #f5f5f5;
}

.dropdown-item.active, .dropdown-item:active {
	color: #2a2b2b;
	text-decoration: none;
	background-color: #37c386;
}

.dropdown-item.disabled, .dropdown-item:disabled {
	color: #dedede;
	background-color: transparent;
}

.dropdown-menu.show {
	display: block;
}

.dropdown-header {
	display: block;
	padding: 0.5rem 1.5rem;
	margin-bottom: 0;
	font-size: 12px;
	color: #dedede;
	white-space: nowrap;
}

.btn-group,
.btn-group-vertical {
	position: relative;
	display: inline-flex;
	vertical-align: middle;
}

.btn-group > .btn,
.btn-group-vertical > .btn {
	position: relative;
	flex: 0 1 auto;
}

.btn-group > .btn:hover,
.btn-group-vertical > .btn:hover {
	z-index: 2;
}

.btn-group > .btn:focus, .btn-group > .btn:active, .btn-group > .btn.active,
.btn-group-vertical > .btn:focus,
.btn-group-vertical > .btn:active,
.btn-group-vertical > .btn.active {
	z-index: 2;
}

.btn-group .btn + .btn,
.btn-group .btn + .btn-group,
.btn-group .btn-group + .btn,
.btn-group .btn-group + .btn-group,
.btn-group-vertical .btn + .btn,
.btn-group-vertical .btn + .btn-group,
.btn-group-vertical .btn-group + .btn,
.btn-group-vertical .btn-group + .btn-group {
	margin-left: -1px;
}

.btn-toolbar {
	display: flex;
	flex-wrap: wrap;
	justify-content: flex-start;
}

.btn-toolbar .input-group {
	width: auto;
}

.btn-group > .btn:not(:first-child):not(:last-child):not(.dropdown-toggle) {
	border-radius: 0;
}

.btn-group > .btn:first-child {
	margin-left: 0;
}

.btn-group > .btn:first-child:not(:last-child):not(.dropdown-toggle) {
	border-top-right-radius: 0;
	border-bottom-right-radius: 0;
}

.btn-group > .btn:last-child:not(:first-child),
.btn-group > .dropdown-toggle:not(:first-child) {
	border-top-left-radius: 0;
	border-bottom-left-radius: 0;
}

.btn-group > .btn-group {
	float: left;
}

.btn-group > .btn-group:not(:first-child):not(:last-child) > .btn {
	border-radius: 0;
}

.btn-group > .btn-group:first-child:not(:last-child) > .btn:last-child,
.btn-group > .btn-group:first-child:not(:last-child) > .dropdown-toggle {
	border-top-right-radius: 0;
	border-bottom-right-radius: 0;
}

.btn-group > .btn-group:last-child:not(:first-child) > .btn:first-child {
	border-top-left-radius: 0;
	border-bottom-left-radius: 0;
}

.btn + .dropdown-toggle-split {
	padding-right: 26.25px;
	padding-left: 26.25px;
}

.btn + .dropdown-toggle-split::after {
	margin-left: 0;
}

.btn-sm + .dropdown-toggle-split, .btn-group-sm > .btn + .dropdown-toggle-split {
	padding-right: 18.75px;
	padding-left: 18.75px;
}

.btn-lg + .dropdown-toggle-split, .btn-group-lg > .btn + .dropdown-toggle-split {
	padding-right: 37.5px;
	padding-left: 37.5px;
}

.btn-group.show .dropdown-toggle {
	box-shadow: 0;
}

.btn-group.show .dropdown-toggle.btn-link {
	box-shadow: none;
}

.btn-group-vertical {
	flex-direction: column;
	align-items: flex-start;
	justify-content: center;
}

.btn-group-vertical .btn,
.btn-group-vertical .btn-group {
	width: 100%;
}

.btn-group-vertical > .btn + .btn,
.btn-group-vertical > .btn + .btn-group,
.btn-group-vertical > .btn-group + .btn,
.btn-group-vertical > .btn-group + .btn-group {
	margin-top: -1px;
	margin-left: 0;
}

.btn-group-vertical > .btn:not(:first-child):not(:last-child) {
	border-radius: 0;
}

.btn-group-vertical > .btn:first-child:not(:last-child) {
	border-bottom-right-radius: 0;
	border-bottom-left-radius: 0;
}

.btn-group-vertical > .btn:last-child:not(:first-child) {
	border-top-left-radius: 0;
	border-top-right-radius: 0;
}

.btn-group-vertical > .btn-group:not(:first-child):not(:last-child) > .btn {
	border-radius: 0;
}

.btn-group-vertical > .btn-group:first-child:not(:last-child) > .btn:last-child,
.btn-group-vertical > .btn-group:first-child:not(:last-child) > .dropdown-toggle {
	border-bottom-right-radius: 0;
	border-bottom-left-radius: 0;
}

.btn-group-vertical > .btn-group:last-child:not(:first-child) > .btn:first-child {
	border-top-left-radius: 0;
	border-top-right-radius: 0;
}

[data-toggle="buttons"] > .btn input[type="radio"],
[data-toggle="buttons"] > .btn input[type="checkbox"],
[data-toggle="buttons"] > .btn-group > .btn input[type="radio"],
[data-toggle="buttons"] > .btn-group > .btn input[type="checkbox"] {
	position: absolute;
	clip: rect(0, 0, 0, 0);
	pointer-events: none;
}

.input-group {
	position: relative;
	display: flex;
	align-items: stretch;
	width: 100%;
}

.input-group .form-input {
	position: relative;
	z-index: 2;
	flex: 1 1 auto;
	width: 1%;
	margin-bottom: 0;
}

.input-group .form-input:focus, .input-group .form-input:active, .input-group .form-input:hover {
	z-index: 3;
}

.input-group-addon,
.input-group-btn,
.input-group .form-input {
	display: flex;
	align-items: center;
}

.input-group-addon:not(:first-child):not(:last-child),
.input-group-btn:not(:first-child):not(:last-child),
.input-group .form-input:not(:first-child):not(:last-child) {
	border-radius: 0;
}

.input-group-addon,
.input-group-btn {
	white-space: nowrap;
}

.input-group-addon {
	padding: 11px 35px;
	margin-bottom: 0;
	font-size: 14px;
	font-weight: 400;
	line-height: 1.25;
	color: #495057;
	text-align: center;
	background-color: #e9ecef;
	border: 1px solid #ced4da;
	border-radius: 0.25rem;
}

.input-group-addon.form-input-sm,
.input-group-sm > .input-group-addon,
.input-group-sm > .input-group-btn > .input-group-addon.btn {
	padding: 5px 25px;
	font-size: 12px;
	border-radius: 0.2rem;
}

.input-group-addon.form-input-lg,
.input-group-lg > .input-group-addon,
.input-group-lg > .input-group-btn > .input-group-addon.btn {
	padding: 12px 50px;
	font-size: 18px;
	border-radius: 0.3rem;
}

.input-group-addon input[type="radio"],
.input-group-addon input[type="checkbox"] {
	margin-top: 0;
}

.input-group .form-input:not(:last-child),
.input-group-addon:not(:last-child),
.input-group-btn:not(:last-child) > .btn,
.input-group-btn:not(:last-child) > .btn-group > .btn,
.input-group-btn:not(:last-child) > .dropdown-toggle,
.input-group-btn:not(:first-child) > .btn:not(:last-child):not(.dropdown-toggle),
.input-group-btn:not(:first-child) > .btn-group:not(:last-child) > .btn {
	border-top-right-radius: 0;
	border-bottom-right-radius: 0;
}

.input-group-addon:not(:last-child) {
	border-right: 0;
}

.input-group .form-input:not(:first-child),
.input-group-addon:not(:first-child),
.input-group-btn:not(:first-child) > .btn,
.input-group-btn:not(:first-child) > .btn-group > .btn,
.input-group-btn:not(:first-child) > .dropdown-toggle,
.input-group-btn:not(:last-child) > .btn:not(:first-child),
.input-group-btn:not(:last-child) > .btn-group:not(:first-child) > .btn {
	border-top-left-radius: 0;
	border-bottom-left-radius: 0;
}

.form-input + .input-group-addon:not(:first-child) {
	border-left: 0;
}

.input-group-btn {
	position: relative;
	align-items: stretch;
	font-size: 0;
	white-space: nowrap;
}

.input-group-btn > .btn {
	position: relative;
}

.input-group-btn > .btn + .btn {
	margin-left: -1px;
}

.input-group-btn > .btn:focus, .input-group-btn > .btn:active, .input-group-btn > .btn:hover {
	z-index: 3;
}

.input-group-btn:first-child > .btn + .btn {
	margin-left: 0;
}

.input-group-btn:not(:last-child) > .btn,
.input-group-btn:not(:last-child) > .btn-group {
	margin-right: -1px;
}

.input-group-btn:not(:first-child) > .btn,
.input-group-btn:not(:first-child) > .btn-group {
	z-index: 2;
	margin-left: 0;
}

.input-group-btn:not(:first-child) > .btn:first-child,
.input-group-btn:not(:first-child) > .btn-group:first-child {
	margin-left: -1px;
}

.input-group-btn:not(:first-child) > .btn:focus, .input-group-btn:not(:first-child) > .btn:active, .input-group-btn:not(:first-child) > .btn:hover,
.input-group-btn:not(:first-child) > .btn-group:focus,
.input-group-btn:not(:first-child) > .btn-group:active,
.input-group-btn:not(:first-child) > .btn-group:hover {
	z-index: 3;
}

.custom-control {
	position: relative;
	display: inline-flex;
	min-height: 1.71429rem;
	padding-left: 1.5rem;
	margin-right: 1rem;
}

.custom-control-input {
	position: absolute;
	z-index: -1;
	opacity: 0;
}

.custom-control-input:checked ~ .custom-control-indicator {
	color: #fff;
	background-color: #007bff;
	box-shadow: none;
}

.custom-control-input:focus ~ .custom-control-indicator {
	box-shadow: 0 0 0 1px #fff, 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}

.custom-control-input:active ~ .custom-control-indicator {
	color: #fff;
	background-color: #b3d7ff;
	box-shadow: none;
}

.custom-control-input:disabled ~ .custom-control-indicator {
	background-color: #e9ecef;
}

.custom-control-input:disabled ~ .custom-control-description {
	color: #868e96;
}

.custom-control-indicator {
	position: absolute;
	top: 0.35714rem;
	left: 0;
	display: block;
	width: 1rem;
	height: 1rem;
	pointer-events: none;
	user-select: none;
	background-color: #ddd;
	background-repeat: no-repeat;
	background-position: center center;
	background-size: 50% 50%;
	box-shadow: inset 0 0.25rem 0.25rem rgba(0, 0, 0, 0.1);
}

.custom-checkbox .custom-control-indicator {
	border-radius: 0.25rem;
}

.custom-checkbox .custom-control-input:checked ~ .custom-control-indicator {
	background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3E%3Cpath fill='%23fff' d='M6.564.75l-3.59 3.612-1.538-1.55L0 4.26 2.974 7.25 8 2.193z'/%3E%3C/svg%3E");
}

.custom-checkbox .custom-control-input:indeterminate ~ .custom-control-indicator {
	background-color: #007bff;
	background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 4'%3E%3Cpath stroke='%23fff' d='M0 2h4'/%3E%3C/svg%3E");
	box-shadow: none;
}

.custom-radio .custom-control-indicator {
	border-radius: 50%;
}

.custom-radio .custom-control-input:checked ~ .custom-control-indicator {
	background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3E%3Ccircle r='3' fill='%23fff'/%3E%3C/svg%3E");
}

.custom-controls-stacked {
	display: flex;
	flex-direction: column;
}

.custom-controls-stacked .custom-control {
	margin-bottom: 0.25rem;
}

.custom-controls-stacked .custom-control + .custom-control {
	margin-left: 0;
}

.custom-select {
	display: inline-block;
	max-width: 100%;
	height: calc(2.25rem + 2px);
	padding: 0.375rem 1.75rem 0.375rem 0.75rem;
	line-height: 1.5;
	color: #495057;
	vertical-align: middle;
	background: #fff url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 5'%3E%3Cpath fill='%23333' d='M2 0L0 2h4zm0 5L0 3h4z'/%3E%3C/svg%3E") no-repeat right 0.75rem center;
	background-size: 8px 10px;
	border: 1px solid #ced4da;
	border-radius: 0.25rem;
	appearance: none;
}

.custom-select:focus {
	border-color: #80bdff;
	outline: none;
	box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.075), 0 0 5px rgba(128, 189, 255, 0.5);
}

.custom-select[multiple] {
	height: auto;
	background-image: none;
}

.custom-select:disabled {
	color: #868e96;
	background-color: #e9ecef;
}

.custom-select::-ms-expand {
	opacity: 0;
}

.custom-select-sm {
	height: calc(1.8125rem + 2px);
	padding-top: 0.375rem;
	padding-bottom: 0.375rem;
	font-size: 75%;
}

.custom-file {
	position: relative;
	display: inline-block;
	max-width: 100%;
	height: calc(2.25rem + 2px);
	margin-bottom: 0;
}

.custom-file-input {
	min-width: 14rem;
	max-width: 100%;
	height: calc(2.25rem + 2px);
	margin: 0;
	opacity: 0;
}

.custom-file-input:focus ~ .custom-file-control {
	box-shadow: 0 0 0 0.075rem #fff, 0 0 0 0.2rem #007bff;
}

.custom-file-control {
	position: absolute;
	top: 0;
	right: 0;
	left: 0;
	z-index: 5;
	height: calc(2.25rem + 2px);
	padding: 0.375rem 0.75rem;
	line-height: 1.5;
	color: #495057;
	pointer-events: none;
	user-select: none;
	background-color: #fff;
	border: 1px solid #ced4da;
	border-radius: 0.25rem;
	box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
}

.custom-file-control:lang(en):empty::after {
	content: "Choose file...";
}

.custom-file-control::before {
	position: absolute;
	top: -1px;
	right: -1px;
	bottom: -1px;
	z-index: 6;
	display: block;
	height: calc(2.25rem + 2px);
	padding: 0.375rem 0.75rem;
	line-height: 1.5;
	color: #495057;
	background-color: #e9ecef;
	border: 1px solid #ced4da;
	border-radius: 0 0.25rem 0.25rem 0;
}

.custom-file-control:lang(en)::before {
	content: "Browse";
}

.nav {
	display: flex;
	flex-wrap: wrap;
	padding-left: 0;
	margin-bottom: 0;
	list-style: none;
}

.nav-link {
	display: block;
	padding: 0.5rem 1rem;
}

.nav-link:focus, .nav-link:hover {
	text-decoration: none;
}

.nav-link.disabled {
	color: #868e96;
}

.nav-tabs {
	border-bottom: 1px solid #ddd;
}

.nav-tabs .nav-item {
	margin-bottom: -1px;
}

.nav-tabs .nav-link {
	border: 1px solid transparent;
	border-top-left-radius: 0.25rem;
	border-top-right-radius: 0.25rem;
}

.nav-tabs .nav-link:focus, .nav-tabs .nav-link:hover {
	border-color: #f9f9f9 #f9f9f9 #ddd;
}

.nav-tabs .nav-link.disabled {
	color: #868e96;
	background-color: transparent;
	border-color: transparent;
}

.nav-tabs .nav-link.active,
.nav-tabs .nav-item.show .nav-link {
	color: #495057;
	background-color: #fff;
	border-color: #ddd #ddd #fff;
}

.nav-tabs .dropdown-menu {
	margin-top: -1px;
	border-top-left-radius: 0;
	border-top-right-radius: 0;
}

.nav-pills .nav-link {
	border-radius: 0;
}

.nav-pills .nav-link.active,
.nav-pills .show > .nav-link {
	color: #fff;
	background-color: #007bff;
}

.nav-fill .nav-item {
	flex: 1 1 auto;
	text-align: center;
}

.nav-justified .nav-item {
	flex-basis: 0;
	flex-grow: 1;
	text-align: center;
}

.tab-content > .tab-pane {
	display: none;
}

.tab-content > .active {
	display: block;
}

.navbar {
	position: relative;
	display: flex;
	flex-wrap: wrap;
	align-items: center;
	justify-content: space-between;
	padding: 0.5rem 1rem;
}

.navbar > .container,
.navbar > .container-fluid {
	display: flex;
	flex-wrap: wrap;
	align-items: center;
	justify-content: space-between;
}

.navbar-brand {
	display: inline-block;
	padding-top: 0.3125rem;
	padding-bottom: 0.3125rem;
	margin-right: 1rem;
	font-size: 1.25rem;
	line-height: inherit;
	white-space: nowrap;
}

.navbar-brand:focus, .navbar-brand:hover {
	text-decoration: none;
}

.navbar-nav {
	display: flex;
	flex-direction: column;
	padding-left: 0;
	margin-bottom: 0;
	list-style: none;
}

.navbar-nav .nav-link {
	padding-right: 0;
	padding-left: 0;
}

.navbar-nav .dropdown-menu {
	position: static;
	float: none;
}

.navbar-text {
	display: inline-block;
	padding-top: 0.5rem;
	padding-bottom: 0.5rem;
}

.navbar-collapse {
	flex-basis: 100%;
	flex-grow: 1;
	align-items: center;
}

.navbar-toggler {
	padding: 0.25rem 0.75rem;
	font-size: 1.25rem;
	line-height: 1;
	background: transparent;
	border: 1px solid transparent;
	border-radius: 0.25rem;
}

.navbar-toggler:focus, .navbar-toggler:hover {
	text-decoration: none;
}

.navbar-toggler-icon {
	display: inline-block;
	width: 1.5em;
	height: 1.5em;
	vertical-align: middle;
	content: "";
	background: no-repeat center center;
	background-size: 100% 100%;
}

@media (max-width: 575px) {
	.navbar-expand-sm > .container,
	.navbar-expand-sm > .container-fluid {
		padding-right: 0;
		padding-left: 0;
	}
}

@media (min-width: 576px) {
	.navbar-expand-sm {
		flex-flow: row nowrap;
		justify-content: flex-start;
	}
	.navbar-expand-sm .navbar-nav {
		flex-direction: row;
	}
	.navbar-expand-sm .navbar-nav .dropdown-menu {
		position: absolute;
	}
	.navbar-expand-sm .navbar-nav .dropdown-menu-right {
		right: 0;
		left: auto;
	}
	.navbar-expand-sm .navbar-nav .nav-link {
		padding-right: .5rem;
		padding-left: .5rem;
	}
	.navbar-expand-sm > .container,
	.navbar-expand-sm > .container-fluid {
		flex-wrap: nowrap;
	}
	.navbar-expand-sm .navbar-collapse {
		display: flex !important;
		flex-basis: auto;
	}
	.navbar-expand-sm .navbar-toggler {
		display: none;
	}
	.navbar-expand-sm .dropup .dropdown-menu {
		top: auto;
		bottom: 100%;
	}
}

@media (max-width: 767px) {
	.navbar-expand-md > .container,
	.navbar-expand-md > .container-fluid {
		padding-right: 0;
		padding-left: 0;
	}
}

@media (min-width: 768px) {
	.navbar-expand-md {
		flex-flow: row nowrap;
		justify-content: flex-start;
	}
	.navbar-expand-md .navbar-nav {
		flex-direction: row;
	}
	.navbar-expand-md .navbar-nav .dropdown-menu {
		position: absolute;
	}
	.navbar-expand-md .navbar-nav .dropdown-menu-right {
		right: 0;
		left: auto;
	}
	.navbar-expand-md .navbar-nav .nav-link {
		padding-right: .5rem;
		padding-left: .5rem;
	}
	.navbar-expand-md > .container,
	.navbar-expand-md > .container-fluid {
		flex-wrap: nowrap;
	}
	.navbar-expand-md .navbar-collapse {
		display: flex !important;
		flex-basis: auto;
	}
	.navbar-expand-md .navbar-toggler {
		display: none;
	}
	.navbar-expand-md .dropup .dropdown-menu {
		top: auto;
		bottom: 100%;
	}
}

@media (max-width: 991px) {
	.navbar-expand-lg > .container,
	.navbar-expand-lg > .container-fluid {
		padding-right: 0;
		padding-left: 0;
	}
}

@media (min-width: 992px) {
	.navbar-expand-lg {
		flex-flow: row nowrap;
		justify-content: flex-start;
	}
	.navbar-expand-lg .navbar-nav {
		flex-direction: row;
	}
	.navbar-expand-lg .navbar-nav .dropdown-menu {
		position: absolute;
	}
	.navbar-expand-lg .navbar-nav .dropdown-menu-right {
		right: 0;
		left: auto;
	}
	.navbar-expand-lg .navbar-nav .nav-link {
		padding-right: .5rem;
		padding-left: .5rem;
	}
	.navbar-expand-lg > .container,
	.navbar-expand-lg > .container-fluid {
		flex-wrap: nowrap;
	}
	.navbar-expand-lg .navbar-collapse {
		display: flex !important;
		flex-basis: auto;
	}
	.navbar-expand-lg .navbar-toggler {
		display: none;
	}
	.navbar-expand-lg .dropup .dropdown-menu {
		top: auto;
		bottom: 100%;
	}
}

@media (max-width: 1199px) {
	.navbar-expand-xl > .container,
	.navbar-expand-xl > .container-fluid {
		padding-right: 0;
		padding-left: 0;
	}
}

@media (min-width: 1200px) {
	.navbar-expand-xl {
		flex-flow: row nowrap;
		justify-content: flex-start;
	}
	.navbar-expand-xl .navbar-nav {
		flex-direction: row;
	}
	.navbar-expand-xl .navbar-nav .dropdown-menu {
		position: absolute;
	}
	.navbar-expand-xl .navbar-nav .dropdown-menu-right {
		right: 0;
		left: auto;
	}
	.navbar-expand-xl .navbar-nav .nav-link {
		padding-right: .5rem;
		padding-left: .5rem;
	}
	.navbar-expand-xl > .container,
	.navbar-expand-xl > .container-fluid {
		flex-wrap: nowrap;
	}
	.navbar-expand-xl .navbar-collapse {
		display: flex !important;
		flex-basis: auto;
	}
	.navbar-expand-xl .navbar-toggler {
		display: none;
	}
	.navbar-expand-xl .dropup .dropdown-menu {
		top: auto;
		bottom: 100%;
	}
}

@media (max-width: 1799px) {
	.navbar-expand-xxl > .container,
	.navbar-expand-xxl > .container-fluid {
		padding-right: 0;
		padding-left: 0;
	}
}

@media (min-width: 1800px) {
	.navbar-expand-xxl {
		flex-flow: row nowrap;
		justify-content: flex-start;
	}
	.navbar-expand-xxl .navbar-nav {
		flex-direction: row;
	}
	.navbar-expand-xxl .navbar-nav .dropdown-menu {
		position: absolute;
	}
	.navbar-expand-xxl .navbar-nav .dropdown-menu-right {
		right: 0;
		left: auto;
	}
	.navbar-expand-xxl .navbar-nav .nav-link {
		padding-right: .5rem;
		padding-left: .5rem;
	}
	.navbar-expand-xxl > .container,
	.navbar-expand-xxl > .container-fluid {
		flex-wrap: nowrap;
	}
	.navbar-expand-xxl .navbar-collapse {
		display: flex !important;
		flex-basis: auto;
	}
	.navbar-expand-xxl .navbar-toggler {
		display: none;
	}
	.navbar-expand-xxl .dropup .dropdown-menu {
		top: auto;
		bottom: 100%;
	}
}

.navbar-expand {
	flex-flow: row nowrap;
	justify-content: flex-start;
}

.navbar-expand > .container,
.navbar-expand > .container-fluid {
	padding-right: 0;
	padding-left: 0;
}

.navbar-expand .navbar-nav {
	flex-direction: row;
}

.navbar-expand .navbar-nav .dropdown-menu {
	position: absolute;
}

.navbar-expand .navbar-nav .dropdown-menu-right {
	right: 0;
	left: auto;
}

.navbar-expand .navbar-nav .nav-link {
	padding-right: .5rem;
	padding-left: .5rem;
}

.navbar-expand > .container,
.navbar-expand > .container-fluid {
	flex-wrap: nowrap;
}

.navbar-expand .navbar-collapse {
	display: flex !important;
	flex-basis: auto;
}

.navbar-expand .navbar-toggler {
	display: none;
}

.navbar-expand .dropup .dropdown-menu {
	top: auto;
	bottom: 100%;
}

.navbar-light .navbar-brand {
	color: rgba(0, 0, 0, 0.9);
}

.navbar-light .navbar-brand:focus, .navbar-light .navbar-brand:hover {
	color: rgba(0, 0, 0, 0.9);
}

.navbar-light .navbar-nav .nav-link {
	color: rgba(0, 0, 0, 0.5);
}

.navbar-light .navbar-nav .nav-link:focus, .navbar-light .navbar-nav .nav-link:hover {
	color: rgba(0, 0, 0, 0.7);
}

.navbar-light .navbar-nav .nav-link.disabled {
	color: rgba(0, 0, 0, 0.3);
}

.navbar-light .navbar-nav .show > .nav-link,
.navbar-light .navbar-nav .active > .nav-link,
.navbar-light .navbar-nav .nav-link.show,
.navbar-light .navbar-nav .nav-link.active {
	color: rgba(0, 0, 0, 0.9);
}

.navbar-light .navbar-toggler {
	color: rgba(0, 0, 0, 0.5);
	border-color: rgba(0, 0, 0, 0.1);
}

.navbar-light .navbar-toggler-icon {
	background-image: url("data:image/svg+xml;charset=utf8,%3Csvg viewBox='0 0 30 30' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath stroke='rgba(0, 0, 0, 0.5)' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 7h22M4 15h22M4 23h22'/%3E%3C/svg%3E");
}

.navbar-light .navbar-text {
	color: rgba(0, 0, 0, 0.5);
}

.navbar-light .navbar-text a {
	color: rgba(0, 0, 0, 0.9);
}

.navbar-light .navbar-text a:focus, .navbar-light .navbar-text a:hover {
	color: rgba(0, 0, 0, 0.9);
}

.navbar-dark .navbar-brand {
	color: #fff;
}

.navbar-dark .navbar-brand:focus, .navbar-dark .navbar-brand:hover {
	color: #fff;
}

.navbar-dark .navbar-nav .nav-link {
	color: rgba(255, 255, 255, 0.5);
}

.navbar-dark .navbar-nav .nav-link:focus, .navbar-dark .navbar-nav .nav-link:hover {
	color: rgba(255, 255, 255, 0.75);
}

.navbar-dark .navbar-nav .nav-link.disabled {
	color: rgba(255, 255, 255, 0.25);
}

.navbar-dark .navbar-nav .show > .nav-link,
.navbar-dark .navbar-nav .active > .nav-link,
.navbar-dark .navbar-nav .nav-link.show,
.navbar-dark .navbar-nav .nav-link.active {
	color: #fff;
}

.navbar-dark .navbar-toggler {
	color: rgba(255, 255, 255, 0.5);
	border-color: rgba(255, 255, 255, 0.1);
}

.navbar-dark .navbar-toggler-icon {
	background-image: url("data:image/svg+xml;charset=utf8,%3Csvg viewBox='0 0 30 30' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath stroke='rgba(255, 255, 255, 0.5)' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 7h22M4 15h22M4 23h22'/%3E%3C/svg%3E");
}

.navbar-dark .navbar-text {
	color: rgba(255, 255, 255, 0.5);
}

.navbar-dark .navbar-text a {
	color: #fff;
}

.navbar-dark .navbar-text a:focus, .navbar-dark .navbar-text a:hover {
	color: #fff;
}

.breadcrumb {
	display: flex;
	flex-wrap: wrap;
	padding: 0.75rem 1rem;
	margin-bottom: 1rem;
	list-style: none;
	background-color: #e9ecef;
	border-radius: 0;
}

.breadcrumb-item + .breadcrumb-item::before {
	display: inline-block;
	padding-right: 0.5rem;
	padding-left: 0.5rem;
	color: #868e96;
	content: "/";
}

.breadcrumb-item + .breadcrumb-item:hover::before {
	text-decoration: underline;
}

.breadcrumb-item + .breadcrumb-item:hover::before {
	text-decoration: none;
}

.breadcrumb-item.active {
	color: #868e96;
}

.pagination {
	display: flex;
	padding-left: 0;
	list-style: none;
	border-radius: 0;
}

.page-item:first-child .page-link {
	margin-left: 0;
	border-top-left-radius: 0;
	border-bottom-left-radius: 0;
}

.page-item:last-child .page-link {
	border-top-right-radius: 0;
	border-bottom-right-radius: 0;
}

.page-item.active .page-link {
	z-index: 2;
	color: #fff;
	background-color: #37c386;
	border-color: #37c386;
}

.page-item.disabled .page-link {
	pointer-events: none;
	background-color: #cdcdcd;
	border-color: #cdcdcd;
}

.page-link {
	position: relative;
	display: block;
	padding: 10px 10px;
	margin-left: -2px;
	line-height: 24px;
	color: #000;
	background-color: transparent;
	border: 2px solid #cdcdcd;
}

.page-link:focus, .page-link:hover {
	color: #fff;
	text-decoration: none;
	background-color: #37c386;
	border-color: #37c386;
}

.pagination-lg .page-link {
	padding: 0.75rem 1.5rem;
	font-size: 18px;
	line-height: 1.33333;
}

.pagination-lg .page-item:first-child .page-link {
	border-top-left-radius: 6px;
	border-bottom-left-radius: 6px;
}

.pagination-lg .page-item:last-child .page-link {
	border-top-right-radius: 6px;
	border-bottom-right-radius: 6px;
}

.pagination-sm .page-link {
	padding: 0.25rem 0.5rem;
	font-size: 12px;
	line-height: 1.5;
}

.pagination-sm .page-item:first-child .page-link {
	border-top-left-radius: 3px;
	border-bottom-left-radius: 3px;
}

.pagination-sm .page-item:last-child .page-link {
	border-top-right-radius: 3px;
	border-bottom-right-radius: 3px;
}

.badge {
	display: inline-block;
	padding: 0.25em 0.4em;
	font-size: 75%;
	font-weight: 700;
	line-height: 1;
	text-align: center;
	white-space: nowrap;
	vertical-align: baseline;
	border-radius: 0.25rem;
}

.badge:empty {
	display: none;
}

.btn .badge {
	position: relative;
	top: -1px;
}

.badge-pill {
	padding-right: 0.6em;
	padding-left: 0.6em;
	border-radius: 10rem;
}

.badge-primary {
	color: #fff;
	background-color: #007bff;
}

.badge-primary[href]:focus, .badge-primary[href]:hover {
	color: #fff;
	text-decoration: none;
	background-color: #0062cc;
}

.badge-secondary {
	color: #fff;
	background-color: #868e96;
}

.badge-secondary[href]:focus, .badge-secondary[href]:hover {
	color: #fff;
	text-decoration: none;
	background-color: #6c757d;
}

.badge-success {
	color: #fff;
	background-color: #28a745;
}

.badge-success[href]:focus, .badge-success[href]:hover {
	color: #fff;
	text-decoration: none;
	background-color: #1e7e34;
}

.badge-info {
	color: #fff;
	background-color: #17a2b8;
}

.badge-info[href]:focus, .badge-info[href]:hover {
	color: #fff;
	text-decoration: none;
	background-color: #117a8b;
}

.badge-warning {
	color: #111;
	background-color: #ffc107;
}

.badge-warning[href]:focus, .badge-warning[href]:hover {
	color: #111;
	text-decoration: none;
	background-color: #d39e00;
}

.badge-danger {
	color: #fff;
	background-color: #dc3545;
}

.badge-danger[href]:focus, .badge-danger[href]:hover {
	color: #fff;
	text-decoration: none;
	background-color: #bd2130;
}

.badge-light {
	color: #111;
	background-color: #f8f9fa;
}

.badge-light[href]:focus, .badge-light[href]:hover {
	color: #111;
	text-decoration: none;
	background-color: #dae0e5;
}

.badge-dark {
	color: #fff;
	background-color: #343a40;
}

.badge-dark[href]:focus, .badge-dark[href]:hover {
	color: #fff;
	text-decoration: none;
	background-color: #1d2124;
}

.jumbotron {
	padding: 2rem 1rem;
	margin-bottom: 2rem;
	background-color: #e9ecef;
	border-radius: 6px;
}

@media (min-width: 576px) {
	.jumbotron {
		padding: 4rem 2rem;
	}
}

.jumbotron-fluid {
	padding-right: 0;
	padding-left: 0;
	border-radius: 0;
}

.alert {
	position: relative;
	padding: 0.75rem 1.25rem;
	margin-bottom: 1rem;
	border: 1px solid transparent;
	border-radius: 0.25rem;
}

.alert-heading {
	color: inherit;
}

.alert-link {
	font-weight: 700;
}

.alert-dismissible .close {
	position: absolute;
	top: 0;
	right: 0;
	padding: 0.75rem 1.25rem;
	color: inherit;
}

.alert-primary {
	color: #004085;
	background-color: #cce5ff;
	border-color: #b8daff;
}

.alert-primary hr {
	border-top-color: #9fcdff;
}

.alert-primary .alert-link {
	color: #002752;
}

.alert-secondary {
	color: #464a4e;
	background-color: #e7e8ea;
	border-color: #dddfe2;
}

.alert-secondary hr {
	border-top-color: #cfd2d6;
}

.alert-secondary .alert-link {
	color: #2e3133;
}

.alert-success {
	color: #155724;
	background-color: #d4edda;
	border-color: #c3e6cb;
}

.alert-success hr {
	border-top-color: #b1dfbb;
}

.alert-success .alert-link {
	color: #0b2e13;
}

.alert-info {
	color: #0c5460;
	background-color: #d1ecf1;
	border-color: #bee5eb;
}

.alert-info hr {
	border-top-color: #abdde5;
}

.alert-info .alert-link {
	color: #062c33;
}

.alert-warning {
	color: #856404;
	background-color: #fff3cd;
	border-color: #ffeeba;
}

.alert-warning hr {
	border-top-color: #ffe8a1;
}

.alert-warning .alert-link {
	color: #533f03;
}

.alert-danger {
	color: #721c24;
	background-color: #f8d7da;
	border-color: #f5c6cb;
}

.alert-danger hr {
	border-top-color: #f1b0b7;
}

.alert-danger .alert-link {
	color: #491217;
}

.alert-light {
	color: #818182;
	background-color: #fefefe;
	border-color: #fdfdfe;
}

.alert-light hr {
	border-top-color: #ececf6;
}

.alert-light .alert-link {
	color: #686868;
}

.alert-dark {
	color: #1b1e21;
	background-color: #d6d8d9;
	border-color: #c6c8ca;
}

.alert-dark hr {
	border-top-color: #b9bbbe;
}

.alert-dark .alert-link {
	color: #040505;
}

@keyframes progress-bar-stripes {
	from {
		background-position: 1rem 0;
	}
	to {
		background-position: 0 0;
	}
}

.progress {
	display: flex;
	height: 1rem;
	overflow: hidden;
	font-size: 0.75rem;
	background-color: #e9ecef;
	border-radius: 0.25rem;
}

.progress-bar {
	display: flex;
	align-items: center;
	justify-content: center;
	color: #fff;
	background-color: #007bff;
}

.progress-bar-striped {
	background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
	background-size: 1rem 1rem;
}

.progress-bar-animated {
	animation: progress-bar-stripes 1s linear infinite;
}

.media {
	display: flex;
	align-items: flex-start;
}

.media-body {
	flex: 1;
}

.list-group {
	display: flex;
	flex-direction: column;
	padding-left: 0;
	margin-bottom: 0;
}

.list-group-item-action {
	width: 100%;
	color: #495057;
	text-align: inherit;
}

.list-group-item-action:focus, .list-group-item-action:hover {
	color: #495057;
	text-decoration: none;
	background-color: #f8f9fa;
}

.list-group-item-action:active {
	color: #212529;
	background-color: #e9ecef;
}

.list-group-item {
	position: relative;
	display: block;
	padding: 0.75rem 1.25rem;
	margin-bottom: -1px;
	background-color: #fff;
	border: 1px solid rgba(0, 0, 0, 0.125);
}

.list-group-item:first-child {
	border-top-left-radius: 0.25rem;
	border-top-right-radius: 0.25rem;
}

.list-group-item:last-child {
	margin-bottom: 0;
	border-bottom-right-radius: 0.25rem;
	border-bottom-left-radius: 0.25rem;
}

.list-group-item:focus, .list-group-item:hover {
	text-decoration: none;
}

.list-group-item.disabled, .list-group-item:disabled {
	color: #868e96;
	background-color: #fff;
}

.list-group-item.active {
	z-index: 2;
	color: #fff;
	background-color: #007bff;
	border-color: #007bff;
}

.list-group-flush .list-group-item {
	border-right: 0;
	border-left: 0;
	border-radius: 0;
}

.list-group-flush:first-child .list-group-item:first-child {
	border-top: 0;
}

.list-group-flush:last-child .list-group-item:last-child {
	border-bottom: 0;
}

.list-group-item-primary {
	color: #004085;
	background-color: #b8daff;
}

a.list-group-item-primary,
button.list-group-item-primary {
	color: #004085;
}

a.list-group-item-primary:focus, a.list-group-item-primary:hover,
button.list-group-item-primary:focus,
button.list-group-item-primary:hover {
	color: #004085;
	background-color: #9fcdff;
}

a.list-group-item-primary.active,
button.list-group-item-primary.active {
	color: #fff;
	background-color: #004085;
	border-color: #004085;
}

.list-group-item-secondary {
	color: #464a4e;
	background-color: #dddfe2;
}

a.list-group-item-secondary,
button.list-group-item-secondary {
	color: #464a4e;
}

a.list-group-item-secondary:focus, a.list-group-item-secondary:hover,
button.list-group-item-secondary:focus,
button.list-group-item-secondary:hover {
	color: #464a4e;
	background-color: #cfd2d6;
}

a.list-group-item-secondary.active,
button.list-group-item-secondary.active {
	color: #fff;
	background-color: #464a4e;
	border-color: #464a4e;
}

.list-group-item-success {
	color: #155724;
	background-color: #c3e6cb;
}

a.list-group-item-success,
button.list-group-item-success {
	color: #155724;
}

a.list-group-item-success:focus, a.list-group-item-success:hover,
button.list-group-item-success:focus,
button.list-group-item-success:hover {
	color: #155724;
	background-color: #b1dfbb;
}

a.list-group-item-success.active,
button.list-group-item-success.active {
	color: #fff;
	background-color: #155724;
	border-color: #155724;
}

.list-group-item-info {
	color: #0c5460;
	background-color: #bee5eb;
}

a.list-group-item-info,
button.list-group-item-info {
	color: #0c5460;
}

a.list-group-item-info:focus, a.list-group-item-info:hover,
button.list-group-item-info:focus,
button.list-group-item-info:hover {
	color: #0c5460;
	background-color: #abdde5;
}

a.list-group-item-info.active,
button.list-group-item-info.active {
	color: #fff;
	background-color: #0c5460;
	border-color: #0c5460;
}

.list-group-item-warning {
	color: #856404;
	background-color: #ffeeba;
}

a.list-group-item-warning,
button.list-group-item-warning {
	color: #856404;
}

a.list-group-item-warning:focus, a.list-group-item-warning:hover,
button.list-group-item-warning:focus,
button.list-group-item-warning:hover {
	color: #856404;
	background-color: #ffe8a1;
}

a.list-group-item-warning.active,
button.list-group-item-warning.active {
	color: #fff;
	background-color: #856404;
	border-color: #856404;
}

.list-group-item-danger {
	color: #721c24;
	background-color: #f5c6cb;
}

a.list-group-item-danger,
button.list-group-item-danger {
	color: #721c24;
}

a.list-group-item-danger:focus, a.list-group-item-danger:hover,
button.list-group-item-danger:focus,
button.list-group-item-danger:hover {
	color: #721c24;
	background-color: #f1b0b7;
}

a.list-group-item-danger.active,
button.list-group-item-danger.active {
	color: #fff;
	background-color: #721c24;
	border-color: #721c24;
}

.list-group-item-light {
	color: #818182;
	background-color: #fdfdfe;
}

a.list-group-item-light,
button.list-group-item-light {
	color: #818182;
}

a.list-group-item-light:focus, a.list-group-item-light:hover,
button.list-group-item-light:focus,
button.list-group-item-light:hover {
	color: #818182;
	background-color: #ececf6;
}

a.list-group-item-light.active,
button.list-group-item-light.active {
	color: #fff;
	background-color: #818182;
	border-color: #818182;
}

.list-group-item-dark {
	color: #1b1e21;
	background-color: #c6c8ca;
}

a.list-group-item-dark,
button.list-group-item-dark {
	color: #1b1e21;
}

a.list-group-item-dark:focus, a.list-group-item-dark:hover,
button.list-group-item-dark:focus,
button.list-group-item-dark:hover {
	color: #1b1e21;
	background-color: #b9bbbe;
}

a.list-group-item-dark.active,
button.list-group-item-dark.active {
	color: #fff;
	background-color: #1b1e21;
	border-color: #1b1e21;
}

.close {
	float: right;
	font-size: 1.5rem;
	font-weight: 700;
	line-height: 1;
	color: #000;
	text-shadow: 0 1px 0 #fff;
	opacity: .5;
}

.close:focus, .close:hover {
	color: #000;
	text-decoration: none;
	opacity: .75;
}

button.close {
	padding: 0;
	background: transparent;
	border: 0;
	-webkit-appearance: none;
}

.modal-open {
	overflow: hidden;
}

.modal {
	position: fixed;
	top: 0;
	right: 0;
	bottom: 0;
	left: 0;
	z-index: 1050;
	display: none;
	overflow: hidden;
	outline: 0;
}

.modal.fade .modal-dialog {
	transition: transform 0.3s ease-out;
	transform: translate(0, -25%);
}

.modal.show .modal-dialog {
	transform: translate(0, 0);
}

.modal-open .modal {
	overflow-x: hidden;
	overflow-y: auto;
}

.modal-dialog {
	position: relative;
	width: auto;
	margin: 10px;
	pointer-events: none;
}

.modal-content {
	position: relative;
	display: flex;
	flex-direction: column;
	pointer-events: auto;
	background-color: #fff;
	background-clip: padding-box;
	border: 1px solid rgba(0, 0, 0, 0.2);
	border-radius: 6px;
	box-shadow: 0 3px 9px rgba(0, 0, 0, 0.5);
	outline: 0;
}

.modal-backdrop {
	position: fixed;
	top: 0;
	right: 0;
	bottom: 0;
	left: 0;
	z-index: 1040;
	background-color: #000;
}

.modal-backdrop.fade {
	opacity: 0;
}

.modal-backdrop.show {
	opacity: 0.5;
}

.modal-header {
	display: flex;
	align-items: flex-start;
	justify-content: space-between;
	padding: 15px;
	border-bottom: 1px solid #e9ecef;
	border-top-left-radius: 6px;
	border-top-right-radius: 6px;
}

.modal-header .close {
	padding: 15px;
	margin: -15px -15px -15px auto;
}

.modal-title {
	margin-bottom: 0;
	line-height: 1.5;
}

.modal-body {
	position: relative;
	flex: 1 1 auto;
	padding: 15px;
}

.modal-footer {
	display: flex;
	align-items: center;
	justify-content: flex-end;
	padding: 15px;
	border-top: 1px solid #e9ecef;
}

.modal-footer > :not(:first-child) {
	margin-left: .25rem;
}

.modal-footer > :not(:last-child) {
	margin-right: .25rem;
}

.modal-scrollbar-measure {
	position: absolute;
	top: -9999px;
	width: 50px;
	height: 50px;
	overflow: scroll;
}

@media (min-width: 576px) {
	.modal-dialog {
		max-width: 500px;
		margin: 30px auto;
	}
	.modal-content {
		box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
	}
	.modal-sm {
		max-width: 300px;
	}
}

@media (min-width: 992px) {
	.modal-lg {
		max-width: 800px;
	}
}

.tooltip {
	position: absolute;
	z-index: 1070;
	display: block;
	margin: 0;
	font-family: "Roboto", Helvetica, Arial, sans-serif;
	font-style: normal;
	font-weight: 400;
	line-height: 1.71429;
	text-align: left;
	text-align: start;
	text-decoration: none;
	text-shadow: none;
	text-transform: none;
	letter-spacing: normal;
	word-break: normal;
	word-spacing: normal;
	white-space: normal;
	line-break: auto;
	font-size: 12px;
	word-wrap: break-word;
	opacity: 0;
}

.tooltip.show {
	opacity: 1;
}

.tooltip .arrow {
	position: absolute;
	display: block;
	width: 6px;
	height: 6px;
}

.tooltip .arrow::before {
	position: absolute;
	border-color: transparent;
	border-style: solid;
}

.tooltip.bs-tooltip-top, .tooltip.bs-tooltip-auto[x-placement^="top"] {
	padding: 6px 0;
}

.tooltip.bs-tooltip-top .arrow, .tooltip.bs-tooltip-auto[x-placement^="top"] .arrow {
	bottom: 0;
}

.tooltip.bs-tooltip-top .arrow::before, .tooltip.bs-tooltip-auto[x-placement^="top"] .arrow::before {
	margin-left: -4px;
	content: "";
	border-width: 6px 6px 0;
	border-top-color: #37c386;
}

.tooltip.bs-tooltip-right, .tooltip.bs-tooltip-auto[x-placement^="right"] {
	padding: 0 6px;
}

.tooltip.bs-tooltip-right .arrow, .tooltip.bs-tooltip-auto[x-placement^="right"] .arrow {
	left: 0;
}

.tooltip.bs-tooltip-right .arrow::before, .tooltip.bs-tooltip-auto[x-placement^="right"] .arrow::before {
	margin-top: -4px;
	content: "";
	border-width: 6px 6px 6px 0;
	border-right-color: #37c386;
}

.tooltip.bs-tooltip-bottom, .tooltip.bs-tooltip-auto[x-placement^="bottom"] {
	padding: 6px 0;
}

.tooltip.bs-tooltip-bottom .arrow, .tooltip.bs-tooltip-auto[x-placement^="bottom"] .arrow {
	top: 0;
}

.tooltip.bs-tooltip-bottom .arrow::before, .tooltip.bs-tooltip-auto[x-placement^="bottom"] .arrow::before {
	margin-left: -4px;
	content: "";
	border-width: 0 6px 6px;
	border-bottom-color: #37c386;
}

.tooltip.bs-tooltip-left, .tooltip.bs-tooltip-auto[x-placement^="left"] {
	padding: 0 6px;
}

.tooltip.bs-tooltip-left .arrow, .tooltip.bs-tooltip-auto[x-placement^="left"] .arrow {
	right: 0;
}

.tooltip.bs-tooltip-left .arrow::before, .tooltip.bs-tooltip-auto[x-placement^="left"] .arrow::before {
	right: 0;
	margin-top: -4px;
	content: "";
	border-width: 6px 0 6px 6px;
	border-left-color: #37c386;
}

.tooltip-inner {
	max-width: 200px;
	padding: 6px 10px;
	color: #fff;
	text-align: center;
	background-color: #37c386;
	border-radius: 0;
}

.popover {
	position: absolute;
	top: 0;
	left: 0;
	z-index: 1060;
	display: block;
	max-width: 276px;
	font-family: "Roboto", Helvetica, Arial, sans-serif;
	font-style: normal;
	font-weight: 400;
	line-height: 1.71429;
	text-align: left;
	text-align: start;
	text-decoration: none;
	text-shadow: none;
	text-transform: none;
	letter-spacing: normal;
	word-break: normal;
	word-spacing: normal;
	white-space: normal;
	line-break: auto;
	font-size: 12px;
	word-wrap: break-word;
	background-color: #fff;
	background-clip: padding-box;
	border: 1px solid rgba(0, 0, 0, 0.2);
	border-radius: 6px;
	box-shadow: 0 0.25rem 0.5rem rgba(0, 0, 0, 0.2);
}

.popover .arrow {
	position: absolute;
	display: block;
	width: 0.8rem;
	height: 0.4rem;
}

.popover .arrow::before,
.popover .arrow::after {
	position: absolute;
	display: block;
	border-color: transparent;
	border-style: solid;
}

.popover .arrow::before {
	content: "";
	border-width: 0.8rem;
}

.popover .arrow::after {
	content: "";
	border-width: 0.8rem;
}

.popover.bs-popover-top, .popover.bs-popover-auto[x-placement^="top"] {
	margin-bottom: 0.8rem;
}

.popover.bs-popover-top .arrow, .popover.bs-popover-auto[x-placement^="top"] .arrow {
	bottom: 0;
}

.popover.bs-popover-top .arrow::before, .popover.bs-popover-auto[x-placement^="top"] .arrow::before,
.popover.bs-popover-top .arrow::after,
.popover.bs-popover-auto[x-placement^="top"] .arrow::after {
	border-bottom-width: 0;
}

.popover.bs-popover-top .arrow::before, .popover.bs-popover-auto[x-placement^="top"] .arrow::before {
	bottom: -0.8rem;
	margin-left: -0.8rem;
	border-top-color: rgba(0, 0, 0, 0.25);
}


.popover.bs-popover-top .arrow::after,
.popover.bs-popover-auto[x-placement^="top"] .arrow::after {
	bottom: calc((0.8rem - 1px) * -1);
	margin-left: -0.8rem;
	border-top-color: #fff;
}

.popover.bs-popover-right, .popover.bs-popover-auto[x-placement^="right"] {
	margin-left: 0.8rem;
}

.popover.bs-popover-right .arrow, .popover.bs-popover-auto[x-placement^="right"] .arrow {
	left: 0;
}

.popover.bs-popover-right .arrow::before, .popover.bs-popover-auto[x-placement^="right"] .arrow::before,
.popover.bs-popover-right .arrow::after,
.popover.bs-popover-auto[x-placement^="right"] .arrow::after {
	margin-top: -0.8rem;
	border-left-width: 0;
}

.popover.bs-popover-right .arrow::before, .popover.bs-popover-auto[x-placement^="right"] .arrow::before {
	left: -0.8rem;
	border-right-color: rgba(0, 0, 0, 0.25);
}


.popover.bs-popover-right .arrow::after,
.popover.bs-popover-auto[x-placement^="right"] .arrow::after {
	left: calc((0.8rem - 1px) * -1);
	border-right-color: #fff;
}

.popover.bs-popover-bottom, .popover.bs-popover-auto[x-placement^="bottom"] {
	margin-top: 0.8rem;
}

.popover.bs-popover-bottom .arrow, .popover.bs-popover-auto[x-placement^="bottom"] .arrow {
	top: 0;
}

.popover.bs-popover-bottom .arrow::before, .popover.bs-popover-auto[x-placement^="bottom"] .arrow::before,
.popover.bs-popover-bottom .arrow::after,
.popover.bs-popover-auto[x-placement^="bottom"] .arrow::after {
	margin-left: -0.8rem;
	border-top-width: 0;
}

.popover.bs-popover-bottom .arrow::before, .popover.bs-popover-auto[x-placement^="bottom"] .arrow::before {
	top: -0.8rem;
	border-bottom-color: rgba(0, 0, 0, 0.25);
}


.popover.bs-popover-bottom .arrow::after,
.popover.bs-popover-auto[x-placement^="bottom"] .arrow::after {
	top: calc((0.8rem - 1px) * -1);
	border-bottom-color: #fff;
}

.popover.bs-popover-bottom .popover-header::before, .popover.bs-popover-auto[x-placement^="bottom"] .popover-header::before {
	position: absolute;
	top: 0;
	left: 50%;
	display: block;
	width: 20px;
	margin-left: -10px;
	content: "";
	border-bottom: 1px solid #f7f7f7;
}

.popover.bs-popover-left, .popover.bs-popover-auto[x-placement^="left"] {
	margin-right: 0.8rem;
}

.popover.bs-popover-left .arrow, .popover.bs-popover-auto[x-placement^="left"] .arrow {
	right: 0;
}

.popover.bs-popover-left .arrow::before, .popover.bs-popover-auto[x-placement^="left"] .arrow::before,
.popover.bs-popover-left .arrow::after,
.popover.bs-popover-auto[x-placement^="left"] .arrow::after {
	margin-top: -0.8rem;
	border-right-width: 0;
}

.popover.bs-popover-left .arrow::before, .popover.bs-popover-auto[x-placement^="left"] .arrow::before {
	right: -0.8rem;
	border-left-color: rgba(0, 0, 0, 0.25);
}


.popover.bs-popover-left .arrow::after,
.popover.bs-popover-auto[x-placement^="left"] .arrow::after {
	right: calc((0.8rem - 1px) * -1);
	border-left-color: #fff;
}

.popover-header {
	padding: 0.5rem 0.75rem;
	margin-bottom: 0;
	font-size: 14px;
	color: inherit;
	background-color: #f7f7f7;
	border-bottom: 1px solid #ebebeb;
	border-top-left-radius: calc(6px - 1px);
	border-top-right-radius: calc(6px - 1px);
}

.popover-header:empty {
	display: none;
}

.popover-body {
	padding: 0.5rem 0.75rem;
	color: #212529;
}

.carousel {
	position: relative;
}

.carousel-inner {
	position: relative;
	width: 100%;
	overflow: hidden;
}

.carousel-item {
	position: relative;
	display: none;
	align-items: center;
	width: 100%;
	transition: transform 0.6s ease;
	backface-visibility: hidden;
	perspective: 1000px;
}

.carousel-item.active,
.carousel-item-next,
.carousel-item-prev {
	display: block;
}

.carousel-item-next,
.carousel-item-prev {
	position: absolute;
	top: 0;
}

.carousel-item-next.carousel-item-left,
.carousel-item-prev.carousel-item-right {
	transform: translateX(0);
}

@supports (transform-style: preserve-3d) {
	.carousel-item-next.carousel-item-left,
	.carousel-item-prev.carousel-item-right {
		transform: translate3d(0, 0, 0);
	}
}

.carousel-item-next,
.active.carousel-item-right {
	transform: translateX(100%);
}

@supports (transform-style: preserve-3d) {
	.carousel-item-next,
	.active.carousel-item-right {
		transform: translate3d(100%, 0, 0);
	}
}

.carousel-item-prev,
.active.carousel-item-left {
	transform: translateX(-100%);
}

@supports (transform-style: preserve-3d) {
	.carousel-item-prev,
	.active.carousel-item-left {
		transform: translate3d(-100%, 0, 0);
	}
}

.carousel-control-prev,
.carousel-control-next {
	position: absolute;
	top: 0;
	bottom: 0;
	display: flex;
	align-items: center;
	justify-content: center;
	width: 15%;
	color: #fff;
	text-align: center;
	opacity: 0.5;
}

.carousel-control-prev:focus, .carousel-control-prev:hover,
.carousel-control-next:focus,
.carousel-control-next:hover {
	color: #fff;
	text-decoration: none;
	outline: 0;
	opacity: .9;
}

.carousel-control-prev {
	left: 0;
}

.carousel-control-next {
	right: 0;
}

.carousel-control-prev-icon,
.carousel-control-next-icon {
	display: inline-block;
	width: 20px;
	height: 20px;
	background: transparent no-repeat center center;
	background-size: 100% 100%;
}

.carousel-control-prev-icon {
	background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' viewBox='0 0 8 8'%3E%3Cpath d='M5.25 0l-4 4 4 4 1.5-1.5-2.5-2.5 2.5-2.5-1.5-1.5z'/%3E%3C/svg%3E");
}

.carousel-control-next-icon {
	background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' viewBox='0 0 8 8'%3E%3Cpath d='M2.75 0l-1.5 1.5 2.5 2.5-2.5 2.5 1.5 1.5 4-4-4-4z'/%3E%3C/svg%3E");
}

.carousel-indicators {
	position: absolute;
	right: 0;
	bottom: 10px;
	left: 0;
	z-index: 15;
	display: flex;
	justify-content: center;
	padding-left: 0;
	margin-right: 15%;
	margin-left: 15%;
	list-style: none;
}

.carousel-indicators li {
	position: relative;
	flex: 0 1 auto;
	width: 30px;
	height: 3px;
	margin-right: 3px;
	margin-left: 3px;
	text-indent: -999px;
	background-color: rgba(255, 255, 255, 0.5);
}

.carousel-indicators li::before {
	position: absolute;
	top: -10px;
	left: 0;
	display: inline-block;
	width: 100%;
	height: 10px;
	content: "";
}

.carousel-indicators li::after {
	position: absolute;
	bottom: -10px;
	left: 0;
	display: inline-block;
	width: 100%;
	height: 10px;
	content: "";
}

.carousel-indicators .active {
	background-color: #fff;
}

.carousel-caption {
	position: absolute;
	right: 15%;
	bottom: 20px;
	left: 15%;
	z-index: 10;
	padding-top: 20px;
	padding-bottom: 20px;
	color: #fff;
	text-align: center;
}

.align-baseline {
	vertical-align: baseline !important;
}

.align-top {
	vertical-align: top !important;
}

.align-middle {
	vertical-align: middle !important;
}

.align-bottom {
	vertical-align: bottom !important;
}

.align-text-bottom {
	vertical-align: text-bottom !important;
}

.align-text-top {
	vertical-align: text-top !important;
}

.bg-primary {
	background-color: #007bff !important;
}

a.bg-primary:focus, a.bg-primary:hover {
	background-color: #0062cc !important;
}

.bg-secondary {
	background-color: #868e96 !important;
}

a.bg-secondary:focus, a.bg-secondary:hover {
	background-color: #6c757d !important;
}

.bg-success {
	background-color: #28a745 !important;
}

a.bg-success:focus, a.bg-success:hover {
	background-color: #1e7e34 !important;
}

.bg-info {
	background-color: #17a2b8 !important;
}

a.bg-info:focus, a.bg-info:hover {
	background-color: #117a8b !important;
}

.bg-warning {
	background-color: #ffc107 !important;
}

a.bg-warning:focus, a.bg-warning:hover {
	background-color: #d39e00 !important;
}

.bg-danger {
	background-color: #dc3545 !important;
}

a.bg-danger:focus, a.bg-danger:hover {
	background-color: #bd2130 !important;
}

.bg-light {
	background-color: #f8f9fa !important;
}

a.bg-light:focus, a.bg-light:hover {
	background-color: #dae0e5 !important;
}

.bg-dark {
	background-color: #343a40 !important;
}

a.bg-dark:focus, a.bg-dark:hover {
	background-color: #1d2124 !important;
}

.bg-default {
	background-color: #fff !important;
}

.bg-transparent {
	background-color: transparent !important;
}

.border {
	border: 1px solid #e9ecef !important;
}

.border-0 {
	border: 0 !important;
}

.border-top-0 {
	border-top: 0 !important;
}

.border-right-0 {
	border-right: 0 !important;
}

.border-bottom-0 {
	border-bottom: 0 !important;
}

.border-left-0 {
	border-left: 0 !important;
}

.border-primary {
	border-color: #007bff !important;
}

.border-secondary {
	border-color: #868e96 !important;
}

.border-success {
	border-color: #28a745 !important;
}

.border-info {
	border-color: #17a2b8 !important;
}

.border-warning {
	border-color: #ffc107 !important;
}

.border-danger {
	border-color: #dc3545 !important;
}

.border-light {
	border-color: #f8f9fa !important;
}

.border-dark {
	border-color: #343a40 !important;
}

.border-white {
	border-color: #fff !important;
}

.rounded {
	border-radius: 0 !important;
}

.rounded-top {
	border-top-left-radius: 0 !important;
	border-top-right-radius: 0 !important;
}

.rounded-right {
	border-top-right-radius: 0 !important;
	border-bottom-right-radius: 0 !important;
}

.rounded-bottom {
	border-bottom-right-radius: 0 !important;
	border-bottom-left-radius: 0 !important;
}

.rounded-left {
	border-top-left-radius: 0 !important;
	border-bottom-left-radius: 0 !important;
}

.rounded-circle {
	border-radius: 50% !important;
}

.rounded-0 {
	border-radius: 0 !important;
}

.clearfix::after {
	display: block;
	clear: both;
	content: "";
}

.d-none {
	display: none !important;
}

.d-inline {
	display: inline !important;
}

.d-inline-block {
	display: inline-block !important;
}

.d-block {
	display: block !important;
}

.d-table {
	display: table !important;
}

.d-table-row {
	display: table-row !important;
}

.d-table-cell {
	display: table-cell !important;
}

.d-flex {
	display: flex !important;
}

.d-inline-flex {
	display: inline-flex !important;
}

@media (min-width: 576px) {
	.d-sm-none {
		display: none !important;
	}
	.d-sm-inline {
		display: inline !important;
	}
	.d-sm-inline-block {
		display: inline-block !important;
	}
	.d-sm-block {
		display: block !important;
	}
	.d-sm-table {
		display: table !important;
	}
	.d-sm-table-row {
		display: table-row !important;
	}
	.d-sm-table-cell {
		display: table-cell !important;
	}
	.d-sm-flex {
		display: flex !important;
	}
	.d-sm-inline-flex {
		display: inline-flex !important;
	}
}

@media (min-width: 768px) {
	.d-md-none {
		display: none !important;
	}
	.d-md-inline {
		display: inline !important;
	}
	.d-md-inline-block {
		display: inline-block !important;
	}
	.d-md-block {
		display: block !important;
	}
	.d-md-table {
		display: table !important;
	}
	.d-md-table-row {
		display: table-row !important;
	}
	.d-md-table-cell {
		display: table-cell !important;
	}
	.d-md-flex {
		display: flex !important;
	}
	.d-md-inline-flex {
		display: inline-flex !important;
	}
}

@media (min-width: 992px) {
	.d-lg-none {
		display: none !important;
	}
	.d-lg-inline {
		display: inline !important;
	}
	.d-lg-inline-block {
		display: inline-block !important;
	}
	.d-lg-block {
		display: block !important;
	}
	.d-lg-table {
		display: table !important;
	}
	.d-lg-table-row {
		display: table-row !important;
	}
	.d-lg-table-cell {
		display: table-cell !important;
	}
	.d-lg-flex {
		display: flex !important;
	}
	.d-lg-inline-flex {
		display: inline-flex !important;
	}
}

@media (min-width: 1200px) {
	.d-xl-none {
		display: none !important;
	}
	.d-xl-inline {
		display: inline !important;
	}
	.d-xl-inline-block {
		display: inline-block !important;
	}
	.d-xl-block {
		display: block !important;
	}
	.d-xl-table {
		display: table !important;
	}
	.d-xl-table-row {
		display: table-row !important;
	}
	.d-xl-table-cell {
		display: table-cell !important;
	}
	.d-xl-flex {
		display: flex !important;
	}
	.d-xl-inline-flex {
		display: inline-flex !important;
	}
}

@media (min-width: 1800px) {
	.d-xxl-none {
		display: none !important;
	}
	.d-xxl-inline {
		display: inline !important;
	}
	.d-xxl-inline-block {
		display: inline-block !important;
	}
	.d-xxl-block {
		display: block !important;
	}
	.d-xxl-table {
		display: table !important;
	}
	.d-xxl-table-row {
		display: table-row !important;
	}
	.d-xxl-table-cell {
		display: table-cell !important;
	}
	.d-xxl-flex {
		display: flex !important;
	}
	.d-xxl-inline-flex {
		display: inline-flex !important;
	}
}

.d-print-block {
	display: none !important;
}

@media print {
	.d-print-block {
		display: block !important;
	}
}

.d-print-inline {
	display: none !important;
}

@media print {
	.d-print-inline {
		display: inline !important;
	}
}

.d-print-inline-block {
	display: none !important;
}

@media print {
	.d-print-inline-block {
		display: inline-block !important;
	}
}

@media print {
	.d-print-none {
		display: none !important;
	}
}

.embed-responsive {
	position: relative;
	display: block;
	width: 100%;
	padding: 0;
	overflow: hidden;
}

.embed-responsive::before {
	display: block;
	content: "";
}

.embed-responsive .embed-responsive-item,
.embed-responsive iframe,
.embed-responsive embed,
.embed-responsive object,
.embed-responsive video {
	position: absolute;
	top: 0;
	bottom: 0;
	left: 0;
	width: 100%;
	height: 100%;
	border: 0;
}

.embed-responsive-21by9::before {
	padding-top: 42.85714%;
}

.embed-responsive-16by9::before {
	padding-top: 56.25%;
}

.embed-responsive-4by3::before {
	padding-top: 75%;
}

.embed-responsive-1by1::before {
	padding-top: 100%;
}

.flex-row {
	flex-direction: row !important;
}

.flex-column {
	flex-direction: column !important;
}

.flex-row-reverse {
	flex-direction: row-reverse !important;
}

.flex-column-reverse {
	flex-direction: column-reverse !important;
}

.flex-wrap {
	flex-wrap: wrap !important;
}

.flex-nowrap {
	flex-wrap: nowrap !important;
}

.flex-wrap-reverse {
	flex-wrap: wrap-reverse !important;
}

.justify-content-start {
	justify-content: flex-start !important;
}

.justify-content-end {
	justify-content: flex-end !important;
}

.justify-content-center {
	justify-content: center !important;
}

.justify-content-between {
	justify-content: space-between !important;
}

.justify-content-around {
	justify-content: space-around !important;
}

.align-items-start {
	align-items: flex-start !important;
}

.align-items-end {
	align-items: flex-end !important;
}

.align-items-center {
	align-items: center !important;
}

.align-items-baseline {
	align-items: baseline !important;
}

.align-items-stretch {
	align-items: stretch !important;
}

.align-content-start {
	align-content: flex-start !important;
}

.align-content-end {
	align-content: flex-end !important;
}

.align-content-center {
	align-content: center !important;
}

.align-content-between {
	align-content: space-between !important;
}

.align-content-around {
	align-content: space-around !important;
}

.align-content-stretch {
	align-content: stretch !important;
}

.align-self-auto {
	align-self: auto !important;
}

.align-self-start {
	align-self: flex-start !important;
}

.align-self-end {
	align-self: flex-end !important;
}

.align-self-center {
	align-self: center !important;
}

.align-self-baseline {
	align-self: baseline !important;
}

.align-self-stretch {
	align-self: stretch !important;
}

@media (min-width: 576px) {
	.flex-sm-row {
		flex-direction: row !important;
	}
	.flex-sm-column {
		flex-direction: column !important;
	}
	.flex-sm-row-reverse {
		flex-direction: row-reverse !important;
	}
	.flex-sm-column-reverse {
		flex-direction: column-reverse !important;
	}
	.flex-sm-wrap {
		flex-wrap: wrap !important;
	}
	.flex-sm-nowrap {
		flex-wrap: nowrap !important;
	}
	.flex-sm-wrap-reverse {
		flex-wrap: wrap-reverse !important;
	}
	.justify-content-sm-start {
		justify-content: flex-start !important;
	}
	.justify-content-sm-end {
		justify-content: flex-end !important;
	}
	.justify-content-sm-center {
		justify-content: center !important;
	}
	.justify-content-sm-between {
		justify-content: space-between !important;
	}
	.justify-content-sm-around {
		justify-content: space-around !important;
	}
	.align-items-sm-start {
		align-items: flex-start !important;
	}
	.align-items-sm-end {
		align-items: flex-end !important;
	}
	.align-items-sm-center {
		align-items: center !important;
	}
	.align-items-sm-baseline {
		align-items: baseline !important;
	}
	.align-items-sm-stretch {
		align-items: stretch !important;
	}
	.align-content-sm-start {
		align-content: flex-start !important;
	}
	.align-content-sm-end {
		align-content: flex-end !important;
	}
	.align-content-sm-center {
		align-content: center !important;
	}
	.align-content-sm-between {
		align-content: space-between !important;
	}
	.align-content-sm-around {
		align-content: space-around !important;
	}
	.align-content-sm-stretch {
		align-content: stretch !important;
	}
	.align-self-sm-auto {
		align-self: auto !important;
	}
	.align-self-sm-start {
		align-self: flex-start !important;
	}
	.align-self-sm-end {
		align-self: flex-end !important;
	}
	.align-self-sm-center {
		align-self: center !important;
	}
	.align-self-sm-baseline {
		align-self: baseline !important;
	}
	.align-self-sm-stretch {
		align-self: stretch !important;
	}
}

@media (min-width: 768px) {
	.flex-md-row {
		flex-direction: row !important;
	}
	.flex-md-column {
		flex-direction: column !important;
	}
	.flex-md-row-reverse {
		flex-direction: row-reverse !important;
	}
	.flex-md-column-reverse {
		flex-direction: column-reverse !important;
	}
	.flex-md-wrap {
		flex-wrap: wrap !important;
	}
	.flex-md-nowrap {
		flex-wrap: nowrap !important;
	}
	.flex-md-wrap-reverse {
		flex-wrap: wrap-reverse !important;
	}
	.justify-content-md-start {
		justify-content: flex-start !important;
	}
	.justify-content-md-end {
		justify-content: flex-end !important;
	}
	.justify-content-md-center {
		justify-content: center !important;
	}
	.justify-content-md-between {
		justify-content: space-between !important;
	}
	.justify-content-md-around {
		justify-content: space-around !important;
	}
	.align-items-md-start {
		align-items: flex-start !important;
	}
	.align-items-md-end {
		align-items: flex-end !important;
	}
	.align-items-md-center {
		align-items: center !important;
	}
	.align-items-md-baseline {
		align-items: baseline !important;
	}
	.align-items-md-stretch {
		align-items: stretch !important;
	}
	.align-content-md-start {
		align-content: flex-start !important;
	}
	.align-content-md-end {
		align-content: flex-end !important;
	}
	.align-content-md-center {
		align-content: center !important;
	}
	.align-content-md-between {
		align-content: space-between !important;
	}
	.align-content-md-around {
		align-content: space-around !important;
	}
	.align-content-md-stretch {
		align-content: stretch !important;
	}
	.align-self-md-auto {
		align-self: auto !important;
	}
	.align-self-md-start {
		align-self: flex-start !important;
	}
	.align-self-md-end {
		align-self: flex-end !important;
	}
	.align-self-md-center {
		align-self: center !important;
	}
	.align-self-md-baseline {
		align-self: baseline !important;
	}
	.align-self-md-stretch {
		align-self: stretch !important;
	}
}

@media (min-width: 992px) {
	.flex-lg-row {
		flex-direction: row !important;
	}
	.flex-lg-column {
		flex-direction: column !important;
	}
	.flex-lg-row-reverse {
		flex-direction: row-reverse !important;
	}
	.flex-lg-column-reverse {
		flex-direction: column-reverse !important;
	}
	.flex-lg-wrap {
		flex-wrap: wrap !important;
	}
	.flex-lg-nowrap {
		flex-wrap: nowrap !important;
	}
	.flex-lg-wrap-reverse {
		flex-wrap: wrap-reverse !important;
	}
	.justify-content-lg-start {
		justify-content: flex-start !important;
	}
	.justify-content-lg-end {
		justify-content: flex-end !important;
	}
	.justify-content-lg-center {
		justify-content: center !important;
	}
	.justify-content-lg-between {
		justify-content: space-between !important;
	}
	.justify-content-lg-around {
		justify-content: space-around !important;
	}
	.align-items-lg-start {
		align-items: flex-start !important;
	}
	.align-items-lg-end {
		align-items: flex-end !important;
	}
	.align-items-lg-center {
		align-items: center !important;
	}
	.align-items-lg-baseline {
		align-items: baseline !important;
	}
	.align-items-lg-stretch {
		align-items: stretch !important;
	}
	.align-content-lg-start {
		align-content: flex-start !important;
	}
	.align-content-lg-end {
		align-content: flex-end !important;
	}
	.align-content-lg-center {
		align-content: center !important;
	}
	.align-content-lg-between {
		align-content: space-between !important;
	}
	.align-content-lg-around {
		align-content: space-around !important;
	}
	.align-content-lg-stretch {
		align-content: stretch !important;
	}
	.align-self-lg-auto {
		align-self: auto !important;
	}
	.align-self-lg-start {
		align-self: flex-start !important;
	}
	.align-self-lg-end {
		align-self: flex-end !important;
	}
	.align-self-lg-center {
		align-self: center !important;
	}
	.align-self-lg-baseline {
		align-self: baseline !important;
	}
	.align-self-lg-stretch {
		align-self: stretch !important;
	}
}

@media (min-width: 1200px) {
	.flex-xl-row {
		flex-direction: row !important;
	}
	.flex-xl-column {
		flex-direction: column !important;
	}
	.flex-xl-row-reverse {
		flex-direction: row-reverse !important;
	}
	.flex-xl-column-reverse {
		flex-direction: column-reverse !important;
	}
	.flex-xl-wrap {
		flex-wrap: wrap !important;
	}
	.flex-xl-nowrap {
		flex-wrap: nowrap !important;
	}
	.flex-xl-wrap-reverse {
		flex-wrap: wrap-reverse !important;
	}
	.justify-content-xl-start {
		justify-content: flex-start !important;
	}
	.justify-content-xl-end {
		justify-content: flex-end !important;
	}
	.justify-content-xl-center {
		justify-content: center !important;
	}
	.justify-content-xl-between {
		justify-content: space-between !important;
	}
	.justify-content-xl-around {
		justify-content: space-around !important;
	}
	.align-items-xl-start {
		align-items: flex-start !important;
	}
	.align-items-xl-end {
		align-items: flex-end !important;
	}
	.align-items-xl-center {
		align-items: center !important;
	}
	.align-items-xl-baseline {
		align-items: baseline !important;
	}
	.align-items-xl-stretch {
		align-items: stretch !important;
	}
	.align-content-xl-start {
		align-content: flex-start !important;
	}
	.align-content-xl-end {
		align-content: flex-end !important;
	}
	.align-content-xl-center {
		align-content: center !important;
	}
	.align-content-xl-between {
		align-content: space-between !important;
	}
	.align-content-xl-around {
		align-content: space-around !important;
	}
	.align-content-xl-stretch {
		align-content: stretch !important;
	}
	.align-self-xl-auto {
		align-self: auto !important;
	}
	.align-self-xl-start {
		align-self: flex-start !important;
	}
	.align-self-xl-end {
		align-self: flex-end !important;
	}
	.align-self-xl-center {
		align-self: center !important;
	}
	.align-self-xl-baseline {
		align-self: baseline !important;
	}
	.align-self-xl-stretch {
		align-self: stretch !important;
	}
}

@media (min-width: 1800px) {
	.flex-xxl-row {
		flex-direction: row !important;
	}
	.flex-xxl-column {
		flex-direction: column !important;
	}
	.flex-xxl-row-reverse {
		flex-direction: row-reverse !important;
	}
	.flex-xxl-column-reverse {
		flex-direction: column-reverse !important;
	}
	.flex-xxl-wrap {
		flex-wrap: wrap !important;
	}
	.flex-xxl-nowrap {
		flex-wrap: nowrap !important;
	}
	.flex-xxl-wrap-reverse {
		flex-wrap: wrap-reverse !important;
	}
	.justify-content-xxl-start {
		justify-content: flex-start !important;
	}
	.justify-content-xxl-end {
		justify-content: flex-end !important;
	}
	.justify-content-xxl-center {
		justify-content: center !important;
	}
	.justify-content-xxl-between {
		justify-content: space-between !important;
	}
	.justify-content-xxl-around {
		justify-content: space-around !important;
	}
	.align-items-xxl-start {
		align-items: flex-start !important;
	}
	.align-items-xxl-end {
		align-items: flex-end !important;
	}
	.align-items-xxl-center {
		align-items: center !important;
	}
	.align-items-xxl-baseline {
		align-items: baseline !important;
	}
	.align-items-xxl-stretch {
		align-items: stretch !important;
	}
	.align-content-xxl-start {
		align-content: flex-start !important;
	}
	.align-content-xxl-end {
		align-content: flex-end !important;
	}
	.align-content-xxl-center {
		align-content: center !important;
	}
	.align-content-xxl-between {
		align-content: space-between !important;
	}
	.align-content-xxl-around {
		align-content: space-around !important;
	}
	.align-content-xxl-stretch {
		align-content: stretch !important;
	}
	.align-self-xxl-auto {
		align-self: auto !important;
	}
	.align-self-xxl-start {
		align-self: flex-start !important;
	}
	.align-self-xxl-end {
		align-self: flex-end !important;
	}
	.align-self-xxl-center {
		align-self: center !important;
	}
	.align-self-xxl-baseline {
		align-self: baseline !important;
	}
	.align-self-xxl-stretch {
		align-self: stretch !important;
	}
}

.float-left {
	float: left !important;
}

.float-right {
	float: right !important;
}

.float-none {
	float: none !important;
}

@media (min-width: 576px) {
	.float-sm-left {
		float: left !important;
	}
	.float-sm-right {
		float: right !important;
	}
	.float-sm-none {
		float: none !important;
	}
}

@media (min-width: 768px) {
	.float-md-left {
		float: left !important;
	}
	.float-md-right {
		float: right !important;
	}
	.float-md-none {
		float: none !important;
	}
}

@media (min-width: 992px) {
	.float-lg-left {
		float: left !important;
	}
	.float-lg-right {
		float: right !important;
	}
	.float-lg-none {
		float: none !important;
	}
}

@media (min-width: 1200px) {
	.float-xl-left {
		float: left !important;
	}
	.float-xl-right {
		float: right !important;
	}
	.float-xl-none {
		float: none !important;
	}
}

@media (min-width: 1800px) {
	.float-xxl-left {
		float: left !important;
	}
	.float-xxl-right {
		float: right !important;
	}
	.float-xxl-none {
		float: none !important;
	}
}

.position-static {
	position: static !important;
}

.position-relative {
	position: relative !important;
}

.position-absolute {
	position: absolute !important;
}

.position-fixed {
	position: fixed !important;
}

.position-sticky {
	position: sticky !important;
}

.fixed-top {
	position: fixed;
	top: 0;
	right: 0;
	left: 0;
	z-index: 1030;
}

.fixed-bottom {
	position: fixed;
	right: 0;
	bottom: 0;
	left: 0;
	z-index: 1030;
}

@supports (position: sticky) {
	.sticky-top {
		position: sticky;
		top: 0;
		z-index: 1020;
	}
}

.sr-only {
	position: absolute;
	width: 1px;
	height: 1px;
	padding: 0;
	overflow: hidden;
	clip: rect(0, 0, 0, 0);
	white-space: nowrap;
	clip-path: inset(50%);
	border: 0;
}

.sr-only-focusable:active, .sr-only-focusable:focus {
	position: static;
	width: auto;
	height: auto;
	overflow: visible;
	clip: auto;
	white-space: normal;
	clip-path: none;
}

.w-25 {
	width: 25% !important;
}

.w-50 {
	width: 50% !important;
}

.w-75 {
	width: 75% !important;
}

.w-100 {
	width: 100% !important;
}

.h-25 {
	height: 25% !important;
}

.h-50 {
	height: 50% !important;
}

.h-75 {
	height: 75% !important;
}

.h-100 {
	height: 100% !important;
}

.mw-100 {
	max-width: 100% !important;
}

.mh-100 {
	max-height: 100% !important;
}

.m-0 {
	margin: 0 !important;
}

.mt-0,
.my-0 {
	margin-top: 0 !important;
}

.mr-0,
.mx-0 {
	margin-right: 0 !important;
}

.mb-0,
.my-0 {
	margin-bottom: 0 !important;
}

.ml-0,
.mx-0 {
	margin-left: 0 !important;
}

.m-1 {
	margin: 0.25rem !important;
}

.mt-1,
.my-1 {
	margin-top: 0.25rem !important;
}

.mr-1,
.mx-1 {
	margin-right: 0.25rem !important;
}

.mb-1,
.my-1 {
	margin-bottom: 0.25rem !important;
}

.ml-1,
.mx-1 {
	margin-left: 0.25rem !important;
}

.m-2 {
	margin: 0.5rem !important;
}

.mt-2,
.my-2 {
	margin-top: 0.5rem !important;
}

.mr-2,
.mx-2 {
	margin-right: 0.5rem !important;
}

.mb-2,
.my-2 {
	margin-bottom: 0.5rem !important;
}

.ml-2,
.mx-2 {
	margin-left: 0.5rem !important;
}

.m-3 {
	margin: 1rem !important;
}

.mt-3,
.my-3 {
	margin-top: 1rem !important;
}

.mr-3,
.mx-3 {
	margin-right: 1rem !important;
}

.mb-3,
.my-3 {
	margin-bottom: 1rem !important;
}

.ml-3,
.mx-3 {
	margin-left: 1rem !important;
}

.m-4 {
	margin: 1.5rem !important;
}

.mt-4,
.my-4 {
	margin-top: 1.5rem !important;
}

.mr-4,
.mx-4 {
	margin-right: 1.5rem !important;
}

.mb-4,
.my-4 {
	margin-bottom: 1.5rem !important;
}

.ml-4,
.mx-4 {
	margin-left: 1.5rem !important;
}

.m-5 {
	margin: 3rem !important;
}

.mt-5,
.my-5 {
	margin-top: 3rem !important;
}

.mr-5,
.mx-5 {
	margin-right: 3rem !important;
}

.mb-5,
.my-5 {
	margin-bottom: 3rem !important;
}

.ml-5,
.mx-5 {
	margin-left: 3rem !important;
}

.p-0 {
	padding: 0 !important;
}

.pt-0,
.py-0 {
	padding-top: 0 !important;
}

.pr-0,
.px-0 {
	padding-right: 0 !important;
}

.pb-0,
.py-0 {
	padding-bottom: 0 !important;
}

.pl-0,
.px-0 {
	padding-left: 0 !important;
}

.p-1 {
	padding: 0.25rem !important;
}

.pt-1,
.py-1 {
	padding-top: 0.25rem !important;
}

.pr-1,
.px-1 {
	padding-right: 0.25rem !important;
}

.pb-1,
.py-1 {
	padding-bottom: 0.25rem !important;
}

.pl-1,
.px-1 {
	padding-left: 0.25rem !important;
}

.p-2 {
	padding: 0.5rem !important;
}

.pt-2,
.py-2 {
	padding-top: 0.5rem !important;
}

.pr-2,
.px-2 {
	padding-right: 0.5rem !important;
}

.pb-2,
.py-2 {
	padding-bottom: 0.5rem !important;
}

.pl-2,
.px-2 {
	padding-left: 0.5rem !important;
}

.p-3 {
	padding: 1rem !important;
}

.pt-3,
.py-3 {
	padding-top: 1rem !important;
}

.pr-3,
.px-3 {
	padding-right: 1rem !important;
}

.pb-3,
.py-3 {
	padding-bottom: 1rem !important;
}

.pl-3,
.px-3 {
	padding-left: 1rem !important;
}

.p-4 {
	padding: 1.5rem !important;
}

.pt-4,
.py-4 {
	padding-top: 1.5rem !important;
}

.pr-4,
.px-4 {
	padding-right: 1.5rem !important;
}

.pb-4,
.py-4 {
	padding-bottom: 1.5rem !important;
}

.pl-4,
.px-4 {
	padding-left: 1.5rem !important;
}

.p-5 {
	padding: 3rem !important;
}

.pt-5,
.py-5 {
	padding-top: 3rem !important;
}

.pr-5,
.px-5 {
	padding-right: 3rem !important;
}

.pb-5,
.py-5 {
	padding-bottom: 3rem !important;
}

.pl-5,
.px-5 {
	padding-left: 3rem !important;
}

.m-auto {
	margin: auto !important;
}

.mt-auto,
.my-auto {
	margin-top: auto !important;
}

.mr-auto,
.mx-auto {
	margin-right: auto !important;
}

.mb-auto,
.my-auto {
	margin-bottom: auto !important;
}

.ml-auto,
.mx-auto {
	margin-left: auto !important;
}

@media (min-width: 576px) {
	.m-sm-0 {
		margin: 0 !important;
	}
	.mt-sm-0,
	.my-sm-0 {
		margin-top: 0 !important;
	}
	.mr-sm-0,
	.mx-sm-0 {
		margin-right: 0 !important;
	}
	.mb-sm-0,
	.my-sm-0 {
		margin-bottom: 0 !important;
	}
	.ml-sm-0,
	.mx-sm-0 {
		margin-left: 0 !important;
	}
	.m-sm-1 {
		margin: 0.25rem !important;
	}
	.mt-sm-1,
	.my-sm-1 {
		margin-top: 0.25rem !important;
	}
	.mr-sm-1,
	.mx-sm-1 {
		margin-right: 0.25rem !important;
	}
	.mb-sm-1,
	.my-sm-1 {
		margin-bottom: 0.25rem !important;
	}
	.ml-sm-1,
	.mx-sm-1 {
		margin-left: 0.25rem !important;
	}
	.m-sm-2 {
		margin: 0.5rem !important;
	}
	.mt-sm-2,
	.my-sm-2 {
		margin-top: 0.5rem !important;
	}
	.mr-sm-2,
	.mx-sm-2 {
		margin-right: 0.5rem !important;
	}
	.mb-sm-2,
	.my-sm-2 {
		margin-bottom: 0.5rem !important;
	}
	.ml-sm-2,
	.mx-sm-2 {
		margin-left: 0.5rem !important;
	}
	.m-sm-3 {
		margin: 1rem !important;
	}
	.mt-sm-3,
	.my-sm-3 {
		margin-top: 1rem !important;
	}
	.mr-sm-3,
	.mx-sm-3 {
		margin-right: 1rem !important;
	}
	.mb-sm-3,
	.my-sm-3 {
		margin-bottom: 1rem !important;
	}
	.ml-sm-3,
	.mx-sm-3 {
		margin-left: 1rem !important;
	}
	.m-sm-4 {
		margin: 1.5rem !important;
	}
	.mt-sm-4,
	.my-sm-4 {
		margin-top: 1.5rem !important;
	}
	.mr-sm-4,
	.mx-sm-4 {
		margin-right: 1.5rem !important;
	}
	.mb-sm-4,
	.my-sm-4 {
		margin-bottom: 1.5rem !important;
	}
	.ml-sm-4,
	.mx-sm-4 {
		margin-left: 1.5rem !important;
	}
	.m-sm-5 {
		margin: 3rem !important;
	}
	.mt-sm-5,
	.my-sm-5 {
		margin-top: 3rem !important;
	}
	.mr-sm-5,
	.mx-sm-5 {
		margin-right: 3rem !important;
	}
	.mb-sm-5,
	.my-sm-5 {
		margin-bottom: 3rem !important;
	}
	.ml-sm-5,
	.mx-sm-5 {
		margin-left: 3rem !important;
	}
	.p-sm-0 {
		padding: 0 !important;
	}
	.pt-sm-0,
	.py-sm-0 {
		padding-top: 0 !important;
	}
	.pr-sm-0,
	.px-sm-0 {
		padding-right: 0 !important;
	}
	.pb-sm-0,
	.py-sm-0 {
		padding-bottom: 0 !important;
	}
	.pl-sm-0,
	.px-sm-0 {
		padding-left: 0 !important;
	}
	.p-sm-1 {
		padding: 0.25rem !important;
	}
	.pt-sm-1,
	.py-sm-1 {
		padding-top: 0.25rem !important;
	}
	.pr-sm-1,
	.px-sm-1 {
		padding-right: 0.25rem !important;
	}
	.pb-sm-1,
	.py-sm-1 {
		padding-bottom: 0.25rem !important;
	}
	.pl-sm-1,
	.px-sm-1 {
		padding-left: 0.25rem !important;
	}
	.p-sm-2 {
		padding: 0.5rem !important;
	}
	.pt-sm-2,
	.py-sm-2 {
		padding-top: 0.5rem !important;
	}
	.pr-sm-2,
	.px-sm-2 {
		padding-right: 0.5rem !important;
	}
	.pb-sm-2,
	.py-sm-2 {
		padding-bottom: 0.5rem !important;
	}
	.pl-sm-2,
	.px-sm-2 {
		padding-left: 0.5rem !important;
	}
	.p-sm-3 {
		padding: 1rem !important;
	}
	.pt-sm-3,
	.py-sm-3 {
		padding-top: 1rem !important;
	}
	.pr-sm-3,
	.px-sm-3 {
		padding-right: 1rem !important;
	}
	.pb-sm-3,
	.py-sm-3 {
		padding-bottom: 1rem !important;
	}
	.pl-sm-3,
	.px-sm-3 {
		padding-left: 1rem !important;
	}
	.p-sm-4 {
		padding: 1.5rem !important;
	}
	.pt-sm-4,
	.py-sm-4 {
		padding-top: 1.5rem !important;
	}
	.pr-sm-4,
	.px-sm-4 {
		padding-right: 1.5rem !important;
	}
	.pb-sm-4,
	.py-sm-4 {
		padding-bottom: 1.5rem !important;
	}
	.pl-sm-4,
	.px-sm-4 {
		padding-left: 1.5rem !important;
	}
	.p-sm-5 {
		padding: 3rem !important;
	}
	.pt-sm-5,
	.py-sm-5 {
		padding-top: 3rem !important;
	}
	.pr-sm-5,
	.px-sm-5 {
		padding-right: 3rem !important;
	}
	.pb-sm-5,
	.py-sm-5 {
		padding-bottom: 3rem !important;
	}
	.pl-sm-5,
	.px-sm-5 {
		padding-left: 3rem !important;
	}
	.m-sm-auto {
		margin: auto !important;
	}
	.mt-sm-auto,
	.my-sm-auto {
		margin-top: auto !important;
	}
	.mr-sm-auto,
	.mx-sm-auto {
		margin-right: auto !important;
	}
	.mb-sm-auto,
	.my-sm-auto {
		margin-bottom: auto !important;
	}
	.ml-sm-auto,
	.mx-sm-auto {
		margin-left: auto !important;
	}
}

@media (min-width: 768px) {
	.m-md-0 {
		margin: 0 !important;
	}
	.mt-md-0,
	.my-md-0 {
		margin-top: 0 !important;
	}
	.mr-md-0,
	.mx-md-0 {
		margin-right: 0 !important;
	}
	.mb-md-0,
	.my-md-0 {
		margin-bottom: 0 !important;
	}
	.ml-md-0,
	.mx-md-0 {
		margin-left: 0 !important;
	}
	.m-md-1 {
		margin: 0.25rem !important;
	}
	.mt-md-1,
	.my-md-1 {
		margin-top: 0.25rem !important;
	}
	.mr-md-1,
	.mx-md-1 {
		margin-right: 0.25rem !important;
	}
	.mb-md-1,
	.my-md-1 {
		margin-bottom: 0.25rem !important;
	}
	.ml-md-1,
	.mx-md-1 {
		margin-left: 0.25rem !important;
	}
	.m-md-2 {
		margin: 0.5rem !important;
	}
	.mt-md-2,
	.my-md-2 {
		margin-top: 0.5rem !important;
	}
	.mr-md-2,
	.mx-md-2 {
		margin-right: 0.5rem !important;
	}
	.mb-md-2,
	.my-md-2 {
		margin-bottom: 0.5rem !important;
	}
	.ml-md-2,
	.mx-md-2 {
		margin-left: 0.5rem !important;
	}
	.m-md-3 {
		margin: 1rem !important;
	}
	.mt-md-3,
	.my-md-3 {
		margin-top: 1rem !important;
	}
	.mr-md-3,
	.mx-md-3 {
		margin-right: 1rem !important;
	}
	.mb-md-3,
	.my-md-3 {
		margin-bottom: 1rem !important;
	}
	.ml-md-3,
	.mx-md-3 {
		margin-left: 1rem !important;
	}
	.m-md-4 {
		margin: 1.5rem !important;
	}
	.mt-md-4,
	.my-md-4 {
		margin-top: 1.5rem !important;
	}
	.mr-md-4,
	.mx-md-4 {
		margin-right: 1.5rem !important;
	}
	.mb-md-4,
	.my-md-4 {
		margin-bottom: 1.5rem !important;
	}
	.ml-md-4,
	.mx-md-4 {
		margin-left: 1.5rem !important;
	}
	.m-md-5 {
		margin: 3rem !important;
	}
	.mt-md-5,
	.my-md-5 {
		margin-top: 3rem !important;
	}
	.mr-md-5,
	.mx-md-5 {
		margin-right: 3rem !important;
	}
	.mb-md-5,
	.my-md-5 {
		margin-bottom: 3rem !important;
	}
	.ml-md-5,
	.mx-md-5 {
		margin-left: 3rem !important;
	}
	.p-md-0 {
		padding: 0 !important;
	}
	.pt-md-0,
	.py-md-0 {
		padding-top: 0 !important;
	}
	.pr-md-0,
	.px-md-0 {
		padding-right: 0 !important;
	}
	.pb-md-0,
	.py-md-0 {
		padding-bottom: 0 !important;
	}
	.pl-md-0,
	.px-md-0 {
		padding-left: 0 !important;
	}
	.p-md-1 {
		padding: 0.25rem !important;
	}
	.pt-md-1,
	.py-md-1 {
		padding-top: 0.25rem !important;
	}
	.pr-md-1,
	.px-md-1 {
		padding-right: 0.25rem !important;
	}
	.pb-md-1,
	.py-md-1 {
		padding-bottom: 0.25rem !important;
	}
	.pl-md-1,
	.px-md-1 {
		padding-left: 0.25rem !important;
	}
	.p-md-2 {
		padding: 0.5rem !important;
	}
	.pt-md-2,
	.py-md-2 {
		padding-top: 0.5rem !important;
	}
	.pr-md-2,
	.px-md-2 {
		padding-right: 0.5rem !important;
	}
	.pb-md-2,
	.py-md-2 {
		padding-bottom: 0.5rem !important;
	}
	.pl-md-2,
	.px-md-2 {
		padding-left: 0.5rem !important;
	}
	.p-md-3 {
		padding: 1rem !important;
	}
	.pt-md-3,
	.py-md-3 {
		padding-top: 1rem !important;
	}
	.pr-md-3,
	.px-md-3 {
		padding-right: 1rem !important;
	}
	.pb-md-3,
	.py-md-3 {
		padding-bottom: 1rem !important;
	}
	.pl-md-3,
	.px-md-3 {
		padding-left: 1rem !important;
	}
	.p-md-4 {
		padding: 1.5rem !important;
	}
	.pt-md-4,
	.py-md-4 {
		padding-top: 1.5rem !important;
	}
	.pr-md-4,
	.px-md-4 {
		padding-right: 1.5rem !important;
	}
	.pb-md-4,
	.py-md-4 {
		padding-bottom: 1.5rem !important;
	}
	.pl-md-4,
	.px-md-4 {
		padding-left: 1.5rem !important;
	}
	.p-md-5 {
		padding: 3rem !important;
	}
	.pt-md-5,
	.py-md-5 {
		padding-top: 3rem !important;
	}
	.pr-md-5,
	.px-md-5 {
		padding-right: 3rem !important;
	}
	.pb-md-5,
	.py-md-5 {
		padding-bottom: 3rem !important;
	}
	.pl-md-5,
	.px-md-5 {
		padding-left: 3rem !important;
	}
	.m-md-auto {
		margin: auto !important;
	}
	.mt-md-auto,
	.my-md-auto {
		margin-top: auto !important;
	}
	.mr-md-auto,
	.mx-md-auto {
		margin-right: auto !important;
	}
	.mb-md-auto,
	.my-md-auto {
		margin-bottom: auto !important;
	}
	.ml-md-auto,
	.mx-md-auto {
		margin-left: auto !important;
	}
}

@media (min-width: 992px) {
	.m-lg-0 {
		margin: 0 !important;
	}
	.mt-lg-0,
	.my-lg-0 {
		margin-top: 0 !important;
	}
	.mr-lg-0,
	.mx-lg-0 {
		margin-right: 0 !important;
	}
	.mb-lg-0,
	.my-lg-0 {
		margin-bottom: 0 !important;
	}
	.ml-lg-0,
	.mx-lg-0 {
		margin-left: 0 !important;
	}
	.m-lg-1 {
		margin: 0.25rem !important;
	}
	.mt-lg-1,
	.my-lg-1 {
		margin-top: 0.25rem !important;
	}
	.mr-lg-1,
	.mx-lg-1 {
		margin-right: 0.25rem !important;
	}
	.mb-lg-1,
	.my-lg-1 {
		margin-bottom: 0.25rem !important;
	}
	.ml-lg-1,
	.mx-lg-1 {
		margin-left: 0.25rem !important;
	}
	.m-lg-2 {
		margin: 0.5rem !important;
	}
	.mt-lg-2,
	.my-lg-2 {
		margin-top: 0.5rem !important;
	}
	.mr-lg-2,
	.mx-lg-2 {
		margin-right: 0.5rem !important;
	}
	.mb-lg-2,
	.my-lg-2 {
		margin-bottom: 0.5rem !important;
	}
	.ml-lg-2,
	.mx-lg-2 {
		margin-left: 0.5rem !important;
	}
	.m-lg-3 {
		margin: 1rem !important;
	}
	.mt-lg-3,
	.my-lg-3 {
		margin-top: 1rem !important;
	}
	.mr-lg-3,
	.mx-lg-3 {
		margin-right: 1rem !important;
	}
	.mb-lg-3,
	.my-lg-3 {
		margin-bottom: 1rem !important;
	}
	.ml-lg-3,
	.mx-lg-3 {
		margin-left: 1rem !important;
	}
	.m-lg-4 {
		margin: 1.5rem !important;
	}
	.mt-lg-4,
	.my-lg-4 {
		margin-top: 1.5rem !important;
	}
	.mr-lg-4,
	.mx-lg-4 {
		margin-right: 1.5rem !important;
	}
	.mb-lg-4,
	.my-lg-4 {
		margin-bottom: 1.5rem !important;
	}
	.ml-lg-4,
	.mx-lg-4 {
		margin-left: 1.5rem !important;
	}
	.m-lg-5 {
		margin: 3rem !important;
	}
	.mt-lg-5,
	.my-lg-5 {
		margin-top: 3rem !important;
	}
	.mr-lg-5,
	.mx-lg-5 {
		margin-right: 3rem !important;
	}
	.mb-lg-5,
	.my-lg-5 {
		margin-bottom: 3rem !important;
	}
	.ml-lg-5,
	.mx-lg-5 {
		margin-left: 3rem !important;
	}
	.p-lg-0 {
		padding: 0 !important;
	}
	.pt-lg-0,
	.py-lg-0 {
		padding-top: 0 !important;
	}
	.pr-lg-0,
	.px-lg-0 {
		padding-right: 0 !important;
	}
	.pb-lg-0,
	.py-lg-0 {
		padding-bottom: 0 !important;
	}
	.pl-lg-0,
	.px-lg-0 {
		padding-left: 0 !important;
	}
	.p-lg-1 {
		padding: 0.25rem !important;
	}
	.pt-lg-1,
	.py-lg-1 {
		padding-top: 0.25rem !important;
	}
	.pr-lg-1,
	.px-lg-1 {
		padding-right: 0.25rem !important;
	}
	.pb-lg-1,
	.py-lg-1 {
		padding-bottom: 0.25rem !important;
	}
	.pl-lg-1,
	.px-lg-1 {
		padding-left: 0.25rem !important;
	}
	.p-lg-2 {
		padding: 0.5rem !important;
	}
	.pt-lg-2,
	.py-lg-2 {
		padding-top: 0.5rem !important;
	}
	.pr-lg-2,
	.px-lg-2 {
		padding-right: 0.5rem !important;
	}
	.pb-lg-2,
	.py-lg-2 {
		padding-bottom: 0.5rem !important;
	}
	.pl-lg-2,
	.px-lg-2 {
		padding-left: 0.5rem !important;
	}
	.p-lg-3 {
		padding: 1rem !important;
	}
	.pt-lg-3,
	.py-lg-3 {
		padding-top: 1rem !important;
	}
	.pr-lg-3,
	.px-lg-3 {
		padding-right: 1rem !important;
	}
	.pb-lg-3,
	.py-lg-3 {
		padding-bottom: 1rem !important;
	}
	.pl-lg-3,
	.px-lg-3 {
		padding-left: 1rem !important;
	}
	.p-lg-4 {
		padding: 1.5rem !important;
	}
	.pt-lg-4,
	.py-lg-4 {
		padding-top: 1.5rem !important;
	}
	.pr-lg-4,
	.px-lg-4 {
		padding-right: 1.5rem !important;
	}
	.pb-lg-4,
	.py-lg-4 {
		padding-bottom: 1.5rem !important;
	}
	.pl-lg-4,
	.px-lg-4 {
		padding-left: 1.5rem !important;
	}
	.p-lg-5 {
		padding: 3rem !important;
	}
	.pt-lg-5,
	.py-lg-5 {
		padding-top: 3rem !important;
	}
	.pr-lg-5,
	.px-lg-5 {
		padding-right: 3rem !important;
	}
	.pb-lg-5,
	.py-lg-5 {
		padding-bottom: 3rem !important;
	}
	.pl-lg-5,
	.px-lg-5 {
		padding-left: 3rem !important;
	}
	.m-lg-auto {
		margin: auto !important;
	}
	.mt-lg-auto,
	.my-lg-auto {
		margin-top: auto !important;
	}
	.mr-lg-auto,
	.mx-lg-auto {
		margin-right: auto !important;
	}
	.mb-lg-auto,
	.my-lg-auto {
		margin-bottom: auto !important;
	}
	.ml-lg-auto,
	.mx-lg-auto {
		margin-left: auto !important;
	}
}

@media (min-width: 1200px) {
	.m-xl-0 {
		margin: 0 !important;
	}
	.mt-xl-0,
	.my-xl-0 {
		margin-top: 0 !important;
	}
	.mr-xl-0,
	.mx-xl-0 {
		margin-right: 0 !important;
	}
	.mb-xl-0,
	.my-xl-0 {
		margin-bottom: 0 !important;
	}
	.ml-xl-0,
	.mx-xl-0 {
		margin-left: 0 !important;
	}
	.m-xl-1 {
		margin: 0.25rem !important;
	}
	.mt-xl-1,
	.my-xl-1 {
		margin-top: 0.25rem !important;
	}
	.mr-xl-1,
	.mx-xl-1 {
		margin-right: 0.25rem !important;
	}
	.mb-xl-1,
	.my-xl-1 {
		margin-bottom: 0.25rem !important;
	}
	.ml-xl-1,
	.mx-xl-1 {
		margin-left: 0.25rem !important;
	}
	.m-xl-2 {
		margin: 0.5rem !important;
	}
	.mt-xl-2,
	.my-xl-2 {
		margin-top: 0.5rem !important;
	}
	.mr-xl-2,
	.mx-xl-2 {
		margin-right: 0.5rem !important;
	}
	.mb-xl-2,
	.my-xl-2 {
		margin-bottom: 0.5rem !important;
	}
	.ml-xl-2,
	.mx-xl-2 {
		margin-left: 0.5rem !important;
	}
	.m-xl-3 {
		margin: 1rem !important;
	}
	.mt-xl-3,
	.my-xl-3 {
		margin-top: 1rem !important;
	}
	.mr-xl-3,
	.mx-xl-3 {
		margin-right: 1rem !important;
	}
	.mb-xl-3,
	.my-xl-3 {
		margin-bottom: 1rem !important;
	}
	.ml-xl-3,
	.mx-xl-3 {
		margin-left: 1rem !important;
	}
	.m-xl-4 {
		margin: 1.5rem !important;
	}
	.mt-xl-4,
	.my-xl-4 {
		margin-top: 1.5rem !important;
	}
	.mr-xl-4,
	.mx-xl-4 {
		margin-right: 1.5rem !important;
	}
	.mb-xl-4,
	.my-xl-4 {
		margin-bottom: 1.5rem !important;
	}
	.ml-xl-4,
	.mx-xl-4 {
		margin-left: 1.5rem !important;
	}
	.m-xl-5 {
		margin: 3rem !important;
	}
	.mt-xl-5,
	.my-xl-5 {
		margin-top: 3rem !important;
	}
	.mr-xl-5,
	.mx-xl-5 {
		margin-right: 3rem !important;
	}
	.mb-xl-5,
	.my-xl-5 {
		margin-bottom: 3rem !important;
	}
	.ml-xl-5,
	.mx-xl-5 {
		margin-left: 3rem !important;
	}
	.p-xl-0 {
		padding: 0 !important;
	}
	.pt-xl-0,
	.py-xl-0 {
		padding-top: 0 !important;
	}
	.pr-xl-0,
	.px-xl-0 {
		padding-right: 0 !important;
	}
	.pb-xl-0,
	.py-xl-0 {
		padding-bottom: 0 !important;
	}
	.pl-xl-0,
	.px-xl-0 {
		padding-left: 0 !important;
	}
	.p-xl-1 {
		padding: 0.25rem !important;
	}
	.pt-xl-1,
	.py-xl-1 {
		padding-top: 0.25rem !important;
	}
	.pr-xl-1,
	.px-xl-1 {
		padding-right: 0.25rem !important;
	}
	.pb-xl-1,
	.py-xl-1 {
		padding-bottom: 0.25rem !important;
	}
	.pl-xl-1,
	.px-xl-1 {
		padding-left: 0.25rem !important;
	}
	.p-xl-2 {
		padding: 0.5rem !important;
	}
	.pt-xl-2,
	.py-xl-2 {
		padding-top: 0.5rem !important;
	}
	.pr-xl-2,
	.px-xl-2 {
		padding-right: 0.5rem !important;
	}
	.pb-xl-2,
	.py-xl-2 {
		padding-bottom: 0.5rem !important;
	}
	.pl-xl-2,
	.px-xl-2 {
		padding-left: 0.5rem !important;
	}
	.p-xl-3 {
		padding: 1rem !important;
	}
	.pt-xl-3,
	.py-xl-3 {
		padding-top: 1rem !important;
	}
	.pr-xl-3,
	.px-xl-3 {
		padding-right: 1rem !important;
	}
	.pb-xl-3,
	.py-xl-3 {
		padding-bottom: 1rem !important;
	}
	.pl-xl-3,
	.px-xl-3 {
		padding-left: 1rem !important;
	}
	.p-xl-4 {
		padding: 1.5rem !important;
	}
	.pt-xl-4,
	.py-xl-4 {
		padding-top: 1.5rem !important;
	}
	.pr-xl-4,
	.px-xl-4 {
		padding-right: 1.5rem !important;
	}
	.pb-xl-4,
	.py-xl-4 {
		padding-bottom: 1.5rem !important;
	}
	.pl-xl-4,
	.px-xl-4 {
		padding-left: 1.5rem !important;
	}
	.p-xl-5 {
		padding: 3rem !important;
	}
	.pt-xl-5,
	.py-xl-5 {
		padding-top: 3rem !important;
	}
	.pr-xl-5,
	.px-xl-5 {
		padding-right: 3rem !important;
	}
	.pb-xl-5,
	.py-xl-5 {
		padding-bottom: 3rem !important;
	}
	.pl-xl-5,
	.px-xl-5 {
		padding-left: 3rem !important;
	}
	.m-xl-auto {
		margin: auto !important;
	}
	.mt-xl-auto,
	.my-xl-auto {
		margin-top: auto !important;
	}
	.mr-xl-auto,
	.mx-xl-auto {
		margin-right: auto !important;
	}
	.mb-xl-auto,
	.my-xl-auto {
		margin-bottom: auto !important;
	}
	.ml-xl-auto,
	.mx-xl-auto {
		margin-left: auto !important;
	}
}

@media (min-width: 1800px) {
	.m-xxl-0 {
		margin: 0 !important;
	}
	.mt-xxl-0,
	.my-xxl-0 {
		margin-top: 0 !important;
	}
	.mr-xxl-0,
	.mx-xxl-0 {
		margin-right: 0 !important;
	}
	.mb-xxl-0,
	.my-xxl-0 {
		margin-bottom: 0 !important;
	}
	.ml-xxl-0,
	.mx-xxl-0 {
		margin-left: 0 !important;
	}
	.m-xxl-1 {
		margin: 0.25rem !important;
	}
	.mt-xxl-1,
	.my-xxl-1 {
		margin-top: 0.25rem !important;
	}
	.mr-xxl-1,
	.mx-xxl-1 {
		margin-right: 0.25rem !important;
	}
	.mb-xxl-1,
	.my-xxl-1 {
		margin-bottom: 0.25rem !important;
	}
	.ml-xxl-1,
	.mx-xxl-1 {
		margin-left: 0.25rem !important;
	}
	.m-xxl-2 {
		margin: 0.5rem !important;
	}
	.mt-xxl-2,
	.my-xxl-2 {
		margin-top: 0.5rem !important;
	}
	.mr-xxl-2,
	.mx-xxl-2 {
		margin-right: 0.5rem !important;
	}
	.mb-xxl-2,
	.my-xxl-2 {
		margin-bottom: 0.5rem !important;
	}
	.ml-xxl-2,
	.mx-xxl-2 {
		margin-left: 0.5rem !important;
	}
	.m-xxl-3 {
		margin: 1rem !important;
	}
	.mt-xxl-3,
	.my-xxl-3 {
		margin-top: 1rem !important;
	}
	.mr-xxl-3,
	.mx-xxl-3 {
		margin-right: 1rem !important;
	}
	.mb-xxl-3,
	.my-xxl-3 {
		margin-bottom: 1rem !important;
	}
	.ml-xxl-3,
	.mx-xxl-3 {
		margin-left: 1rem !important;
	}
	.m-xxl-4 {
		margin: 1.5rem !important;
	}
	.mt-xxl-4,
	.my-xxl-4 {
		margin-top: 1.5rem !important;
	}
	.mr-xxl-4,
	.mx-xxl-4 {
		margin-right: 1.5rem !important;
	}
	.mb-xxl-4,
	.my-xxl-4 {
		margin-bottom: 1.5rem !important;
	}
	.ml-xxl-4,
	.mx-xxl-4 {
		margin-left: 1.5rem !important;
	}
	.m-xxl-5 {
		margin: 3rem !important;
	}
	.mt-xxl-5,
	.my-xxl-5 {
		margin-top: 3rem !important;
	}
	.mr-xxl-5,
	.mx-xxl-5 {
		margin-right: 3rem !important;
	}
	.mb-xxl-5,
	.my-xxl-5 {
		margin-bottom: 3rem !important;
	}
	.ml-xxl-5,
	.mx-xxl-5 {
		margin-left: 3rem !important;
	}
	.p-xxl-0 {
		padding: 0 !important;
	}
	.pt-xxl-0,
	.py-xxl-0 {
		padding-top: 0 !important;
	}
	.pr-xxl-0,
	.px-xxl-0 {
		padding-right: 0 !important;
	}
	.pb-xxl-0,
	.py-xxl-0 {
		padding-bottom: 0 !important;
	}
	.pl-xxl-0,
	.px-xxl-0 {
		padding-left: 0 !important;
	}
	.p-xxl-1 {
		padding: 0.25rem !important;
	}
	.pt-xxl-1,
	.py-xxl-1 {
		padding-top: 0.25rem !important;
	}
	.pr-xxl-1,
	.px-xxl-1 {
		padding-right: 0.25rem !important;
	}
	.pb-xxl-1,
	.py-xxl-1 {
		padding-bottom: 0.25rem !important;
	}
	.pl-xxl-1,
	.px-xxl-1 {
		padding-left: 0.25rem !important;
	}
	.p-xxl-2 {
		padding: 0.5rem !important;
	}
	.pt-xxl-2,
	.py-xxl-2 {
		padding-top: 0.5rem !important;
	}
	.pr-xxl-2,
	.px-xxl-2 {
		padding-right: 0.5rem !important;
	}
	.pb-xxl-2,
	.py-xxl-2 {
		padding-bottom: 0.5rem !important;
	}
	.pl-xxl-2,
	.px-xxl-2 {
		padding-left: 0.5rem !important;
	}
	.p-xxl-3 {
		padding: 1rem !important;
	}
	.pt-xxl-3,
	.py-xxl-3 {
		padding-top: 1rem !important;
	}
	.pr-xxl-3,
	.px-xxl-3 {
		padding-right: 1rem !important;
	}
	.pb-xxl-3,
	.py-xxl-3 {
		padding-bottom: 1rem !important;
	}
	.pl-xxl-3,
	.px-xxl-3 {
		padding-left: 1rem !important;
	}
	.p-xxl-4 {
		padding: 1.5rem !important;
	}
	.pt-xxl-4,
	.py-xxl-4 {
		padding-top: 1.5rem !important;
	}
	.pr-xxl-4,
	.px-xxl-4 {
		padding-right: 1.5rem !important;
	}
	.pb-xxl-4,
	.py-xxl-4 {
		padding-bottom: 1.5rem !important;
	}
	.pl-xxl-4,
	.px-xxl-4 {
		padding-left: 1.5rem !important;
	}
	.p-xxl-5 {
		padding: 3rem !important;
	}
	.pt-xxl-5,
	.py-xxl-5 {
		padding-top: 3rem !important;
	}
	.pr-xxl-5,
	.px-xxl-5 {
		padding-right: 3rem !important;
	}
	.pb-xxl-5,
	.py-xxl-5 {
		padding-bottom: 3rem !important;
	}
	.pl-xxl-5,
	.px-xxl-5 {
		padding-left: 3rem !important;
	}
	.m-xxl-auto {
		margin: auto !important;
	}
	.mt-xxl-auto,
	.my-xxl-auto {
		margin-top: auto !important;
	}
	.mr-xxl-auto,
	.mx-xxl-auto {
		margin-right: auto !important;
	}
	.mb-xxl-auto,
	.my-xxl-auto {
		margin-bottom: auto !important;
	}
	.ml-xxl-auto,
	.mx-xxl-auto {
		margin-left: auto !important;
	}
}

.text-justify {
	text-align: justify !important;
}

.text-nowrap {
	white-space: nowrap !important;
}

.text-truncate {
	overflow: hidden;
	text-overflow: ellipsis;
	white-space: nowrap;
}

.text-left {
	text-align: left !important;
}

.text-right {
	text-align: right !important;
}

.text-center {
	text-align: center !important;
}

@media (min-width: 576px) {
	.text-sm-left {
		text-align: left !important;
	}
	.text-sm-right {
		text-align: right !important;
	}
	.text-sm-center {
		text-align: center !important;
	}
}

@media (min-width: 768px) {
	.text-md-left {
		text-align: left !important;
	}
	.text-md-right {
		text-align: right !important;
	}
	.text-md-center {
		text-align: center !important;
	}
}

@media (min-width: 992px) {
	.text-lg-left {
		text-align: left !important;
	}
	.text-lg-right {
		text-align: right !important;
	}
	.text-lg-center {
		text-align: center !important;
	}
}

@media (min-width: 1200px) {
	.text-xl-left {
		text-align: left !important;
	}
	.text-xl-right {
		text-align: right !important;
	}
	.text-xl-center {
		text-align: center !important;
	}
}

@media (min-width: 1800px) {
	.text-xxl-left {
		text-align: left !important;
	}
	.text-xxl-right {
		text-align: right !important;
	}
	.text-xxl-center {
		text-align: center !important;
	}
}

.text-lowercase {
	text-transform: lowercase !important;
}

.text-uppercase {
	text-transform: uppercase !important;
}

.text-capitalize {
	text-transform: capitalize !important;
}

.font-weight-light {
	font-weight: 300 !important;
}

.font-weight-normal {
	font-weight: 400 !important;
}

.font-weight-bold {
	font-weight: 700 !important;
}

.font-italic {
	font-style: italic !important;
}

.text-white {
	color: #fff !important;
}

.text-primary {
	color: #007bff !important;
}

a.text-primary:focus, a.text-primary:hover {
	color: #0062cc !important;
}

.text-secondary {
	color: #868e96 !important;
}

a.text-secondary:focus, a.text-secondary:hover {
	color: #6c757d !important;
}

.text-success {
	color: #28a745 !important;
}

a.text-success:focus, a.text-success:hover {
	color: #1e7e34 !important;
}

.text-info {
	color: #17a2b8 !important;
}

a.text-info:focus, a.text-info:hover {
	color: #117a8b !important;
}

.text-warning {
	color: #ffc107 !important;
}

a.text-warning:focus, a.text-warning:hover {
	color: #d39e00 !important;
}

.text-danger {
	color: #dc3545 !important;
}

a.text-danger:focus, a.text-danger:hover {
	color: #bd2130 !important;
}

.text-light {
	color: #f8f9fa !important;
}

a.text-light:focus, a.text-light:hover {
	color: #dae0e5 !important;
}

.text-dark {
	color: #343a40 !important;
}

a.text-dark:focus, a.text-dark:hover {
	color: #1d2124 !important;
}

.text-muted {
	color: #dedede !important;
}

.text-hide {
	font: 0/0 a;
	color: transparent;
	text-shadow: none;
	background-color: transparent;
	border: 0;
}

.visible {
	visibility: visible !important;
}

.invisible {
	visibility: hidden !important;
}



<?php // BEGIN PHP
$tmp = ob_get_contents(); ob_end_clean(); dolWebsiteOutput($tmp);
// END PHP ?>
