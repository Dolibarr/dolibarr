<?php
// BEGIN PHP File generated to provide a wrapper.php - DO NOT MODIFY - It is just a generated wrapper.
$websitekey=basename(dirname(__FILE__));
if (! defined('USEDOLIBARRSERVER') && ! defined('USEDOLIBARREDITOR')) { require_once './master.inc.php'; } // Load master if not already loaded
$original_file=str_replace("../","/", GETPOST("file","alpha"));
if ($_GET["modulepart"] == "mycompany" && preg_match('/^\/?logos\//', $original_file)) readfile(dol_osencode($conf->mycompany->dir_output."/".$original_file));
else print 'Bad value for modulepart or file';
if (is_object($db)) $db->close();
// END PHP ?>
