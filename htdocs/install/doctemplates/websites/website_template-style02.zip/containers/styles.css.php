<?php // BEGIN PHP
$websitekey=basename(__DIR__);
if (! defined('USEDOLIBARRSERVER') && ! defined('USEDOLIBARREDITOR')) { require_once __DIR__.'/master.inc.php'; } // Load env if not already loaded
require_once DOL_DOCUMENT_ROOT.'/core/lib/website.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/website.inc.php';
ob_start();
if (! headers_sent()) {	/* because file is included inline when in edit mode and we don't want warning */ 
header('Cache-Control: max-age=3600, public, must-revalidate');
header('Content-type: text/css');
}
// END PHP ?>
/* CSS content (all pages) 
body.bodywebsite { margin: 0; font-family: 'Open Sans', sans-serif; }
.bodywebsite h1 { margin-top: 0; margin-bottom: 0; padding: 10px;}
*/

.bodywebsite h1,
.bodywebsite h2,
.bodywebsite h3,
.bodywebsite h4,
.bodywebsite h5,
.bodywebsite h6 {
    font-family: Hurricane;
}

.bodywebsite hr {
    margin: 100px;
}

.bodywebsite header {
    align-items: center;
    justify-content: center;
}
.bodywebsite .bg {
    background-color: #010134;
}

.bodywebsite #mysection1 {
    color: white;
    background-color: #010134;
    font-family: Arial, Helvetica, sans-serif;
    font-weight: bold;
}

.bodywebsite #main {
    padding-top: 15%;
}

.bodywebsite .btn-perso {
    margin: 20px 15px;
    font-weight: bold;
    background-color: #a600a9;
}
.bodywebsite .btn-perso:hover {
    background-color: #79027b;
    color: white;
}

.bodywebsite .btn-perso2 {
    font-weight: bold;
    background-color: #7700ba;
}
.bodywebsite .btn-perso2:hover {
    background-color: #3d0160;
    color: white;
}

.bodywebsite .product {
    margin-bottom: 20px;
}

.bodywebsite .flex {
    display: flex;
    flex-direction: column;
    align-items: center;
}
<?php // BEGIN PHP
$tmp = ob_get_contents(); ob_end_clean(); dolWebsiteOutput($tmp, "css");
// END PHP ?>
