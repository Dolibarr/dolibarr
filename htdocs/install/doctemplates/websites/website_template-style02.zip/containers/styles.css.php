<?php // BEGIN PHP
$websitekey=basename(__DIR__);
if (! defined('USEDOLIBARRSERVER') && ! defined('USEDOLIBARREDITOR')) { require_once __DIR__.'/master.inc.php'; } // Load env if not already loaded
require_once DOL_DOCUMENT_ROOT.'/core/lib/website.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/website.inc.php';
ob_start();
if (! headers_sent()) {	/* because file is included inline when in edit mode and we don't want warning */ 
header('Cache-Control: max-age=3600, public, must-revalidate');
header('Content-type: text/css');
}
// END PHP ?>
/* CSS content (all pages) 
body.bodywebsite { margin: 0; font-family: 'Open Sans', sans-serif; }
.bodywebsite h1 { margin-top: 0; margin-bottom: 0; padding: 10px;}
*/

h1,
h2,
h3,
h4,
h5,
h6 {
    font-family: Hurricane;
}

hr {
    margin: 100px;
}

header {
    align-items: center;
    justify-content: center;
}
.bg {
    background-color: #010134;
}
#mysection1 {
    color: white;
    background-color: #010134;
    font-family: Arial, Helvetica, sans-serif;
    font-weight: bold;
}

#main {
    margin-top: 0%;
    margin-bottom: 15%;
}

.btn-perso {
    font-weight: bold;
    background-color: #a600a9;
}
.btn-perso:hover {
    background-color: #79027b;
    color: white;
}

.btn-perso2 {
    font-weight: bold;
    background-color: #7700ba;
}
.btn-perso2:hover {
    background-color: #3d0160;
    color: white;
}

.product {
    margin-bottom: 20px;
}

.flex {
    display: flex;
    flex-direction: column;
    align-items: center;
}
<?php // BEGIN PHP
$tmp = ob_get_contents(); ob_end_clean(); dolWebsiteOutput($tmp, "css");
// END PHP ?>
