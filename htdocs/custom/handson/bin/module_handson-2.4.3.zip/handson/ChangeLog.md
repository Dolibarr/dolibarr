# CHANGELOG HANDSON FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

#### 2.0.10.2
Bug fix Coaches Table

### 2.0.7
DHL Label works now

### 2.0.7
RP Update

### 2.0.3-2.0.6
DHL Label bugfixes

### 2.0.2
Bug fixes DHL Label

### 2.0.1
Bug fixes DHL Label

# 2.0
- Entities: RP, Team, Player
- DHL Label

## 1.15
DHl Label Creation implemented

####1.14.4.1
Bugfix

###1.14.4
Deleting implemented

###1.14.3.2
Minor bug fix

####1.14.3.1
Forgot to comment picto show

### 1.14.3
Employee can download exported csv-zip file
Menu structure on handson-menu adapted

### 1.14.2
Minor bug fix

### 1.14.1
Minor bug fix

## 1.14
CSV conversion contao->hub added

## 1.13
Tab Verträge works now and shows a list of Verträge

###1.12.4
Add export to Thirdparties

###1.12.3
Menu changes

#1.12.2
Change RP Liste to contacts (instead of thirdparties)

#1.12.1
fk_typent 234->238 --> difference between dev and prod ...

## 1.12
RP Liste added

# 1.11.6
Adressen werden korrekt angezeigt

## 1.9.3
Bug fixes in DHL Export

## 1.9.2
CSV Export für DHL

## 1.9.1.1
Bug fix

## 1.9.1
Adresse + PLZ in KlaziListe hinzugefügt

## 1.9
Excel-Export

## 1.8
Verlinkung von Geschäftspartner zum Vertrag

## 1.7.1
Filterfunktion funktioniert auch für chkbxlst Felder

## 1.7
Filterfunktion in Verträge funktioniert

## 1.6.4
Unterstützung vom E-Mail-Adressen Button auf der Klazibestelliste

##1.6.3
Klazi BEstelliste: E-Mail Feld hinzugefüt. Filter auf neue Felder funktionieren.

## 1.6
Neue Liste für Klazibestellungen

##1.5.2.3
Bug fixes

## 1.5.2
Bug fixes

## 1.5.1
Added order select field in mail trigger.

## 1.5
Menu improvements.
Possibility to manually trigger order confirmation mail.

## 1.3
Added rules for mailing

## 1.2.1
Sendmail creates a pdf if not existing

## 1.2
With sendmail

## 1.0.2
Foerderung can choose category

## 1.0.1
Help text is being displayed properly

## 1.0

Initial version
