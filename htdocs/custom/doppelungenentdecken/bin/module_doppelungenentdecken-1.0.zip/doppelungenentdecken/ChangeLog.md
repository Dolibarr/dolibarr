# CHANGELOG DOPPELUNGENENTDECKEN FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## 1.0

Initial version
Works for thirdparties
