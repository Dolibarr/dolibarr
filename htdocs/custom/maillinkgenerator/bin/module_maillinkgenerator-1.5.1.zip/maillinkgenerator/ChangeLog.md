# CHANGELOG MAILLINKGENERATOR FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

#1.5.1
Add to Thirdparties

## 1.4.2
Support of Klazi Bestelliste

## 1.4.1
Bug Fix

# 1.4
Button being shown on memberlist too.

# 1.3
Rest of page is greyed out.

# 1.2
Bcc is not highlited anymore. Select all & copy added. Span is textarea now. But css doesn't work in prod.

# 1.1
Links became buttons. Bcc button is highlighted. Icon added.

# 1.0
Initial version
